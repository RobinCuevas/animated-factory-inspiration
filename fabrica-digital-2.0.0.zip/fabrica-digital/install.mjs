import { readdir, cp, mkdir, readFile, writeFile, rename, lstat, realpath, rm } from 'node:fs/promises';
import { dirname, resolve, join } from 'node:path';
import { homedir } from 'node:os';
import { fileURLToPath } from 'node:url';

const source = dirname(fileURLToPath(import.meta.url));
const exists = async path => {
  try { await lstat(path); return true; }
  catch (error) { if (error.code === 'ENOENT') return false; throw error; }
};
async function refuseSymlink(path) {
  if ((await lstat(path)).isSymbolicLink()) throw new Error(`No se modifica un enlace simbólico: ${path}`);
}
async function checkExistingParents(path, home) {
  for (let current = path; current !== dirname(home); current = dirname(current)) {
    if (await exists(current)) await refuseSymlink(current);
    if (current === home) break;
  }
}
async function checkSourceTree(path) {
  const stat = await lstat(path);
  if (stat.isSymbolicLink()) throw new Error('El paquete contiene un enlace simbólico. Usa una copia completa del ZIP.');
  if (stat.isDirectory()) for (const item of await readdir(path)) await checkSourceTree(join(path, item));
}

// The default personal marketplace is rooted at home, like the official
// plugin scaffold: ~/plugins/<name> and ~/.agents/plugins/marketplace.json.
export async function install({ home = homedir(), apply = false } = {}) {
  home = resolve(home);
  const manifest = JSON.parse(await readFile(join(source, '.codex-plugin', 'plugin.json'), 'utf8'));
  const name = manifest.name;
  if (name !== 'fabrica-digital') throw new Error('Identificador de plugin inesperado.');
  const target = join(home, 'plugins', name);
  const config = join(home, '.agents', 'plugins', 'marketplace.json');
  await checkExistingParents(target, home);
  await checkExistingParents(config, home);
  await checkSourceTree(source);
  const hasConfig = await exists(config);
  const original = hasConfig ? await readFile(config, 'utf8') : null;
  const market = hasConfig ? JSON.parse(original) : { name: 'personal', interface: { displayName: 'Personal' }, plugins: [] };
  if (!market || !/^[A-Za-z0-9_-]+$/.test(market.name) || !Array.isArray(market.plugins) || (market.interface !== undefined && (!market.interface || typeof market.interface !== 'object' || Array.isArray(market.interface)))) {
    throw new Error('El marketplace personal no tiene un formato válido. No se ha modificado.');
  }
  if (market.plugins.some(item => item?.name === name)) throw new Error('Fábrica digital ya está registrada. Se conserva la instalación actual. Actualízala desde la gestión de plugins de Codex.');
  const same = await exists(target) && await realpath(target) === await realpath(source);
  if (await exists(target) && !same) throw new Error('Ya existe una carpeta con este nombre. No se ha sobrescrito.');
  const result = { plugin: name, version: manifest.version, source, target, marketplace: config, marketplaceName: market.name, applied: apply };
  if (!apply) return result;
  await mkdir(dirname(config), { recursive: true });
  await mkdir(dirname(target), { recursive: true });
  const lock = config + '.fabrica-digital.lock';
  await writeFile(lock, String(process.pid), { flag: 'wx' });
  const staging = target + '.install-' + process.pid;
  const temporary = config + '.' + process.pid + '.tmp';
  let copied = false, staged = false, temporaryWritten = false;
  try {
    if (!same) {
      await mkdir(staging);
      staged = true;
      for (const item of await readdir(source)) await cp(join(source, item), join(staging, item), { recursive: true, force: false, errorOnExist: true });
      if (await exists(target)) throw new Error('El destino apareció durante la copia. No se ha sobrescrito.');
      await rename(staging, target);
      staged = false;
      copied = true;
    }
    const before = await exists(config) ? await readFile(config, 'utf8') : null;
    if (before !== original) throw new Error('El marketplace cambió durante la preparación. Se conserva ese cambio.');
    if (hasConfig) await writeFile(config + '.backup-' + Date.now(), original, { flag: 'wx' });
    market.plugins.push({ name, source: { source: 'local', path: './plugins/' + name }, policy: { installation: 'AVAILABLE', authentication: 'ON_INSTALL' }, category: 'Productivity' });
    await writeFile(temporary, JSON.stringify(market, null, 2) + '\n', { flag: 'wx' });
    temporaryWritten = true;
    await rename(temporary, config);
    return result;
  } catch (error) {
    if (copied) await rm(target, { recursive: true, force: true });
    throw error;
  } finally {
    if (staged) await rm(staging, { recursive: true, force: true });
    if (temporaryWritten) await rm(temporary, { force: true });
    await rm(lock, { force: true });
  }
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    if (process.argv.length > 3 || (process.argv[2] && !['--check', '--install'].includes(process.argv[2]))) throw new Error('Uso: node install.mjs [--check | --install]');
    const result = await install({ apply: process.argv[2] === '--install' });
    console.log(JSON.stringify(result, null, 2));
    console.log(result.applied ? 'Registrado en el marketplace personal. Abre Plugins, instala Fábrica digital e inicia una tarea nueva.' : 'Comprobación sin cambios. Para registrar el plugin: node install.mjs --install');
  } catch (error) { console.error(error.message); process.exitCode = 1; }
}
