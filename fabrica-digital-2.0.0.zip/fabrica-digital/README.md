# Fábrica digital · 2.0

Un plugin para convertir el contexto de una empresa en una fábrica 3D que explique qué hace cada servicio, qué circula y qué ocurre cuando algo tarda o falla. La plantilla es neutral. Conserva iconos de servicios Azure y utiliza datos ficticios.

Incluye el recorrido interactivo, un catálogo de 17 piezas, conexiones curvas, un ejemplo para crear nuevas máquinas y personajes articulados. La reproducción, el panel explicativo y los movimientos de cámara ya están resueltos. El ejemplo de portal es una referencia editable, no una arquitectura obligatoria.

## Empezar desde el ZIP

Descomprime la carpeta `fabrica-digital` y, desde ella, comprueba la instalación:

```sh
node install.mjs --check
node install.mjs --install
```

El primer comando no modifica nada. El segundo copia el paquete a `~/plugins/fabrica-digital` y lo registra en el marketplace personal de Codex. Conserva las entradas existentes y se detiene si encuentra una instalación o un destino con el mismo nombre. No sustituye automáticamente una versión anterior. Después, abre Plugins en Codex, instala "Fábrica digital" e inicia una tarea nueva.

Se necesita Node.js 22 o posterior. El plugin no contiene credenciales ni requiere cuentas Azure. La primera ejecución del proyecto descarga dependencias de desarrollo. El vídeo requiere además FFmpeg y Chromium.

También puedes crear una copia editable sin instalar el plugin:

```sh
node skills/fabrica-digital/scripts/create-demo.mjs ../mi-fabrica
```

El destino debe ser nuevo y estar fuera del plugin. Dentro de la copia:

```sh
node scripts/factory.mjs dev
```

## Invocarlo con un caso nuevo

> Usa $fabrica-digital para explicar esta arquitectura. Este es el contexto, estos son los servicios y estas son las decisiones pendientes. La audiencia es no técnica. Usa este logo y estos colores. Queremos enseñar estos tres recorridos y entregar una web interactiva.

Si falta el logo, el caso puede empezar sin él. La primera tarea es acordar un pequeño mapa de responsabilidades y un relato causal con las fuentes disponibles. Después se adapta la escena. Una cola, un asistente de IA o una prueba de seguridad se incluyen cuando ayudan a explicar el caso.

## Qué viene preparado

- Marca configurable, logo opcional en el suelo e iconos de servicios adheridos a las máquinas, con proporciones conservadas.
- Nitidez que sigue la densidad de pantalla y el zoom del navegador, con un presupuesto de renderizado acotado.
- Cámara de ángulo fijo, desplazamiento con ratón, zoom, transiciones suaves y rótulos que intentan evitar los elementos importantes.
- Reproducir, Anterior y Siguiente. Los dos últimos animan un paso completo y pausan para leer. Al encadenar secciones se puede omitir la introducción repetida.
- Explicación a la derecha, logos alineados, detalle técnico desplegable y servicios relacionados debajo de la escena.
- Ejemplos de documentos, borradores, colas, archivos, capacidad, asistencia con IA, pruebas de seguridad y acceso de agentes. Todos son adaptables y opcionales.
- Robot asistente y evaluador de sombrero blanco reutilizables. Los ejemplos de IA conservan control humano y los de seguridad no certifican una protección real.

## Dónde se adapta

`skills/fabrica-digital/assets/template` es la plantilla copiada. Cada proyecto generado tiene su propio `README.md`, una guía de contexto en `docs/new-project-brief.md` y el contrato de adaptación en `docs/reuse-guide.md`. El código, el guion y los recursos quedan editables.

Para conservar mejoras entre clientes, incorpora a la plantilla solo comportamientos y piezas genéricas. Logos, documentos, nombres, contratos, URLs y decisiones particulares permanecen en la copia de cada proyecto.

## Distribución y recursos de terceros

El ZIP está preparado para compartir el plugin y su plantilla editable. No se añade una licencia pública para la geometría original. Acuerda los permisos de redistribución que correspondan antes de incorporarla a otro producto o publicarla como biblioteca.

Los iconos Azure, Three.js y las fuentes conservan sus condiciones y avisos en `docs/asset-sources.md` y `public/licenses/` de la plantilla. Los logos de proveedores identifican servicios, no implican patrocinio ni aprobación de la arquitectura. Un logo de cliente se incorpora a su proyecto cuando su uso está autorizado.
