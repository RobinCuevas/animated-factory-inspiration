import { readdir, cp, lstat, mkdir, realpath } from 'node:fs/promises';
import { dirname, resolve, relative, isAbsolute, join, basename, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const skill = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const plugin = resolve(skill, '../..');
const source = join(skill, 'assets', 'template');
const inside = (parent, child) => {
  const path = relative(parent, child);
  return path === '' || (!path.startsWith('..' + sep) && path !== '..' && !isAbsolute(path));
};
async function canonical(path) {
  try { return await realpath(path); }
  catch (error) {
    if (error.code !== 'ENOENT') throw error;
    return join(await canonical(dirname(path)), basename(path));
  }
}
try {
  if (process.argv.length !== 3) throw new Error('Uso: node create-demo.mjs <nuevo-directorio>');
  const target = resolve(process.argv[2]);
  if (inside(await realpath(plugin), await canonical(target))) throw new Error('El proyecto debe estar fuera del plugin instalado.');
  try { await lstat(target); throw new Error('El destino ya existe. No se ha sobrescrito.'); }
  catch (error) { if (error.code !== 'ENOENT') throw error; }
  await mkdir(dirname(target), { recursive: true });
  await mkdir(target);
  for (const name of await readdir(source)) await cp(join(source, name), join(target, name), { recursive: true, force: false, errorOnExist: true });
  console.log(`Proyecto creado: ${target}\nLee README.md y docs/new-project-brief.md. Personaliza src/project.js y adapta arquitectura, guion y escena.\nInicia con: node scripts/factory.mjs dev`);
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
