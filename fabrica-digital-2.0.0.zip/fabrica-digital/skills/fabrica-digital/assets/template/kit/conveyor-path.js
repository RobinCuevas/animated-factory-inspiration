import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';

const TAU = Math.PI * 2;
const JOIN_EPSILON = 1e-6;
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

function finite(value, name) {
  if (!Number.isFinite(value)) throw new TypeError(`${name} debe ser un número finito`);
  return value;
}

function point(value, name) {
  if (!Array.isArray(value) || value.length !== 2) throw new TypeError(`${name} debe ser [x, z]`);
  return value.map((coordinate) => finite(coordinate, name));
}

function normalizeSegments(input, minimumRadius = 0) {
  if (!Array.isArray(input) || input.length === 0) throw new TypeError('Se necesita al menos un tramo');
  let length = 0;
  const segments = input.map((source, index) => {
    if (!source || typeof source !== 'object') throw new TypeError(`Tramo ${index} inválido`);
    const start = length;
    let segment;
    if (source.type === 'line') {
      const from = point(source.from, 'from');
      const to = point(source.to, 'to');
      const dx = to[0] - from[0], dz = to[1] - from[1];
      const segmentLength = Math.hypot(dx, dz);
      if (segmentLength < JOIN_EPSILON) throw new RangeError('Un tramo recto debe tener longitud positiva');
      segment = { type: 'line', from, to, length: segmentLength, tangent: [dx / segmentLength, dz / segmentLength] };
    } else if (source.type === 'arc') {
      const center = point(source.center, 'center');
      const radius = finite(source.radius, 'radius');
      // This radius and a >= 1 m clear lane leave space for a .7 x .95 parcel.
      if (radius <= 0 || radius < minimumRadius) throw new RangeError('Radio demasiado cerrado para el ancho de cinta');
      const startAngle = finite(source.startAngle, 'startAngle');
      const endAngle = finite(source.endAngle, 'endAngle');
      let sweep = endAngle - startAngle;
      if (!Number.isFinite(sweep) || Math.abs(sweep) < JOIN_EPSILON || Math.abs(sweep) > TAU + JOIN_EPSILON) {
        throw new RangeError('El arco debe recorrer entre cero y una vuelta, sin ser nulo');
      }
      if (source.clockwise !== undefined && typeof source.clockwise !== 'boolean') throw new TypeError('clockwise debe ser booleano');
      if (source.clockwise === true && sweep > 0) sweep = Math.abs(sweep - TAU) < JOIN_EPSILON ? -TAU : sweep - TAU;
      if (source.clockwise === false && sweep < 0) sweep = Math.abs(sweep + TAU) < JOIN_EPSILON ? TAU : sweep + TAU;
      if (Math.abs(sweep) < JOIN_EPSILON) throw new RangeError('El arco no puede ser nulo');
      segment = { type: 'arc', center, radius, startAngle, sweep, sign: Math.sign(sweep), length: radius * Math.abs(sweep) };
    } else {
      throw new TypeError('El tipo de tramo debe ser line o arc');
    }
    length += segment.length;
    return { ...segment, start, end: length };
  });
  if (!Number.isFinite(length)) throw new RangeError('La longitud del recorrido debe ser finita');
  for (let i = 1; i < segments.length; i++) {
    const a = sampleSegment(segments[i - 1], segments[i - 1].length);
    const b = sampleSegment(segments[i], 0);
    if (Math.hypot(a.x - b.x, a.z - b.z) > JOIN_EPSILON) throw new RangeError(`Hay un hueco entre los tramos ${i - 1} y ${i}`);
    if (Math.hypot(a.tx - b.tx, a.tz - b.tz) > JOIN_EPSILON) throw new RangeError(`La unión ${i - 1}/${i} necesita continuidad tangente`);
  }
  return { segments, length };
}

function sampleSegment(segment, distance) {
  if (segment.type === 'line') {
    const [tx, tz] = segment.tangent;
    return { x: segment.from[0] + tx * distance, z: segment.from[1] + tz * distance, tx, tz };
  }
  const angle = segment.startAngle + segment.sign * distance / segment.radius;
  const cosine = Math.cos(angle), sine = Math.sin(angle);
  return {
    x: segment.center[0] + cosine * segment.radius,
    z: segment.center[1] + sine * segment.radius,
    tx: -sine * segment.sign, tz: cosine * segment.sign, angle,
  };
}

function locateDistance(segments, length, distance) {
  const d = clamp(finite(distance, 'distance'), 0, length);
  const segment = segments.find((item) => d < item.end) || segments.at(-1);
  return { ...sampleSegment(segment, d - segment.start), segment, distance: d };
}

function pose(p, height) {
  return { position: [p.x, height, p.z], tangent: [p.tx, 0, p.tz], yaw: Math.atan2(p.tx, p.tz) };
}

// A route can continue inside existing machines without drawing another belt.
export function createPathSampler(input, options = {}) {
  if (!options || typeof options !== 'object' || Array.isArray(options)) throw new TypeError('options debe ser un objeto');
  const height = finite(options.height ?? 1.281, 'height');
  const { segments, length } = normalizeSegments(input);
  return { length, at: (distance) => pose(locateDistance(segments, length, distance), height) };
}

/**
 * A small, open conveyor path. Angles use x = cx + r*cos(a), z = cz + r*sin(a).
 * With no clockwise flag the sign of endAngle - startAngle selects direction.
 * at() clamps finite distances to the ends. update() accepts signed absolute
 * travel, so reversing a timeline never accumulates transforms. height is the
 * contact plane, not the centre of a parcel placed on that plane.
 */
export function createConveyorPath(input, options = {}) {
  if (!options || typeof options !== 'object' || Array.isArray(options)) throw new TypeError('options debe ser un objeto');
  const width = finite(options.width ?? 1.4, 'width');
  const height = finite(options.height ?? 1.281, 'height');
  if (width < 1) throw new RangeError('width debe ser al menos 1 para dejar paso a una pieza de .7 × .95');
  if (height < 0.6) throw new RangeError('height debe ser al menos 0.6 para alojar rodillos y soportes');
  const { segments, length } = normalizeSegments(input, width / 2 + 0.25);
  if (Math.ceil(length / 0.24) > 10000) throw new RangeError('El recorrido supera el límite de 10000 rodillos');
  const object = new THREE.Group();
  object.name = 'conveyor-path';
  const geometries = new Set();
  const materials = {
    ivory: new THREE.MeshStandardMaterial({ color: 0xeee9db, roughness: 0.48, metalness: 0.12 }),
    teal: new THREE.MeshStandardMaterial({ color: 0x246964, roughness: 0.44, metalness: 0.18 }),
    steel: new THREE.MeshStandardMaterial({ color: 0x84918e, roughness: 0.32, metalness: 0.68 }),
    dark: new THREE.MeshStandardMaterial({ color: 0x293d38, roughness: 0.54, metalness: 0.20 }),
    paint: new THREE.MeshStandardMaterial({ color: 0xd9c796, roughness: 0.47, metalness: 0.18, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 }),
  };
  let disposed = false;

  function locate(distance) {
    return locateDistance(segments, length, distance);
  }

  function at(distance) {
    const p = locate(distance);
    return pose(p, height);
  }

  function mesh(geometry, material, parent = object) {
    geometries.add(geometry);
    const result = new THREE.Mesh(geometry, material);
    result.castShadow = true;
    result.receiveShadow = true;
    parent.add(result);
    return result;
  }

  function box(w, h, d, material, position, parent = object) {
    const item = mesh(new RoundedBoxGeometry(w, h, d, 2, Math.min(0.03, w / 4, h / 4, d / 4)), material, parent);
    item.position.fromArray(position);
    return item;
  }

  // Each guide is one smooth swept strip through the entire analytic path.
  // It does not join short boxes at an angle or use the old polygonal conveyor.
  const samples = [];
  for (const [index, segment] of segments.entries()) {
    const count = segment.type === 'arc' ? Math.max(2, Math.ceil(Math.abs(segment.sweep) / (Math.PI / 96))) : 1;
    for (let i = index ? 1 : 0; i <= count; i++) samples.push(sampleSegment(segment, segment.length * i / count));
  }

  function band(offset, thickness, bottom, top, material, name) {
    const positions = [], indices = [];
    for (const p of samples) {
      for (const [side, y] of [[-1, bottom], [1, bottom], [1, top], [-1, top]]) {
        const distance = offset + side * thickness / 2;
        positions.push(p.x - p.tz * distance, y, p.z + p.tx * distance);
      }
    }
    for (let i = 0; i < samples.length - 1; i++) {
      const a = i * 4, b = a + 4;
      for (let edge = 0; edge < 4; edge++) {
        const next = (edge + 1) % 4;
        indices.push(a + edge, b + edge, b + next, a + edge, b + next, a + next);
      }
    }
    const last = (samples.length - 1) * 4;
    indices.push(0, 1, 2, 0, 2, 3, last, last + 2, last + 1, last, last + 3, last + 2);
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geometry.setIndex(indices);
    geometry.computeVertexNormals();
    const result = mesh(geometry, material);
    result.name = name;
    return result;
  }
  for (const side of [-1, 1]) {
    band(side * (width / 2 + 0.075), 0.11, height - 0.35, height - 0.15, materials.teal, 'continuous-side-frame');
    band(side * (width / 2 + 0.075), 0.07, height - 0.025, height + 0.09, materials.ivory, 'continuous-guide');
  }

  // Radial cones have radii proportional to their turning radii. Their axes
  // slope down outwards so the upper generatrix is exactly the contact plane.
  const rollerCount = Math.max(1, Math.ceil(length / 0.24));
  const pitch = length / rollerCount;
  const rollers = [];
  for (let i = 0; i < rollerCount; i++) {
    const station = (i + 0.5) * pitch;
    const p = locate(station);
    const spindle = new THREE.Group();
    spindle.name = 'roller-spindle';
    object.add(spindle);
    const spinning = new THREE.Group();
    spinning.name = 'roller-spin';
    spindle.add(spinning);
    let innerRadius, outerRadius, axialLength, spinRadius, sign, axis, center;
    if (p.segment.type === 'arc') {
      const radius = p.segment.radius;
      const taper = Math.sin(pitch / (2 * radius)) * 0.64;
      const cosine = Math.sqrt(1 - taper * taper);
      const radial = new THREE.Vector3(Math.cos(p.angle), 0, Math.sin(p.angle));
      innerRadius = taper * (radius - width / 2);
      outerRadius = taper * (radius + width / 2);
      axialLength = width * cosine;
      spinRadius = taper * radius;
      sign = p.segment.sign;
      axis = radial.clone().multiplyScalar(cosine).add(new THREE.Vector3(0, -taper, 0));
      const topNormal = radial.clone().multiplyScalar(taper).add(new THREE.Vector3(0, cosine, 0));
      const innerContact = new THREE.Vector3(p.x, height, p.z).addScaledVector(radial, -width / 2);
      const outerContact = new THREE.Vector3(p.x, height, p.z).addScaledVector(radial, width / 2);
      const innerAxis = innerContact.clone().addScaledVector(topNormal, -innerRadius);
      const outerAxis = outerContact.clone().addScaledVector(topNormal, -outerRadius);
      center = innerAxis.clone().lerp(outerAxis, 0.5);
      spindle.userData.contacts = [innerContact.toArray(), outerContact.toArray()];
      spindle.userData.axisEnds = [innerAxis.toArray(), outerAxis.toArray()];
      spindle.userData.topNormal = topNormal.toArray();
    } else {
      innerRadius = outerRadius = pitch * 0.32;
      axialLength = width;
      spinRadius = innerRadius;
      sign = 1;
      axis = new THREE.Vector3(p.tz, 0, -p.tx);
      center = new THREE.Vector3(p.x, height - innerRadius, p.z);
    }
    spindle.position.copy(center);
    spindle.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), axis);
    const body = mesh(new THREE.CylinderGeometry(outerRadius, innerRadius, axialLength, 40, 1, false), materials.steel, spinning);
    body.name = 'roller-body';
    const taperDifference = outerRadius - innerRadius;
    const stripe = mesh(new THREE.CylinderGeometry(outerRadius - taperDifference * 0.02, innerRadius + taperDifference * 0.02, axialLength * 0.96, 2, 1, true, 0, 0.075), materials.paint, spinning);
    stripe.name = 'roller-paint';
    stripe.castShadow = false;
    const axleRadius = Math.min(0.024, innerRadius * 0.40);
    mesh(new THREE.CylinderGeometry(axleRadius, axleRadius, axialLength + 0.20, 12), materials.dark, spindle).name = 'roller-axle';
    for (const side of [-1, 1]) {
      const bearing = center.clone().addScaledVector(axis, side * (axialLength / 2 + 0.08));
      const bottom = height - 0.20, top = bearing.y + 0.046;
      const support = box(0.105, top - bottom, 0.12, materials.ivory, [bearing.x, (bottom + top) / 2, bearing.z]);
      support.name = 'roller-bearing';
      support.rotation.y = Math.atan2(p.tx, p.tz);
    }
    spindle.userData = { ...spindle.userData, kind: p.segment.type, station, innerRadius, outerRadius, axialLength, spinRadius, sign, contactHeight: height };
    rollers.push({ spindle, spinning, spinRadius, sign });
  }

  const supportCount = Math.max(2, Math.ceil(length / 1.8) + 1);
  for (let i = 0; i < supportCount; i++) {
    const inset = Math.min(0.14, length / 4);
    const distance = inset + (length - inset * 2) * i / (supportCount - 1);
    const p = at(distance);
    const support = new THREE.Group();
    support.name = 'conveyor-support';
    support.position.set(p.position[0], 0, p.position[2]);
    support.rotation.y = p.yaw;
    object.add(support);
    box(width + 0.29, 0.12, 0.18, materials.steel, [0, height - 0.405, 0], support);
    const legTop = height - 0.465;
    for (const side of [-1, 1]) {
      const x = side * (width / 2 + 0.07);
      box(0.10, legTop - 0.075, 0.12, materials.steel, [x, (legTop + 0.075) / 2, 0], support);
      box(0.32, 0.075, 0.31, materials.dark, [x, 0.0375, 0], support);
    }
  }
  object.userData = { width, height, length, rollerCount, pitch, guideInnerOffset: width / 2 + 0.04 };

  function update(travelDistance) {
    if (disposed) throw new Error('El transportador ha sido liberado');
    finite(travelDistance, 'travelDistance');
    for (const roller of rollers) {
      roller.spinning.rotation.y = (travelDistance % (TAU * roller.spinRadius)) / roller.spinRadius * roller.sign;
    }
  }
  update(0);
  return {
    object, length, at, update,
    dispose() {
      if (disposed) return;
      disposed = true;
      for (const geometry of geometries) geometry.dispose();
      for (const material of Object.values(materials)) material.dispose();
      object.removeFromParent();
      object.clear();
    },
  };
}
