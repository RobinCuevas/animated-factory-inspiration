import * as THREE from 'three';
import * as M from './models.js';

// Keep the proven procedural models unchanged. This adapter owns naming,
// per-instance materials, reusable controls and short, reversible examples.
export const THEMES = Object.freeze({
  neutral: { title: 'Industrial', accent: 0x216b6c, soft: 0x84b2ac, frame: 0x2a617d },
  azure: { title: 'Azul claro', accent: 0x177fa8, soft: 0x8ec8dc, frame: 0x396d96 },
  amber: { title: 'Ámbar', accent: 0x987128, soft: 0xd8bc76, frame: 0x736c58 },
  blue: { title: 'Azul profundo', accent: 0x355a88, soft: 0x9db7d8, frame: 0x435e77 },
});

const entry = (id, title, description, meaning, states = [], duration = 12) =>
  ({ id, title, description, meaning, states, duration });
export const ASSETS = Object.freeze([
  entry('document', 'Documentos y referencias', 'Cinco siluetas con significado propio.', 'Original verde, copia blanca, referencia morada, dato ámbar e incidencia roja.', ['kind']),
  entry('archive', 'Archivo de originales', 'Archivo abierto con documentos conservados.', 'Repositorio de origen. Puede representar SharePoint u otro gestor documental.', ['open']),
  entry('delivery-van', 'Furgoneta documental', 'Llegada ordinaria con puertas y carga.', 'Entrada de un lote pequeño de documentos.', ['open', 'loaded', 'moving']),
  entry('delivery-truck', 'Camión documental', 'Más volumen con la misma operación.', 'Pico de carga o campaña de entrada.', ['open', 'loaded', 'moving']),
  entry('connector', 'Conector de consulta', 'Terminal con bandejas de consulta y respuesta.', 'Interfaz de integración. El rótulo del proyecto puede identificar Microsoft Graph u otra API.'),
  entry('ingester', 'Máquina de ingesta', 'Puesto de recepción con cabezal y salida.', 'Obtiene y prepara una copia del origen.', ['processing']),
  entry('object-store', 'Almacén de objetos', 'Estanterías con copias documentales.', 'Almacenamiento de objetos, por ejemplo Blob, S3 o Cloud Storage.'),
  entry('queue', 'Cola de trabajo', 'Cinta con referencias visibles.', 'Espera de trabajo pendiente. Las fichas representan referencias, no los bytes del documento.', ['running', 'count']),
  entry('dead-letter', 'Cola de incidencias', 'Ramal compacto que termina en una bandeja.', 'Trabajos que requieren inspección y recuperación operativa.', ['active']),
  entry('processor', 'Máquina de procesamiento', 'Prensa con cámara de trabajo abierta.', 'Una instancia de cómputo convierte una copia en datos.', ['processing']),
  entry('processor-pool', 'Capacidad elástica', 'El grupo recorre 0 → 1 → 6 → 1 → 0.', 'La capacidad acompaña la demanda. Es una metáfora, no una garantía de un proveedor.', ['capacity', 'processing'], 20),
  entry('database', 'Base de datos', 'Cilindro hueco con puerta articulada.', 'Persistencia de datos, estado o evidencia, según el relato.', ['open']),
  entry('identity', 'Acceso e identidad', 'Puerta con credencial y validación visible.', 'Autenticación y acceso autorizado. El proyecto debe distinguir ambas comprobaciones.', ['authorized', 'open']),
  entry('human', 'Persona', 'Humanoide con pasos, credencial y accesorios.', 'Usuario, verificador u operador, según el contexto.', ['walking', 'identified', 'document']),
  entry('review', 'Revisión humana', 'Persona y dos pantallas sobre una mesa.', 'Comparación y decisión humana apoyadas en evidencia.'),
  entry('api', 'Servicio de acceso', 'Módulo de interfaz con puertos.', 'Servicio que recibe peticiones y aplica sus responsabilidades.'),
  entry('factory', 'Nube del cliente', 'Plataforma abierta con un perímetro y una entrada.', 'Límite lógico del entorno del cliente. No representa una VNet ni una subred.', [], 12),
]);

const definitions = new Map(ASSETS.map(item => [item.id, item]));
// Geometry objects may live in the unchanged model cache, but their GPU
// buffers need not live forever. Track active kit users, then release GPU
// resources only after the last user leaves. Three can upload a cached
// geometry again from its retained attributes when a later instance uses it.
const geometryUsers = new Map();
function retainGeometries(object) {
  const geometries = new Set();
  object.traverse(node => { if (node.geometry) geometries.add(node.geometry); });
  for (const geometry of geometries) geometryUsers.set(geometry, (geometryUsers.get(geometry) || 0) + 1);
  return geometries;
}
function releaseGeometries(geometries) {
  for (const geometry of geometries) {
    const remaining = geometryUsers.get(geometry) - 1;
    if (remaining > 0) geometryUsers.set(geometry, remaining);
    else { geometryUsers.delete(geometry); geometry.dispose(); }
  }
  geometries.clear();
}
const clamp = (value, min = 0, max = 1) => THREE.MathUtils.clamp(Number.isFinite(value) ? value : min, min, max);
export const phase = (time, duration = 12) => ((Number.isFinite(time) ? time : 0) % duration + duration) % duration;
export const smooth = (start, end, time) => {
  const x = clamp((time - start) / (end - start));
  return x * x * x * (x * (x * 6 - 15) + 10);
};
export const pulse = (start, contact, release, end, time) =>
  smooth(start, contact, time) * (1 - smooth(release, end, time));
export function capacityAt(time) {
  const t = phase(time, 20);
  return clamp(smooth(.8, 2, t) + 5 * smooth(5, 8, t)
    - 5 * smooth(12, 15, t) - smooth(17, 19, t), 0, 6);
}

function add(parent, child, x = 0, y = 0, z = 0) {
  child.position.set(x, y, z);
  parent.add(child);
  return child;
}

function makeFactory({ width = 22, depth = 16 } = {}) {
  width = Math.max(8, Number(width) || 22);
  depth = Math.max(8, Number(depth) || 16);
  const object = new THREE.Group();
  object.add(M.box(width, .35, depth, M.materials.ivory, [0, -.175, 0], .15));
  object.add(M.box(width + .12, .11, depth + .12, M.materials.darkSteel, [0, -.395, 0], .06));
  const left = -width / 2 + .18, right = width / 2 - .18;
  const back = -depth / 2 + .18, front = depth / 2 - .18;
  const entrance = Math.min(width / 4, width / 2 - 2);
  const rail = (a, b) => {
    const dx = b[0] - a[0], dz = b[1] - a[1], length = Math.hypot(dx, dz);
    for (const y of [.6, .98]) {
      const bar = M.box(.05, .05, length, M.materials.steel,
        [(a[0] + b[0]) / 2, y, (a[1] + b[1]) / 2], .01);
      bar.rotation.y = Math.atan2(dx, dz);
      object.add(bar);
    }
    const count = Math.max(1, Math.ceil(length / 2.1));
    for (let i = 0; i <= count; i++) {
      const x = a[0] + dx * i / count, z = a[1] + dz * i / count;
      object.add(M.box(.075, 1, .075, M.materials.darkSteel, [x, .5, z], .018));
      object.add(M.box(.12, .16, .12, M.materials.amber, [x, .24, z], .015));
    }
  };
  rail([left, back], [left, front]);
  rail([left, front], [entrance - 1.6, front]);
  rail([entrance + 1.6, front], [right, front]);
  object.add(M.box(width - .3, .68, .15, M.materials.ivory, [0, .34, back]));
  object.add(M.box(.15, .68, depth - .3, M.materials.ivory, [right, .34, 0]));
  object.add(M.box(3.2, .16, 1.15, M.materials.ivory, [entrance, -.08, front + .66]));
  object.userData.bounds = { left, right, back, front };
  object.userData.entrance = new THREE.Vector3(entrance, 0, front);
  object.userData.dimensions = [width, 1, depth + 1.15];
  return object;
}

function makeDeadLetter() {
  const object = new THREE.Group();
  const belt = M.makeConveyor([[-3, 1.12, 0], [3, 1.12, 0]], 1);
  object.add(belt);
  for (const z of [-.53, .53]) object.add(M.box(6, .09, .06, M.materials.error, [0, 1.25, z], .015));
  object.add(M.box(1.5, .2, 1.5, M.materials.graphite, [3, 1.06, 0]));
  object.add(M.box(1.45, .1, 1.45, M.materials.error, [3, 1.19, 0]));
  object.add(M.box(1.1, .8, .09, M.materials.graphite, [3, 2.05, -.5]));
  object.add(M.box(.89, .54, .025, M.materials.error, [3, 2.05, -.437]));
  const job = add(object, M.makeDocument({ kind: 'error' }), -3, 1.28, 0);
  object.userData.job = job;
  object.userData.rollers = belt.userData.rollers;
  object.userData.input = new THREE.Vector3(-3, 1.28, 0);
  object.userData.output = new THREE.Vector3(3, 1.28, 0);
  return object;
}

// Only chassis roles change. All five document/reference colors, indicator
// states and white copies keep their established semantic identities.
function ownMaterials(object, theme) {
  const clones = new Map();
  const replacements = new Map([
    [M.materials.teal, theme.accent], [M.materials.paleTeal, theme.soft],
    [M.materials.blue, theme.frame],
  ]);
  const copy = original => {
    if (!clones.has(original)) {
      const owned = original.clone();
      if (replacements.has(original)) owned.color.setHex(replacements.get(original));
      clones.set(original, owned);
    }
    return clones.get(original);
  };
  object.traverse(node => {
    if (node.material) node.material = Array.isArray(node.material)
      ? node.material.map(copy) : copy(node.material);
  });
  // Material references in userData must follow the replacement as well.
  object.traverse(node => {
    for (const [key, value] of Object.entries(node.userData)) {
      if (value?.isMaterial && clones.has(value)) node.userData[key] = clones.get(value);
    }
  });
  return new Set(clones.values());
}

function setAccess(gate, authorized, open) {
  // The original closure captures pre-adapter materials, so the adapter
  // explicitly operates on its own lights and retains the original geometry.
  const state = gate.userData.lightStates[authorized ? 'granted' : 'idle'];
  const light = gate.userData.lightMaterial;
  light.color.setHex(state.color);
  light.emissive.setHex(state.emissive);
  light.emissiveIntensity = state.emissiveIntensity;
  gate.userData.archMaterial.color.setHex(authorized ? 0x39bc86 : 0xe7e2d7);
  gate.userData.archMaterial.emissive.setHex(authorized ? 0x166149 : 0);
  gate.userData.archMaterial.emissiveIntensity = authorized ? .08 : 0;
  const angle = open * Math.PI / 2;
  for (const flap of gate.userData.flaps) {
    flap.position.set(flap.userData.side * (.5295 - .525 / 2 * Math.cos(angle)),
      1.03, .18 + .525 / 2 * Math.sin(angle));
    flap.rotation.y = flap.userData.side * angle;
  }
  gate.userData.authorized = authorized;
  gate.userData.openAmount = open;
}

function runMachine(machine, t, processing = true, ingester = false) {
  const p = phase(t, 4);
  const stroke = processing ? pulse(.8, 1.45, 1.75, 2.55, p) : 0;
  machine.userData.head.position.y = machine.userData.headRest.y - stroke * (ingester ? .24 : .53);
  machine.userData.document.visible = processing && p < 1.75;
  machine.userData.stamping = stroke > .001;
  for (const roller of machine.userData.rollers || []) roller.rotation.x = processing ? t * 3 : 0;
  return stroke;
}

/** Make a new instance. Never clone(true): articulated model methods retain
 * their constructor's object references. The outer Group belongs to callers. */
export function createAsset(id, options = {}) {
  const definition = definitions.get(id);
  if (!definition) throw new RangeError(`Asset desconocido: ${id}`);
  const theme = typeof options.theme === 'object' ? options.theme : THEMES[options.theme || 'neutral'];
  if (!theme) throw new RangeError(`Tema desconocido: ${options.theme}`);
  const object = new THREE.Group();
  object.name = definition.title;
  object.userData.assetId = id;
  object.userData.meaning = definition.meaning;
  object.userData.anchors = {};
  let model, machines = [], jobs = [], variants = [];
  const constructors = {
    archive: M.makeArchive, connector: M.makeGraph, ingester: M.makeIngester,
    'object-store': M.makeWarehouse, queue: M.makeQueue, processor: M.makeMachine,
    database: M.makeSQL, identity: M.makeGate, review: M.makeReview, api: M.makeApi,
  };
  if (id === 'document') {
    variants = ['original', 'copy', 'job', 'data', 'error'].map(kind => M.makeDocument({ kind }));
    variants.forEach(variant => object.add(variant));
    model = variants[0];
  } else if (id.startsWith('delivery-')) model = M.makeVan({ truck: id === 'delivery-truck' });
  else if (id === 'human') model = M.makeHuman({
    document: options.document ?? false, identified: options.identified ?? true,
    bodyColor: options.bodyColor, tool: options.tool ?? false,
  });
  else if (id === 'factory') model = makeFactory(options);
  else if (id === 'dead-letter') model = makeDeadLetter();
  else if (id === 'processor-pool') {
    model = new THREE.Group();
    for (let i = 0; i < 6; i++) {
      const x = (i % 3 - 1) * 3.6, z = (Math.floor(i / 3) - .5) * 3.8;
      const machine = add(model, M.makeMachine(), x, 0, z);
      machine.userData.rest = machine.position.clone();
      machines.push(machine);
      for (const side of [-1, 1]) {
        model.add(M.box(3.1, .018, .035, M.materials.darkSteel, [x, .02, z + side * 1.6], .004));
        model.add(M.box(.035, .018, 3.2, M.materials.darkSteel, [x + side * 1.55, .02, z], .004));
      }
    }
    model.userData.dimensions = [10.3, 3.4, 7];
  } else model = constructors[id]();
  if (id !== 'document') object.add(model);
  model.name = definition.title;
  if (id === 'identity') model.userData.symbol.visible = false;
  if (id === 'queue') {
    jobs = Array.from({ length: 4 }, () => add(model, M.makeDocument({ kind: 'job' }), 0, 1.2, 0));
  }
  const ownedMaterials = ownMaterials(object, theme);
  const usedGeometries = retainGeometries(object);
  // The direct model hooks are useful to authors. Public update remains the
  // stable contract and never changes the caller's outer transform.
  object.userData.model = model;
  object.userData.dimensions = model.userData.dimensions || null;
  for (const key of ['dock', 'input', 'output', 'entryOutside', 'entryThreshold', 'entryInside', 'entrance']) {
    if (model.userData[key]?.isVector3) object.userData.anchors[key] = model.userData[key].clone();
  }
  if (id === 'identity') model.userData.setAccess = (granted, amount = granted ? 1 : 0) =>
    setAccess(model, Boolean(granted), clamp(amount));
  let disposed = false;

  function update(timeSeconds, state = {}) {
    if (disposed) throw new Error('Este asset ya ha sido liberado.');
    const t = Number.isFinite(timeSeconds) ? timeSeconds : 0;
    const p = phase(t, definition.duration);
    const s = { ...options, ...state };
    const result = { id, time: t };
    if (id === 'document') {
      const kind = s.kind || 'copy';
      if (!variants.some(variant => variant.userData.kind === kind)) throw new RangeError(`Tipo de documento desconocido: ${kind}`);
      variants.forEach(variant => { variant.visible = variant.userData.kind === kind; });
      result.kind = kind;
    } else if (id === 'archive') {
      const open = clamp(s.open ?? 0);
      model.userData.door.position.y = open * .53;
      result.open = open;
    } else if (id.startsWith('delivery-')) {
      const explicitOpen = s.open !== undefined;
      const open = clamp(s.open ?? pulse(2.6, 3.6, 6.5, 7.6, p));
      const move = s.moving ?? !explicitOpen;
      // Travel and unloading have disjoint intervals. The return leg is a
      // closed reversing movement, so the loop returns to its initial pose.
      const distance = move && open < .001 ? -1.8 + 1.8 * smooth(0, 2.4, p) - 1.8 * smooth(8.4, 11.4, p) : 0;
      model.position.z = distance;
      model.userData.doors.forEach((door, i) => { door.rotation.y = (i ? -1 : 1) * 1.6 * open; });
      model.userData.cargo.visible = s.loaded ?? true;
      model.userData.wheels.forEach(wheel => { wheel.rotation.x = distance / (id === 'delivery-truck' ? .42 : .36); });
      Object.assign(result, { open, loaded: model.userData.cargo.visible, moving: move && open < .001, distance });
    } else if (id === 'processor' || id === 'ingester') {
      result.processing = s.processing ?? true;
      result.stroke = runMachine(model, t, result.processing, id === 'ingester');
    } else if (id === 'processor-pool') {
      const capacity = clamp(s.capacity ?? capacityAt(t), 0, 6);
      let visibleCapacity = 0;
      machines.forEach((machine, i) => {
        const amount = clamp(capacity - i);
        machine.visible = amount > .001;
        machine.scale.setScalar(Math.max(.001, amount));
        machine.position.y = (1 - amount) * 1.7;
        runMachine(machine, t + i * .47, (s.processing ?? true) && amount > .98);
        if (amount > .98) visibleCapacity++;
      });
      Object.assign(result, { capacity, visibleCapacity });
    } else if (id === 'database') {
      const open = clamp(s.open ?? pulse(1, 2.7, 6.5, 8, p));
      model.userData.setDoorOpen(open);
      result.open = open;
    } else if (id === 'identity') {
      const authorized = s.authorized ?? (p >= 2 && p < 8);
      const open = clamp(s.open ?? (s.authorized !== undefined ? Number(authorized) : pulse(2.2, 3.2, 6.7, 7.7, p)));
      setAccess(model, authorized, open);
      Object.assign(result, { authorized, open });
    } else if (id === 'human') {
      const walking = s.walking ?? true;
      model.userData.setStride(walking ? Math.sin(t * Math.PI * 2 / 1.2) * .34 : 0);
      model.userData.badge.visible = s.identified ?? true;
      model.userData.document.visible = s.document ?? false;
      Object.assign(result, { walking, identified: model.userData.badge.visible, document: model.userData.document.visible });
    } else if (id === 'queue') {
      const running = s.running ?? true;
      const count = Math.round(clamp(s.count ?? 4, 0, 4));
      model.userData.rollers.forEach(roller => { roller.rotation.x = running ? t * 3 : 0; });
      jobs.forEach((job, i) => {
        job.visible = i < count;
        job.position.z = running ? -2.4 + phase(t * .65 + i * 1.3, 5.2) : -2.05 + i * 1.37;
      });
      Object.assign(result, { running, count });
    } else if (id === 'dead-letter') {
      const active = s.active ?? true;
      const q = phase(t, 8);
      model.userData.job.visible = active && q >= .5 && q < 7.5;
      model.userData.job.position.x = -3 + 6 * smooth(.5, 5.5, q);
      model.userData.rollers.forEach(roller => { roller.rotation.x = active ? t * 3 : 0; });
      result.active = active;
    }
    object.userData.state = result;
    return result;
  }

  function dispose() {
    if (disposed) return;
    disposed = true;
    object.removeFromParent();
    // InstancedMesh owns instanceMatrix / instanceColor buffers separately
    // from its geometry. Rebuilding a warehouse must release these too.
    object.traverse(node => { if (node.isInstancedMesh) node.dispose(); });
    for (const material of ownedMaterials) material.dispose();
    ownedMaterials.clear();
    releaseGeometries(usedGeometries);
    object.clear();
    delete object.userData.model;
    object.userData.anchors = {};
    model = null;
    machines = []; jobs = []; variants = [];
  }
  try { update(0); } catch (error) { dispose(); throw error; }
  return { object, update, dispose };
}
