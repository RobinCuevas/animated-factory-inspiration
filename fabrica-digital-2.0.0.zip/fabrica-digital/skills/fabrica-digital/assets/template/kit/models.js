import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';

// A common material and geometry library keeps the whole industrial miniature
// coherent, and lets a processing cell be repeated without duplicating assets.
export const materials = {
  ivory: new THREE.MeshStandardMaterial({ color: 0xe7e2d7, roughness: 0.46, metalness: 0.12 }),
  white: new THREE.MeshStandardMaterial({ color: 0xf9f8f0, roughness: 0.73 }),
  paperSide: new THREE.MeshStandardMaterial({ color: 0xd1d3ca, roughness: 0.86 }),
  sharepoint: new THREE.MeshStandardMaterial({ color: 0x038387, roughness: 0.63, metalness: 0.03 }),
  sharepointEdge: new THREE.MeshStandardMaterial({ color: 0xa0ded2, roughness: 0.77 }),
  graphite: new THREE.MeshStandardMaterial({ color: 0x293437, roughness: 0.37, metalness: 0.5 }),
  black: new THREE.MeshStandardMaterial({ color: 0x121b1d, roughness: 0.75 }),
  steel: new THREE.MeshStandardMaterial({ color: 0xa9b2b0, roughness: 0.27, metalness: 0.83 }),
  darkSteel: new THREE.MeshStandardMaterial({ color: 0x687774, roughness: 0.31, metalness: 0.76 }),
  teal: new THREE.MeshStandardMaterial({ color: 0x216b6c, roughness: 0.36, metalness: 0.45 }),
  paleTeal: new THREE.MeshStandardMaterial({ color: 0x84b2ac, roughness: 0.38, metalness: 0.2 }),
  blue: new THREE.MeshStandardMaterial({ color: 0x2a617d, roughness: 0.34, metalness: 0.57 }),
  azure: new THREE.MeshStandardMaterial({ color: 0x139ed9, roughness: 0.33, metalness: 0.2 }),
  amber: new THREE.MeshStandardMaterial({ color: 0xdb9a30, roughness: 0.37, metalness: 0.38 }),
  amberLight: new THREE.MeshStandardMaterial({ color: 0xffcd68, emissive: 0xd48a27, emissiveIntensity: 0.45 }),
  tealLight: new THREE.MeshStandardMaterial({ color: 0x9eddd0, emissive: 0x52b0a8, emissiveIntensity: 0.46 }),
  screen: new THREE.MeshStandardMaterial({ color: 0x163333, roughness: 0.22, metalness: 0.38 }),
  glass: new THREE.MeshPhysicalMaterial({ color: 0x63b8b1, roughness: 0.18, metalness: 0, transparent: true, opacity: 0.16, depthWrite: false, side: THREE.DoubleSide }),
  rubber: new THREE.MeshStandardMaterial({ color: 0x1a2022, roughness: 0.95 }),
  red: new THREE.MeshStandardMaterial({ color: 0xbb5540, roughness: 0.38 }),
  purple: new THREE.MeshStandardMaterial({ color: 0x7651a8, roughness: 0.42, metalness: 0.22 }),
  purpleLight: new THREE.MeshStandardMaterial({ color: 0xbba4dc, roughness: 0.44, metalness: 0.12 }),
  error: new THREE.MeshStandardMaterial({ color: 0xce4148, roughness: 0.42, metalness: 0.18 }),
  accessLight: new THREE.MeshStandardMaterial({ color: 0x70deab, emissive: 0x20a86d, emissiveIntensity: 0.65, roughness: 0.34 }),
};

const geometryCache = new Map();
function geometry(key, make) {
  if (!geometryCache.has(key)) geometryCache.set(key, make());
  return geometryCache.get(key);
}

function mesh(geo, material, position = [0, 0, 0]) {
  const item = new THREE.Mesh(geo, material);
  item.position.fromArray(position);
  item.castShadow = !material.transparent;
  item.receiveShadow = true;
  return item;
}

export function box(w, h, d, material = materials.ivory, position = [0, 0, 0], radius = 0.05) {
  const r = Math.min(radius, w / 3, h / 3, d / 3);
  return mesh(geometry(`b:${w}:${h}:${d}:${r}`, () => r > 0
    ? new RoundedBoxGeometry(w, h, d, 2, r)
    : new THREE.BoxGeometry(w, h, d)), material, position);
}

export function cylinder(radius, height, material = materials.steel, position = [0, 0, 0], radiusTop = radius, segments = 24) {
  return mesh(geometry(`c:${radius}:${height}:${radiusTop}:${segments}`,
    () => new THREE.CylinderGeometry(radiusTop, radius, height, segments)), material, position);
}

function sphere(radius, material, position, scale = [1, 1, 1]) {
  const item = mesh(geometry(`s:${radius}`, () => new THREE.SphereGeometry(radius, 20, 12)), material, position);
  item.scale.fromArray(scale);
  return item;
}

function torus(radius, tube, material, position = [0, 0, 0], horizontal = false) {
  const item = mesh(geometry(`t:${radius}:${tube}`, () => new THREE.TorusGeometry(radius, tube, 8, 40)), material, position);
  if (horizontal) item.rotation.x = Math.PI / 2;
  return item;
}

function rodBetween(a, b, radius, material = materials.steel) {
  const from = new THREE.Vector3().fromArray(a);
  const to = new THREE.Vector3().fromArray(b);
  const direction = to.clone().sub(from);
  const item = cylinder(radius, direction.length(), material);
  item.position.copy(from.add(to).multiplyScalar(0.5));
  item.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), direction.normalize());
  return item;
}

function group(name, dimensions) {
  const item = new THREE.Group();
  item.name = name;
  item.userData.dimensions = dimensions;
  return item;
}

function addBox(parent, w, h, d, material, x, y, z, radius = 0.05) {
  const item = box(w, h, d, material, [x, y, z], radius);
  parent.add(item);
  return item;
}

function foot(parent, x, z, y = 0.1, size = 0.35) {
  parent.add(box(size, 0.16, size, materials.black, [x, y, z], 0.03));
}

function bolt(parent, x, y, z, size = 0.04, front = false) {
  const item = cylinder(size, 0.024, materials.darkSteel, [x, y, z], size, 6);
  if (front) item.rotation.x = Math.PI / 2;
  parent.add(item);
}

function vent(parent, x, y, z, w = 0.7, h = 0.28, count = 4) {
  addBox(parent, w, h, 0.022, materials.black, x, y, z, 0.025);
  for (let i = 1; i <= count; i += 1) {
    addBox(parent, w * 0.9, 0.022, 0.03, materials.darkSteel,
      x, y - h / 2 + h * i / (count + 1), z + 0.02, 0.005);
  }
}

function status(parent, x, y, z, material = materials.tealLight) {
  const bezel = cylinder(0.073, 0.04, materials.graphite, [x, y, z]);
  bezel.rotation.x = Math.PI / 2;
  parent.add(bezel);
  const light = cylinder(0.043, 0.043, material, [x, y, z + 0.025]);
  light.rotation.x = Math.PI / 2;
  parent.add(light);
  return light;
}

export function makeDocument({ reference = false, kind } = {}) {
  const resolvedKind = kind ?? (reference ? 'data' : 'copy');
  const isToken = resolvedKind === 'job' || resolvedKind === 'error';
  const isData = resolvedKind === 'data';
  const isOriginal = resolvedKind === 'original';
  const w = isToken ? 0.62 : isData ? 0.49 : 1.1;
  const d = isToken ? 0.68 : isData ? 0.68 : 1.5;
  const names = {
    original: 'Documento original', copy: 'Copia exacta', data: 'Datos',
    job: 'Referencia de trabajo', error: 'Referencia con error',
  };
  const item = group(names[resolvedKind] ?? 'Documento', [w, isToken ? 0.24 : 0.055, d]);
  item.userData.kind = resolvedKind;
  item.userData.reference = isData || isToken;
  if (isToken) {
    // A thick reusable carrier with an inset and a physical link symbol has a
    // different silhouette from both the source document and its exact copy.
    const base = addBox(item, w, 0.13, d, materials.graphite, 0, 0.065, 0, 0.07);
    const inset = addBox(item, w * 0.86, 0.053, d * 0.82,
      resolvedKind === 'error' ? materials.error : materials.purple, 0, 0.148, 0, 0.052);
    for (const x of [-w * 0.33, w * 0.33]) {
      addBox(item, 0.061, 0.065, 0.19, materials.steel, x, 0.12, -d * 0.28, 0.014);
    }
    const icon = new THREE.Group();
    icon.position.set(0, 0.202, 0.025);
    if (resolvedKind === 'error') {
      icon.add(rodBetween([-0.105, 0, -0.105], [0.105, 0, 0.105], 0.023, materials.white));
      icon.add(rodBetween([-0.105, 0, 0.105], [0.105, 0, -0.105], 0.023, materials.white));
    } else {
      icon.rotation.y = -Math.PI / 4;
      for (const z of [-0.067, 0.067]) {
        const link = torus(0.071, 0.019, materials.white, [0, 0, z], true);
        link.scale.y = 1.42;
        icon.add(link);
      }
    }
    item.add(icon);
    item.userData.base = base;
    item.userData.folio = inset;
    item.userData.icon = icon;
    return item;
  }
  const base = addBox(item, w, 0.036, d,
    isData ? materials.amber : isOriginal ? materials.sharepoint : materials.white,
    0, 0.018, 0, 0.016);
  addBox(item, w * 0.18, 0.011, d * 0.11, isData || isOriginal ? materials.ivory : materials.teal,
    -w * 0.31, 0.042, -d * 0.31, 0.008);
  const lines = isData ? 3 : 5;
  for (let i = 0; i < lines; i += 1) {
    const length = w * (i === lines - 1 ? 0.43 : 0.68);
    addBox(item, length, 0.008, d * 0.019, isData ? materials.graphite : isOriginal ? materials.sharepointEdge : materials.paperSide,
      -w * 0.34 + length / 2, 0.043, -d * 0.09 + i * d * 0.105, 0);
  }
  item.userData.base = base;
  item.userData.folio = base;
  return item;
}

function paperStack(w, depth, height, { upright = false, tab = true, kind = 'copy' } = {}) {
  const item = new THREE.Group();
  const isOriginal = kind === 'original';
  const base = addBox(item, w, height, depth, isOriginal ? materials.sharepoint : materials.white, 0, height / 2, 0, 0.018);
  if (upright) {
    for (let n = 1; n <= 4; n += 1) {
      addBox(item, 0.008, height * 0.9, 0.018, isOriginal ? materials.sharepointEdge : materials.paperSide,
        -w * 0.4 + w * n / 5, height / 2, depth / 2 + 0.003, 0);
    }
    if (tab) addBox(item, w * 0.68, 0.13, depth * 0.94, materials.teal, 0, height - 0.05, 0, 0.01);
  } else {
    for (let n = 1; n <= 3; n += 1) {
      addBox(item, w * 0.97, 0.011, 0.014, isOriginal ? materials.sharepointEdge : materials.paperSide, 0, height * n / 4, depth / 2 + 0.006, 0);
    }
    if (tab) addBox(item, w * 0.18, 0.016, depth * 0.14, materials.teal,
      -w * 0.29, height + 0.01, -depth * 0.3, 0.005);
  }
  item.userData.kind = kind;
  item.userData.folio = base;
  return item;
}

export function makeArchive() {
  const item = group('SharePoint · archivo de originales', [5, 5, 4]);
  addBox(item, 5, 0.23, 4, materials.darkSteel, 0, 0.115, 0, 0.09);
  addBox(item, 4.75, 1.65, 3.55, materials.teal, 0, 1.05, -0.12, 0.07);
  addBox(item, 2.1, 1.23, 0.07, materials.black, 0, 0.99, 1.69, 0.02);
  addBox(item, 2.45, 0.16, 0.43, materials.steel, 0, 0.4, 1.77, 0.025);
  // Upper archive is open, showing the large retained folios from every angle.
  addBox(item, 4.82, 0.21, 3.58, materials.teal, 0, 2.04, -0.11, 0.025);
  addBox(item, 4.7, 2.8, 0.16, materials.teal, 0, 3.44, -1.81, 0.025);
  for (const x of [-2.25, 2.25]) {
    for (const z of [-1.75, 1.5]) addBox(item, 0.2, 2.75, 0.2, materials.teal, x, 3.47, z, 0.02);
    addBox(item, 0.12, 0.16, 3.45, materials.paleTeal, x, 4.84, -0.12, 0.02);
  }
  for (const z of [-1.75, 1.5]) {
    addBox(item, 4.68, 0.17, 0.17, materials.paleTeal, 0, 4.84, z, 0.02);
    addBox(item, 4.68, 0.11, 0.14, materials.darkSteel, 0, 2.6, z, 0.015);
  }
  const originals = new THREE.Group();
  originals.name = 'Originales conservados';
  for (let i = 0; i < 8; i += 1) {
    const folio = paperStack(0.43, 2.64, 2.4 - (i % 3) * 0.12, { upright: true, kind: 'original' });
    folio.position.set(-1.83 + i * 0.52, 2.16, -0.06);
    originals.add(folio);
  }
  item.add(originals);
  const door = new THREE.Group();
  for (let n = 0; n < 5; n += 1) addBox(door, 2.02, 0.105, 0.12, materials.darkSteel, 0, 1.73 - n * 0.108, 1.75, 0.012);
  item.add(door);
  vent(item, -1.73, 1.0, 1.69, 0.7, 0.58, 6);
  addBox(item, 0.32, 0.64, 0.1, materials.graphite, 1.59, 1.09, 1.73, 0.035);
  status(item, 1.59, 1.22, 1.8);
  status(item, 1.59, 0.99, 1.8, materials.amberLight);
  for (const x of [-2.13, 2.13]) for (const y of [0.44, 1.62]) bolt(item, x, y, 1.69, 0.052, true);
  item.userData.originals = originals;
  item.userData.door = door;
  item.userData.dock = new THREE.Vector3(0, 0.45, 2);
  return item;
}

export function makeWarehouse() {
  const item = group('Blob Storage · copias exactas', [8, 4, 4]);
  addBox(item, 8, 0.18, 4, materials.darkSteel, 0, 0.09, 0, 0.07);
  const copies = new THREE.Group();
  const bays = [-2.53, 0, 2.53];
  // Every pile uses the same 1.1 × 1.5 copy silhouette as the travelling
  // document. Lower sheets are instanced, while the top copy keeps its tab
  // and five ruled lines visible without repeating their draw calls below.
  const pileScale = 1.25;
  const lowerSheets = 8;
  const sheetPitch = 0.058;
  const sheetGeometry = box(1.1, 0.036, 1.5, materials.white, [0, 0, 0], 0.016).geometry;
  const layers = new THREE.InstancedMesh(sheetGeometry, materials.white, 18 * lowerSheets);
  layers.name = 'Hojas de copias exactas';
  layers.castShadow = true;
  layers.receiveShadow = true;
  const sheetTransform = new THREE.Object3D();
  sheetTransform.rotation.y = Math.PI / 2;
  sheetTransform.scale.setScalar(pileScale);
  let sheetIndex = 0;
  for (const x of [-3.75, -1.27, 1.27, 3.75]) {
    for (const z of [-1.6, 1.6]) {
      addBox(item, 0.105, 3.68, 0.105, materials.blue, x, 2.02, z, 0.015);
      foot(item, x, z, 0.23, 0.3);
    }
  }
  for (const x of bays) {
    for (const level of [0.54, 1.59, 2.64]) {
      addBox(item, 2.4, 0.105, 3.2, materials.darkSteel, x, level, 0, 0.015);
      for (const z of [-1.63, 1.63]) addBox(item, 2.43, 0.13, 0.07, materials.amber, x, level - 0.02, z, 0.009);
      for (const z of [-0.78, 0.8]) {
        for (let layer = 0; layer < lowerSheets; layer += 1) {
          sheetTransform.position.set(x, level + 0.07 + (0.018 + layer * sheetPitch) * pileScale, z);
          sheetTransform.updateMatrix();
          layers.setMatrixAt(sheetIndex++, sheetTransform.matrix);
        }
        const topCopy = makeDocument({ kind: 'copy' });
        topCopy.name = 'Documento sobre la pila de copias';
        topCopy.rotation.y = Math.PI / 2;
        topCopy.scale.setScalar(pileScale);
        topCopy.position.set(x, level + 0.07 + lowerSheets * sheetPitch * pileScale, z);
        copies.add(topCopy);
      }
    }
    item.add(rodBetween([x - 1.17, 0.6, -1.66], [x + 1.17, 3.76, -1.66], 0.029, materials.steel));
    item.add(rodBetween([x + 1.17, 0.6, -1.66], [x - 1.17, 3.76, -1.66], 0.029, materials.steel));
  }
  copies.add(layers);
  layers.instanceMatrix.needsUpdate = true;
  item.add(copies);
  item.userData.copies = copies;
  item.userData.copyLayers = layers;
  item.userData.copyPileCount = 18;
  item.userData.documentsPerPile = lowerSheets + 1;
  return item;
}

export function makeMachine() {
  const item = group('Instancia de procesamiento', [2.7, 3.4, 2.8]);
  for (const x of [-1.08, 1.08]) for (const z of [-1.1, 1.1]) foot(item, x, z);
  addBox(item, 2.67, 0.65, 2.72, materials.graphite, 0, 0.49, 0, 0.075);
  addBox(item, 2.5, 0.09, 2.58, materials.steel, 0, 0.85, 0, 0.025);
  addBox(item, 2.17, 0.055, 2.18, materials.teal, 0, 0.93, 0, 0.025);
  addBox(item, 2.28, 2.1, 0.15, materials.teal, 0, 2.02, -1.2, 0.05);
  for (const x of [-1.17, 1.17]) for (const z of [-1.17, 1.17]) {
    addBox(item, 0.235, 2.44, 0.245, materials.ivory, x, 2.07, z, 0.045);
  }
  for (const z of [-1.17, 1.17]) addBox(item, 2.58, 0.255, 0.3, materials.ivory, 0, 3.27, z, 0.045);
  for (const x of [-1.17, 1.17]) addBox(item, 0.28, 0.2, 2.37, materials.ivory, x, 3.27, 0, 0.04);
  // Open front and top reveal the working chamber. Translucent side guards
  // suggest a physical machine without hiding the document and moving head.
  for (const x of [-1.185, 1.185]) addBox(item, 0.018, 1.8, 2.06, materials.glass, x, 2.0, 0, 0);
  for (const x of [-0.82, 0.82]) {
    item.add(cylinder(0.052, 1.93, materials.steel, [x, 2.02, -0.56]));
  }
  addBox(item, 2.04, 0.16, 0.36, materials.amber, 0, 2.94, -0.47, 0.028);
  const head = new THREE.Group();
  head.name = 'Cabezal de procesamiento';
  head.position.set(0, 2.1, -0.12);
  addBox(head, 1.94, 0.16, 0.37, materials.amber, 0, 0.21, -0.44, 0.035);
  addBox(head, 0.38, 0.65, 0.44, materials.amber, 0, -0.01, -0.11, 0.05);
  addBox(head, 0.59, 0.1, 0.62, materials.steel, 0, -0.38, -0.11, 0.025);
  addBox(head, 0.27, 0.11, 0.29, materials.teal, 0, -0.46, -0.11, 0.02);
  // Sliding collars, twin pistons and a geared drive make the gantry legible
  // as a mechanism. Every moving part travels with the existing head hook.
  for (const side of [-1, 1]) {
    addBox(head, 0.23, 0.32, 0.26, materials.graphite, side * 0.82, 0.21, -0.44, 0.03);
    head.add(cylinder(0.087, 0.28, materials.darkSteel, [side * 0.31, 0.1, 0.02]));
    head.add(cylinder(0.042, 0.37, materials.steel, [side * 0.31, -0.19, 0.02]));
    head.add(rodBetween([side * 0.64, 0.2, -0.31], [side * 0.29, -0.27, 0.04], 0.055, materials.amber));
  }
  const drive = cylinder(0.18, 0.49, materials.graphite, [0, 0.45, -0.42]);
  drive.rotation.z = Math.PI / 2;
  head.add(drive);
  for (const x of [-0.255, 0.255]) {
    const cap = cylinder(0.15, 0.04, materials.steel, [x, 0.45, -0.42]);
    cap.rotation.z = Math.PI / 2;
    head.add(cap);
  }
  item.add(head);
  const document = makeDocument();
  document.position.set(0, 0.97, 0.12);
  item.add(document);
  const console = new THREE.Group();
  console.position.set(0, 0.88, 1.35);
  console.rotation.x = -0.28;
  addBox(console, 1.28, 0.08, 0.38, materials.graphite, 0, 0, 0, 0.025);
  addBox(console, 0.77, 0.012, 0.24, materials.screen, -0.11, 0.05, 0, 0.01);
  for (let n = 0; n < 3; n += 1) addBox(console, 0.13, 0.015, 0.1, materials.tealLight, -0.35 + n * 0.19, 0.062, 0, 0.008);
  item.add(console);
  vent(item, 0, 0.44, 1.37, 1.4, 0.28, 4);
  status(item, -0.94, 2.97, 1.34, materials.amberLight);
  const light = status(item, 0.95, 2.97, 1.34);
  for (const x of [-1.16, 1.16]) for (const y of [1.08, 3.23]) bolt(item, x, y, 1.315, 0.047, true);
  item.userData.head = head;
  item.userData.headRest = head.position.clone();
  item.userData.document = document;
  item.userData.light = light;
  return item;
}

export function makeIngester() {
  const item = group('Ingesta · recuperación de la versión exacta', [3, 3.5, 3]);
  addBox(item, 3, 0.18, 3, materials.darkSteel, 0, 0.09, 0, 0.07);
  for (const x of [-1.16, 1.16]) addBox(item, 0.63, 3.21, 2.55, materials.ivory, x, 1.78, -0.05, 0.08);
  addBox(item, 2.97, 0.42, 2.56, materials.ivory, 0, 3.28, -0.05, 0.07);
  addBox(item, 2.03, 0.17, 2.52, materials.teal, 0, 1.01, 0.04, 0.025);
  // The rear panel stops above the transport lane. Both the base document
  // and the copy lifted by 0.12 can leave through a genuine opening at -Z.
  addBox(item, 1.72, 1.33, 0.14, materials.teal, 0, 2.445, -1.28, 0.025);
  addBox(item, 1.53, 1.18, 0.025, materials.glass, 0, 2.41, -1.17, 0);
  for (const x of [-0.826, 0.826]) addBox(item, 0.032, 0.69, 0.19, materials.steel, x, 1.435, -1.28, 0.008);
  addBox(item, 1.62, 0.045, 0.36, materials.steel, 0, 1.258, -1.31, 0.014);
  const rollers = [];
  for (const z of [-0.82, -0.27, 0.28, 0.83, 1.23]) {
    const roller = cylinder(0.103, 1.62, materials.steel, [0, 1.16, z]);
    roller.rotation.z = Math.PI / 2;
    item.add(roller);
    rollers.push(roller);
  }
  const arm = new THREE.Group();
  arm.position.set(0, 2.04, 0.02);
  addBox(arm, 1.64, 0.15, 0.33, materials.steel, 0, 0, 0, 0.024);
  for (const x of [-0.57, 0.57]) {
    item.add(cylinder(0.045, 1.14, materials.darkSteel, [x, 2.36, -0.69]));
    addBox(arm, 0.13, 0.3, 0.57, materials.amber, x, -0.17, -0.16, 0.02);
  }
  item.add(arm);
  const document = makeDocument();
  document.position.set(0, 1.285, 0.33);
  item.add(document);
  status(item, -1.14, 2.71, 1.26, materials.amberLight);
  status(item, -1.14, 2.46, 1.26);
  vent(item, 1.13, 0.77, 1.27, 0.4, 0.64, 7);
  addBox(item, 0.36, 0.53, 0.055, materials.graphite, 1.13, 1.94, 1.27, 0.035);
  addBox(item, 0.23, 0.3, 0.025, materials.tealLight, 1.13, 2.01, 1.308, 0.02);
  item.userData.head = arm;
  item.userData.headRest = arm.position.clone();
  item.userData.rollers = rollers;
  item.userData.document = document;
  item.userData.output = new THREE.Vector3(0, 1.38, -1.5);
  item.userData.outputDirection = new THREE.Vector3(0, 0, -1);
  item.userData.outputClearance = { width: 1.62, bottom: 1.281, top: 1.78, planeZ: -1.28 };
  return item;
}

export function makeQueue() {
  const item = group('Queue Storage · espera de referencias', [2.2, 1.25, 6]);
  const conveyor = makeConveyor([[0, 1.105, -2.96], [0, 1.105, 2.96]], 2.11);
  item.add(conveyor);
  for (const x of [-1.053, 1.053]) {
    addBox(item, 0.086, 0.13, 5.87, materials.purple, x, 1.18, 0, 0.02);
  }
  const slots = [-2.08, -0.7, 0.7, 2.08].map((z) => new THREE.Vector3(0, 1.172, z));
  // Low side markers show the waiting area while keeping the rollers exposed.
  // The scene owns all job carriers, so a stopped or empty queue stays honest.
  for (const slot of slots) {
    for (const x of [-0.895, 0.895]) {
      addBox(item, 0.15, 0.03, 0.54, materials.purpleLight, x, 1.192, slot.z, 0.012);
    }
  }
  item.userData.rollers = conveyor.userData.rollers;
  item.userData.conveyor = conveyor;
  item.userData.waitSlots = slots;
  item.userData.surfaceY = 1.163;
  item.userData.input = new THREE.Vector3(0, 1.172, -3);
  item.userData.output = new THREE.Vector3(0, 1.172, 3);
  return item;
}

export function makeSQL() {
  const item = group('Azure SQL · bóveda de evidencia', [3.4, 4.5, 3.4]);
  const bodyMaterial = materials.steel.clone();
  bodyMaterial.color.setHex(0x92adb7);
  const interiorMaterial = materials.graphite.clone();
  interiorMaterial.color.setHex(0x263c46);
  interiorMaterial.side = THREE.DoubleSide;
  const radius = 1.39;
  const wallBottom = 0.26;
  const wallTop = 3.91;
  const openingRadius = 0.91;
  const openingY = 1.91;
  const frontZ = 1.5;
  item.add(cylinder(1.64, 0.2, materials.graphite, [0, 0.1, 0]));

  // Build the cylindrical shell around a real circular opening. A closed
  // cylinder behind an animated disc would still make every card cross metal.
  const shell = new THREE.Group();
  shell.name = 'Cuerpo hueco de la base de datos';
  const curvedShell = (shellRadius, material, inner = false) => {
    const halfOpeningAngle = Math.asin(openingRadius / shellRadius);
    const back = mesh(new THREE.CylinderGeometry(shellRadius, shellRadius,
      wallTop - wallBottom, 64, 1, true, halfOpeningAngle, Math.PI * 2 - halfOpeningAngle * 2),
    material, [0, (wallBottom + wallTop) / 2, 0]);
    shell.add(back);
    for (const upper of [false, true]) {
      const positions = [];
      const normals = [];
      const indices = [];
      const steps = 48;
      for (let n = 0; n <= steps; n += 1) {
        const angle = -halfOpeningAngle + halfOpeningAngle * 2 * n / steps;
        const x = Math.sin(angle) * shellRadius;
        const z = Math.cos(angle) * shellRadius;
        const halfHeight = Math.sqrt(Math.max(0, openingRadius ** 2 - x ** 2));
        const low = upper ? openingY + halfHeight : wallBottom;
        const high = upper ? wallTop : openingY - halfHeight;
        for (const y of [low, high]) {
          positions.push(x, y, z);
          const sign = inner ? -1 : 1;
          normals.push(Math.sin(angle) * sign, 0, Math.cos(angle) * sign);
        }
        if (n < steps) {
          const a = n * 2;
          if (inner) indices.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
          else indices.push(a, a + 2, a + 1, a + 1, a + 2, a + 3);
        }
      }
      const surface = new THREE.BufferGeometry();
      surface.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
      surface.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
      surface.setIndex(indices);
      shell.add(mesh(surface, material));
    }
  };
  curvedShell(radius, bodyMaterial);
  curvedShell(radius - 0.12, interiorMaterial, true);
  shell.add(cylinder(radius - 0.11, 0.055, interiorMaterial, [0, wallBottom + 0.025, 0]));
  shell.add(cylinder(radius - 0.11, 0.055, interiorMaterial, [0, wallTop - 0.025, 0]));

  // The short circular tunnel joins the curved wall to the planar door jamb.
  const tunnelPositions = [];
  const tunnelIndices = [];
  const tunnelSteps = 64;
  for (let n = 0; n <= tunnelSteps; n += 1) {
    const angle = n * Math.PI * 2 / tunnelSteps;
    const x = Math.sin(angle) * openingRadius;
    const y = openingY + Math.cos(angle) * openingRadius;
    const backZ = Math.sqrt((radius - 0.12) ** 2 - x ** 2);
    tunnelPositions.push(x, y, backZ, x, y, frontZ + 0.025);
    if (n < tunnelSteps) {
      const a = n * 2;
      tunnelIndices.push(a, a + 2, a + 1, a + 1, a + 2, a + 3);
    }
  }
  const tunnelGeometry = new THREE.BufferGeometry();
  tunnelGeometry.setAttribute('position', new THREE.Float32BufferAttribute(tunnelPositions, 3));
  tunnelGeometry.setIndex(tunnelIndices);
  tunnelGeometry.computeVertexNormals();
  const tunnelMaterial = materials.darkSteel.clone();
  tunnelMaterial.side = THREE.DoubleSide;
  shell.add(mesh(tunnelGeometry, tunnelMaterial));
  const jamb = mesh(new THREE.RingGeometry(openingRadius, 1.025, 64), bodyMaterial,
    [0, openingY, frontZ + 0.027]);
  shell.add(jamb);
  shell.add(torus(1.01, 0.032, materials.darkSteel, [0, openingY, frontZ + 0.014]));
  item.add(shell);

  item.add(sphere(1.39, bodyMaterial, [0, 3.83, 0], [1, 0.39, 1]));
  item.add(cylinder(1.0, 0.08, materials.darkSteel, [0, 4.36, 0]));
  item.add(cylinder(0.96, 0.06, bodyMaterial, [0, 4.42, 0]));
  // Horizontal bands recall the conventional database symbol. Any band that
  // meets the opening stops at its edge and never bridges the passage.
  for (const y of [0.32, 0.59, 1.28, 2.5, 3.62, 4.0]) {
    const dy = Math.abs(y - openingY);
    const halfGap = dy < openingRadius
      ? Math.asin(Math.sqrt(openingRadius ** 2 - dy ** 2) / 1.415) + 0.028 : 0;
    if (halfGap === 0) item.add(torus(1.415, 0.032, materials.darkSteel, [0, y, 0], true));
    else {
      const points = [];
      for (let n = 0; n <= 80; n += 1) {
        const angle = halfGap + (Math.PI * 2 - halfGap * 2) * n / 80;
        points.push(new THREE.Vector3(Math.sin(angle) * 1.415, y, Math.cos(angle) * 1.415));
      }
      item.add(mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points), 80, 0.032, 8, false), materials.darkSteel));
    }
  }

  const hinge = new THREE.Group();
  hinge.name = 'Bisagra de la bóveda';
  hinge.position.set(1.02, openingY, frontZ + 0.045);
  const door = new THREE.Group();
  door.name = 'Puerta de Azure SQL';
  door.position.set(-1.02, 0, 0);
  const disc = cylinder(0.971, 0.135, bodyMaterial, [0, 0, 0.07]);
  disc.rotation.x = Math.PI / 2;
  door.add(disc);
  door.add(torus(0.938, 0.028, materials.graphite, [0, 0, 0.15]));
  const innerDisc = cylinder(0.858, 0.032, materials.darkSteel, [0, 0, -0.014]);
  innerDisc.rotation.x = Math.PI / 2;
  door.add(innerDisc);
  const wheel = new THREE.Group();
  wheel.position.z = 0.24;
  wheel.add(torus(0.45, 0.045, materials.darkSteel));
  for (let n = 0; n < 5; n += 1) {
    const a = n * Math.PI * 2 / 5;
    wheel.add(rodBetween([0, 0, 0], [Math.sin(a) * 0.45, Math.cos(a) * 0.45, 0], 0.025, materials.steel));
  }
  const hub = cylinder(0.1, 0.12, materials.darkSteel, [0, 0, 0.045]);
  hub.rotation.x = Math.PI / 2;
  wheel.add(hub);
  door.add(wheel);
  for (const y of [-0.5, 0.5]) {
    const bearing = cylinder(0.09, 0.32, materials.darkSteel, [1.02, openingY + y, frontZ + 0.045]);
    item.add(bearing);
    addBox(door, 0.18, 0.22, 0.12, materials.darkSteel, 0.952, y, 0.066, 0.025);
  }
  hinge.add(door);
  item.add(hinge);
  for (let n = 0; n < 12; n += 1) {
    const angle = n * Math.PI / 6;
    bolt(item, Math.cos(angle) * 1.47, 0.218, Math.sin(angle) * 1.47, 0.056);
  }
  item.userData.shell = shell;
  item.userData.door = door;
  item.userData.doorHinge = hinge;
  item.userData.wheel = wheel;
  item.userData.doorOpen = 0;
  item.userData.entryOutside = new THREE.Vector3(0, openingY, 2.65);
  item.userData.entryThreshold = new THREE.Vector3(0, openingY, frontZ + 0.04);
  item.userData.entryInside = new THREE.Vector3(0, openingY, 0);
  item.userData.openingRadius = openingRadius;
  item.userData.setDoorOpen = (amount) => {
    const value = Number.isFinite(amount) ? THREE.MathUtils.clamp(amount, 0, 1) : 0;
    hinge.rotation.y = value * Math.PI * 2 / 3;
    wheel.rotation.z = value * Math.PI * 0.42;
    item.userData.doorOpen = value;
  };
  return item;
}

function documentCrate() {
  const item = new THREE.Group();
  addBox(item, 0.79, 0.46, 0.68, materials.ivory, 0, 0.23, 0, 0.03);
  const folio = addBox(item, 0.57, 0.35, 0.51, materials.sharepoint, 0, 0.55, 0, 0.013);
  addBox(item, 0.64, 0.17, 0.025, materials.teal, 0, 0.26, 0.35, 0.015);
  for (let n = 0; n < 4; n += 1) addBox(item, 0.56, 0.008, 0.014, materials.sharepointEdge, 0, 0.45 + n * 0.055, 0.263, 0);
  item.userData.kind = 'original';
  item.userData.folio = folio;
  return item;
}

export function makeVan({ truck = false } = {}) {
  const length = truck ? 7 : 4.5;
  const item = group(truck ? 'Camión de campaña' : 'Llegada de documentación', [2.2, truck ? 2.8 : 2.2, length]);
  const front = length / 2;
  const cabZ = front - 0.91;
  const cargoLength = length - 1.73;
  const cargoZ = -0.83;
  const cargoHeight = truck ? 1.98 : 1.47;
  addBox(item, 2.12, 0.21, length - 0.13, materials.graphite, 0, 0.5, 0, 0.075);
  addBox(item, 2.06, 0.2, cargoLength, materials.ivory, 0, 0.7, cargoZ, 0.045);
  for (const x of [-0.97, 0.97]) addBox(item, 0.12, cargoHeight, cargoLength, materials.ivory, x, 0.76 + cargoHeight / 2, cargoZ, 0.045);
  const roof = addBox(item, 2.08, 0.13, cargoLength, materials.ivory, 0, 0.77 + cargoHeight, cargoZ, 0.06);
  for (const x of [-0.6, -0.2, 0.2, 0.6]) addBox(item, 0.017, 0.016, cargoLength * 0.89, materials.paperSide, x, 0.85 + cargoHeight, cargoZ, 0.005);
  addBox(item, 1.92, 1.48, 0.11, materials.ivory, 0, 1.45, cabZ - 0.64, 0.04);
  addBox(item, 2.03, 1.43, 1.68, materials.ivory, 0, 1.3, cabZ, 0.15);
  addBox(item, 1.72, 0.6, 0.05, materials.screen, 0, 1.62, front - 0.035, 0.1);
  for (const x of [-1.02, 1.02]) {
    addBox(item, 0.027, 0.55, 0.88, materials.screen, x, 1.63, cabZ + 0.13, 0.045);
    addBox(item, 0.032, 0.08, 0.2, materials.darkSteel, x * 1.016, 1.19, cabZ - 0.17, 0.02);
    addBox(item, 0.21, 0.14, 0.3, materials.graphite, x * 1.115, 1.52, cabZ + 0.6, 0.04);
    addBox(item, 0.035, 0.17, cargoLength * 0.88, materials.teal, x, 1.17, cargoZ, 0.015);
  }
  addBox(item, 1.45, 0.13, 0.06, materials.graphite, 0, 0.93, front + 0.005, 0.025);
  addBox(item, 2.1, 0.14, 0.15, materials.darkSteel, 0, 0.66, front - 0.01, 0.03);
  for (const x of [-0.74, 0.74]) {
    addBox(item, 0.3, 0.19, 0.07, materials.white, x, 1.05, front + 0.013, 0.025);
    addBox(item, 0.09, 0.15, 0.08, materials.amberLight, x * 1.18, 1.05, front + 0.022, 0.02);
    addBox(item, 0.15, 0.27, 0.08, materials.red, x * 1.24, 0.95, -front - 0.003, 0.023);
  }
  const wheels = [];
  const wheelRadius = truck ? 0.42 : 0.36;
  const axles = truck ? [front - 1.0, -front + 0.63, -front + 1.53] : [front - 0.81, -front + 0.78];
  for (const z of axles) {
    for (const x of [-1.065, 1.065]) {
      const tire = cylinder(wheelRadius, 0.22, materials.rubber, [x, wheelRadius, z]);
      tire.rotation.z = Math.PI / 2;
      item.add(tire);
      wheels.push(tire);
      const hub = cylinder(truck ? 0.24 : 0.2, 0.23, materials.steel, [x * 1.012, wheelRadius, z]);
      hub.rotation.z = Math.PI / 2;
      item.add(hub);
      const center = cylinder(0.078, 0.242, materials.graphite, [x * 1.023, wheelRadius, z], 0.078, 6);
      center.rotation.z = Math.PI / 2;
      item.add(center);
    }
  }
  const doors = [];
  for (const side of [-1, 1]) {
    const door = new THREE.Group();
    door.position.set(side * 0.99, 0.8 + cargoHeight / 2, -front + 0.06);
    addBox(door, 0.96, cargoHeight - 0.08, 0.08, materials.ivory, -side * 0.48, 0, 0, 0.04);
    addBox(door, 0.08, 0.28, 0.075, materials.graphite, -side * 0.81, -0.1, -0.075, 0.02);
    addBox(door, 0.032, cargoHeight * 0.83, 0.04, materials.steel, -side * 0.3, 0, -0.055, 0.01);
    item.add(door);
    doors.push(door);
  }
  const cargo = new THREE.Group();
  cargo.name = 'Cajas de documentos';
  cargo.userData.kind = 'original';
  const rows = truck ? 4 : 2;
  for (let n = 0; n < rows; n += 1) for (const x of [-0.45, 0.45]) {
    const crate = documentCrate();
    crate.position.set(x, 0.82, -front + 0.6 + n * 0.78);
    cargo.add(crate);
    if (truck) {
      const upper = documentCrate();
      upper.position.set(x, 1.55, -front + 0.6 + n * 0.78);
      cargo.add(upper);
    }
  }
  item.add(cargo);
  item.userData.wheels = wheels;
  item.userData.doors = doors;
  item.userData.roof = roof;
  item.userData.cargo = cargo;
  return item;
}

function limb(length, radius, material, position, rotation = 0) {
  const item = mesh(geometry(`capsule:${radius}:${length}`, () => new THREE.CapsuleGeometry(radius, Math.max(0.01, length - 2 * radius), 4, 8)), material, position);
  item.rotation.z = rotation;
  return item;
}

export function makeHuman({ document = false, identified = true, color, bodyColor = color, bodyMaterial, tool = false } = {}) {
  const item = group('Validador humano', [tool === 'clipboard' ? 0.76 : tool ? 0.7 : 0.65, 1.5, 0.6]);
  const garment = bodyMaterial?.isMaterial ? bodyMaterial
    : bodyColor == null ? materials.teal : materials.teal.clone();
  if (!bodyMaterial?.isMaterial && bodyColor != null) garment.color.set(bodyColor);
  item.add(sphere(0.174, materials.ivory, [0, 1.326, 0], [0.94, 1, 0.94]));
  const body = limb(0.53, 0.14, garment, [0, 0.92, 0]);
  item.add(body);
  const legs = [];
  const feet = [];
  for (const x of [-0.097, 0.097]) {
    const leg = new THREE.Group();
    leg.name = x < 0 ? 'Pierna izquierda' : 'Pierna derecha';
    leg.position.set(x, 0.67, 0);
    leg.add(limb(0.63, 0.067, materials.graphite, [0, -0.315, 0]));
    const foot = new THREE.Group();
    foot.position.set(0, -0.626, 0);
    addBox(foot, 0.14, 0.087, 0.25, materials.black, 0, 0, 0.065, 0.035);
    leg.add(foot);
    item.add(leg);
    legs.push(leg);
    feet.push(foot);
  }
  for (const x of [-0.225, 0.225]) {
    const arm = limb(0.46, 0.057, garment, [x, 0.88, document ? 0.13 : 0], x < 0 ? -0.14 : 0.14);
    if (document) arm.rotation.x = -0.32;
    item.add(arm);
    item.add(sphere(0.061, materials.ivory, [x, 0.66, document ? 0.2 : 0]));
  }
  const badge = addBox(item, 0.095, 0.15, 0.022, materials.white, -0.065, 1.005, 0.144, 0.011);
  addBox(badge, 0.05, 0.036, 0.012, materials.azure, 0, 0.035, 0.016, 0.006);
  badge.visible = identified;
  const paper = makeDocument({ kind: 'original' });
  paper.rotation.x = Math.PI / 2;
  paper.scale.setScalar(0.59);
  paper.position.set(0, 0.91, 0.28);
  paper.visible = document;
  item.add(paper);
  let accessory = null;
  if (tool) {
    accessory = new THREE.Group();
    accessory.name = tool === 'clipboard' ? 'Tablilla de ingeniería' : 'Llave de ingeniería';
    accessory.position.set(0.255, 0.69, 0.09);
    accessory.rotation.z = -0.22;
    if (tool === 'clipboard') {
      addBox(accessory, 0.27, 0.36, 0.035, materials.graphite, 0, 0, 0, 0.025);
      addBox(accessory, 0.22, 0.27, 0.018, materials.blue, 0, -0.014, 0.027, 0.014);
      addBox(accessory, 0.12, 0.035, 0.05, materials.steel, 0, 0.157, 0.025, 0.009);
      addBox(accessory, 0.12, 0.013, 0.013, materials.paleTeal, -0.013, 0.038, 0.044, 0.002);
      addBox(accessory, 0.013, 0.088, 0.013, materials.paleTeal, 0.04, 0, 0.044, 0.002);
      addBox(accessory, 0.12, 0.013, 0.013, materials.paleTeal, -0.013, -0.045, 0.044, 0.002);
    } else {
      addBox(accessory, 0.048, 0.25, 0.035, materials.steel, 0, -0.015, 0, 0.015);
      addBox(accessory, 0.13, 0.037, 0.035, materials.steel, 0, 0.12, 0, 0.009);
      for (const x of [-0.054, 0.054]) addBox(accessory, 0.032, 0.083, 0.035, materials.steel, x, 0.155, 0, 0.01);
      accessory.add(torus(0.055, 0.017, materials.steel, [0, -0.18, 0]));
    }
    item.add(accessory);
  }
  item.userData.document = paper;
  item.userData.legs = legs;
  item.userData.feet = feet;
  item.userData.setStride = angle => {
    legs.forEach((leg, i) => {
      leg.rotation.x = i === 0 ? angle : -angle;
      // Keep each sole level as the straight leg swings from the hip.
      feet[i].rotation.x = -leg.rotation.x;
    });
  };
  item.userData.badge = badge;
  item.userData.identified = identified;
  item.userData.body = body;
  item.userData.bodyMaterial = garment;
  item.userData.tool = accessory;
  return item;
}

function monitor(width, height, x, y, z, form = false) {
  const item = new THREE.Group();
  item.position.set(x, y, z);
  addBox(item, width, height, 0.095, materials.graphite, 0, 0, 0, 0.055);
  addBox(item, width * 0.91, height * 0.84, 0.012, materials.white, 0, 0.017, 0.055, 0.025);
  if (form) {
    for (let n = 0; n < 3; n += 1) {
      addBox(item, width * 0.62, height * 0.15, 0.016, n === 2 ? materials.paleTeal : materials.paperSide,
        width * 0.03, height * 0.23 - n * height * 0.23, 0.068, 0.012);
    }
    addBox(item, width * 0.11, height * 0.67, 0.016, materials.teal, -width * 0.37, 0.01, 0.07, 0.013);
  } else {
    addBox(item, width * 0.2, height * 0.13, 0.012, materials.teal, -width * 0.22, height * 0.23, 0.071, 0.01);
    for (let n = 0; n < 4; n += 1) addBox(item, width * 0.61, 0.023, 0.016, materials.paperSide, 0, height * 0.03 - n * 0.1, 0.07, 0.002);
  }
  return item;
}

export function makeReview() {
  const item = group('Poste de revisión humana', [4, 2.6, 3]);
  addBox(item, 3.75, 0.11, 1.46, materials.ivory, 0, 1.18, -0.49, 0.065);
  for (const x of [-1.5, 1.5]) for (const z of [-1.03, 0.05]) {
    addBox(item, 0.11, 1.12, 0.11, materials.darkSteel, x, 0.6, z, 0.018);
  }
  addBox(item, 0.7, 0.92, 1.2, materials.graphite, -1.21, 0.68, -0.49, 0.04);
  for (const y of [0.57, 0.9]) {
    addBox(item, 0.59, 0.24, 0.04, materials.darkSteel, -1.21, y, 0.122, 0.015);
    addBox(item, 0.23, 0.032, 0.04, materials.steel, -1.21, y + 0.04, 0.15, 0.01);
  }
  for (const x of [-0.81, 0.78]) {
    addBox(item, 0.42, 0.045, 0.38, materials.graphite, x, 1.275, -0.59, 0.02);
    addBox(item, 0.08, 0.4, 0.07, materials.darkSteel, x, 1.44, -0.66, 0.01);
  }
  const originalScreen = monitor(1.32, 1.0, -0.81, 2.01, -0.68);
  const reviewScreen = monitor(1.32, 1.0, 0.78, 2.01, -0.68, true);
  item.add(originalScreen, reviewScreen);
  addBox(item, 1.0, 0.027, 0.34, materials.graphite, 0.18, 1.26, -0.06, 0.022);
  for (let row = 0; row < 3; row += 1) addBox(item, 0.87, 0.017, 0.026, materials.steel, 0.18, 1.281, -0.16 + row * 0.09, 0.003);
  const human = makeHuman();
  human.position.set(0.18, 0.14, 0.94);
  human.scale.setScalar(1.25);
  human.rotation.y = Math.PI;
  item.add(human);
  const chair = new THREE.Group();
  chair.name = 'Silla del verificador';
  chair.position.set(0.18, 0, 0.94);
  chair.scale.setScalar(1.25);
  addBox(chair, 0.59, 0.13, 0.54, materials.graphite, 0, 0.52, 0, 0.07);
  addBox(chair, 0.55, 0.52, 0.11, materials.teal, 0, 0.92, 0.25, 0.065);
  chair.add(cylinder(0.07, 0.43, materials.steel, [0, 0.265, 0]));
  for (let n = 0; n < 5; n += 1) {
    const a = n * Math.PI * 2 / 5;
    chair.add(rodBetween([0, 0.13, 0], [Math.sin(a) * 0.41, 0.07, Math.cos(a) * 0.41], 0.035, materials.darkSteel));
  }
  item.add(chair);
  item.userData.human = human;
  item.userData.chair = chair;
  item.userData.originalScreen = originalScreen;
  item.userData.reviewScreen = reviewScreen;
  return item;
}

export function makeGate() {
  const item = group('Entra ID · acceso e identidad', [3, 3, 2]);
  const archMaterial = materials.ivory.clone();
  const archRestColor = archMaterial.color.getHex();
  const arch = [];
  addBox(item, 3, 0.13, 2, materials.darkSteel, 0, 0.065, 0, 0.065);
  for (const x of [-1.24, 1.24]) arch.push(addBox(item, 0.44, 2.77, 0.52, archMaterial, x, 1.5, -0.3, 0.07));
  arch.push(addBox(item, 2.97, 0.53, 0.56, archMaterial, 0, 2.73, -0.3, 0.07));
  const diamond = addBox(item, 0.35, 0.35, 0.065, materials.azure, 0, 2.73, 0.02, 0.02);
  diamond.rotation.z = Math.PI / 4;
  item.userData.symbol = diamond;
  // Each gate owns its indicator material. Granting access cannot illuminate
  // unrelated machines that use the shared palette elsewhere in the scene.
  const lightMaterial = materials.accessLight.clone();
  lightMaterial.color.setHex(0x365c50);
  lightMaterial.emissive.setHex(0x000000);
  lightMaterial.emissiveIntensity = 0;
  const lights = [];
  const flaps = [];
  const flapWidth = 0.525;
  const hingeX = 0.5295;
  const flapMaterial = materials.glass.clone();
  flapMaterial.opacity = 0.43;
  for (const x of [-0.71, 0.71]) {
    addBox(item, 0.38, 1.13, 1.09, materials.graphite, x, 0.71, 0.14, 0.075);
    addBox(item, 0.4, 0.055, 1.05, materials.steel, x, 1.305, 0.14, 0.035);
    const side = Math.sign(x);
    const flap = addBox(item, flapWidth, 0.58, 0.035, flapMaterial, side * (hingeX - flapWidth / 2), 1.03, 0.18, 0.015);
    for (const edge of [-1, 1]) addBox(flap, 0.015, 0.55, 0.035, materials.steel, edge * (flapWidth / 2 - 0.009), 0, 0, 0.004);
    addBox(flap, flapWidth - 0.026, 0.014, 0.035, materials.steel, 0, 0.279, 0, 0.004);
    flap.userData.side = Math.sign(x);
    flap.userData.hingeX = side * hingeX;
    flap.userData.closedPosition = flap.position.clone();
    flap.userData.openPosition = new THREE.Vector3(side * hingeX, 1.03, 0.18 + flapWidth / 2);
    flaps.push(flap);
    lights.push(addBox(item, 0.18, 0.025, 0.24, lightMaterial, x, 1.34, 0.49, 0.017));
  }
  const card = new THREE.Group();
  card.position.set(1.08, 1.46, 0.81);
  card.rotation.z = -0.1;
  addBox(card, 0.72, 1.0, 0.065, materials.white, 0, 0, 0, 0.06);
  addBox(card, 0.2, 0.07, 0.014, materials.graphite, 0, 0.4, 0.042, 0.015);
  card.add(sphere(0.096, materials.teal, [-0.13, 0.15, 0.048], [1, 1, 0.15]));
  addBox(card, 0.24, 0.2, 0.017, materials.teal, -0.13, -0.04, 0.047, 0.035);
  for (let n = 0; n < 2; n += 1) addBox(card, 0.43, 0.04, 0.017, materials.paperSide, 0, -0.23 - n * 0.1, 0.047, 0.005);
  item.add(card);
  item.userData.card = card;
  item.userData.lights = lights;
  item.userData.flaps = flaps;
  item.userData.flapMaterial = flapMaterial;
  item.userData.arch = arch;
  item.userData.archMaterial = archMaterial;
  item.userData.lightMaterial = lightMaterial;
  item.userData.lightStates = {
    idle: { color: 0x365c50, emissive: 0x000000, emissiveIntensity: 0 },
    granted: { color: 0x70deab, emissive: 0x20a86d, emissiveIntensity: 0.65 },
  };
  item.userData.setAccess = (granted, openAmount = granted ? 1 : 0) => {
    const amount = Number.isFinite(openAmount) ? THREE.MathUtils.clamp(openAmount, 0, 1) : granted ? 1 : 0;
    const state = item.userData.lightStates[granted ? 'granted' : 'idle'];
    lightMaterial.color.setHex(state.color);
    lightMaterial.emissive.setHex(state.emissive);
    lightMaterial.emissiveIntensity = state.emissiveIntensity;
    archMaterial.color.setHex(granted ? 0x39bc86 : archRestColor);
    archMaterial.emissive.setHex(granted ? 0x166149 : 0x000000);
    archMaterial.emissiveIntensity = granted ? 0.08 : 0;
    const angle = amount * Math.PI / 2;
    for (const flap of flaps) {
      flap.position.set(flap.userData.side * (hingeX - flapWidth / 2 * Math.cos(angle)), 1.03,
        0.18 + flapWidth / 2 * Math.sin(angle));
      flap.rotation.y = flap.userData.side * angle;
    }
    item.userData.authorized = Boolean(granted);
    item.userData.openAmount = amount;
  };
  item.userData.authorized = false;
  item.userData.openAmount = 0;
  return item;
}

export function makeApi() {
  const item = group('API Python · interfaz de negocio', [2.5, 3, 2.5]);
  addBox(item, 2.5, 0.18, 2.5, materials.graphite, 0, 0.09, 0, 0.07);
  addBox(item, 2.16, 2.4, 1.74, materials.graphite, 0, 1.5, -0.08, 0.075);
  for (const x of [-1.04, 1.04]) addBox(item, 0.17, 2.67, 1.95, materials.ivory, x, 1.58, -0.04, 0.05);
  addBox(item, 2.34, 0.19, 1.97, materials.teal, 0, 2.89, -0.04, 0.065);
  for (let row = 0; row < 3; row += 1) {
    const y = 0.73 + row * 0.72;
    addBox(item, 1.93, 0.55, 0.09, materials.steel, 0, y, 0.84, 0.03);
    addBox(item, 1.4, 0.26, 0.028, materials.black, -0.05, y + 0.01, 0.907, 0.018);
    for (let port = 0; port < 4; port += 1) {
      addBox(item, 0.2, 0.155, 0.025, materials.teal, -0.54 + port * 0.31, y + 0.01, 0.934, 0.018);
      addBox(item, 0.08, 0.024, 0.013, materials.amber, -0.54 + port * 0.31, y - 0.1, 0.943, 0.003);
    }
    status(item, 0.8, y + 0.02, 0.917);
  }
  for (const x of [-0.74, 0.74]) {
    const socket = cylinder(0.19, 0.075, materials.amber, [x, 0.38, 0.9]);
    socket.rotation.x = Math.PI / 2;
    item.add(socket);
  }
  return item;
}

export function makeGraph() {
  const item = group('Microsoft Graph · mostrador de consulta', [2.5, 3, 2.5]);
  // A light consultation bridge, deliberately distinct from the enclosed API
  // rack. The shallow side trays are transient exchange points, not storage.
  addBox(item, 2.44, 0.15, 2.1, materials.darkSteel, 0, 0.075, 0, 0.075);
  for (const x of [-0.72, 0.72]) {
    const leg = addBox(item, 0.17, 1.23, 0.62, materials.teal, x, 0.77, -0.22, 0.03);
    leg.rotation.z = -x * 0.15;
    addBox(item, 0.48, 0.085, 1.53, materials.graphite, x, 0.19, -0.04, 0.04);
    item.add(rodBetween([x, 0.39, -0.55], [x, 1.24, 0.48], 0.047, materials.steel));
  }
  addBox(item, 2.39, 0.16, 1.28, materials.teal, 0, 1.41, 0, 0.065);
  addBox(item, 1.24, 0.055, 1.02, materials.darkSteel, 0, 1.522, -0.04, 0.045);
  const trays = [];
  for (const side of [-1, 1]) {
    const tray = new THREE.Group();
    tray.name = side < 0 ? 'Consulta saliente' : 'Respuesta de Graph';
    tray.position.set(side * 0.9, 1.38, 0.21);
    tray.rotation.z = -side * 0.035;
    addBox(tray, 0.69, 0.052, 1.42, materials.steel, 0, 0, 0, 0.025);
    for (const x of [-0.322, 0.322]) addBox(tray, 0.038, 0.13, 1.39, materials.teal, x, 0.053, 0, 0.015);
    addBox(tray, 0.65, 0.13, 0.035, materials.teal, 0, 0.053, -0.7, 0.012);
    addBox(tray, 0.25, 0.014, 0.035, materials.paleTeal, 0, 0.04, 0.65, 0.004);
    item.add(tray);
    trays.push(tray);
  }
  const screen = new THREE.Group();
  screen.position.set(0, 2.045, -0.16);
  screen.rotation.x = -0.13;
  addBox(screen, 1.42, 0.91, 0.11, materials.teal, 0, 0, 0, 0.065);
  addBox(screen, 1.26, 0.73, 0.02, materials.screen, 0, 0.01, 0.068, 0.035);
  // Three large connected nodes communicate a lookup without miniature text.
  const nodes = [[-0.34, -0.13, 0.105], [0, 0.2, 0.105], [0.34, -0.13, 0.105]];
  const symbol = new THREE.Group();
  symbol.name = 'Símbolo de consulta de Graph';
  for (const [a, b] of [[0, 1], [1, 2], [0, 2]]) symbol.add(rodBetween(nodes[a], nodes[b], 0.012, materials.paleTeal));
  for (const pos of nodes) symbol.add(sphere(0.075, materials.tealLight, pos, [1, 1, 0.22]));
  screen.add(symbol);
  item.userData.symbol = symbol;
  item.add(screen);
  addBox(item, 0.17, 0.68, 0.16, materials.darkSteel, 0, 1.77, -0.3, 0.025);
  // The short rear aerial and its open braces give a readable silhouette.
  const antenna = new THREE.Group();
  antenna.position.set(0, 1.49, -0.69);
  antenna.add(cylinder(0.048, 1.16, materials.steel, [0, 0.65, 0]));
  antenna.add(sphere(0.085, materials.paleTeal, [0, 1.31, 0]));
  antenna.add(torus(0.115, 0.018, materials.teal, [0, 1.16, 0]));
  antenna.add(rodBetween([-0.31, 0, 0.03], [0, 0.68, 0], 0.025, materials.steel));
  antenna.add(rodBetween([0.31, 0, 0.03], [0, 0.68, 0], 0.025, materials.steel));
  item.add(antenna);
  // An exposed U-shaped cable conduit and a service handle add small physical
  // cues while retaining the open, desk-like shape of the Graph intermediary.
  const cableCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(-0.44, 1.35, -0.59), new THREE.Vector3(-0.44, 0.6, -0.68),
    new THREE.Vector3(0.43, 0.44, -0.68), new THREE.Vector3(0.43, 1.35, -0.59),
  ]);
  item.add(mesh(new THREE.TubeGeometry(cableCurve, 18, 0.029, 6, false), materials.graphite));
  for (const x of [-0.15, 0.15]) item.add(rodBetween([x, 1.405, 0.67], [x, 1.405, 0.78], 0.027, materials.steel));
  item.add(rodBetween([-0.15, 1.405, 0.78], [0.15, 1.405, 0.78], 0.027, materials.steel));
  const light = status(item, 0.45, 1.412, 0.664);
  item.userData.queryTray = trays[0];
  item.userData.responseTray = trays[1];
  item.userData.screen = screen;
  item.userData.antenna = antenna;
  item.userData.light = light;
  return item;
}

export function makeConveyor(points, width = 1) {
  const item = group('Cinta de transporte de documentos', null);
  item.userData.points = points.map((point) => [...point]);
  const rollers = [];
  for (let segment = 0; segment < points.length - 1; segment += 1) {
    const a = new THREE.Vector3().fromArray(points[segment]);
    const b = new THREE.Vector3().fromArray(points[segment + 1]);
    const length = Math.hypot(b.x - a.x, b.z - a.z);
    if (length < 0.05) continue;
    const section = new THREE.Group();
    section.position.copy(a.clone().add(b).multiplyScalar(0.5));
    section.rotation.y = Math.atan2(b.x - a.x, b.z - a.z);
    const slope = (b.y - a.y) / length;
    for (const side of [-1, 1]) {
      const rail = addBox(section, 0.082, 0.16, length + 0.08, materials.darkSteel, side * width / 2, -0.03, 0, 0.015);
      rail.rotation.x = -Math.atan(slope);
      const guard = addBox(section, 0.048, 0.07, length + 0.08, materials.steel, side * width / 2, 0.105, 0, 0.011);
      guard.rotation.x = -Math.atan(slope);
    }
    const count = Math.max(2, Math.ceil(length / 0.29));
    for (let n = 0; n < count; n += 1) {
      const z = -length / 2 + length * (n + 0.5) / count;
      const roller = cylinder(0.085, width * 0.92, n % 4 === 0 ? materials.darkSteel : materials.steel,
        [0, z * slope - 0.027, z], 0.085, 12);
      roller.rotation.z = Math.PI / 2;
      section.add(roller);
      rollers.push(roller);
    }
    const supports = Math.max(2, Math.ceil(length / 2.4));
    for (let n = 0; n < supports; n += 1) {
      const z = -length / 2 + length * (n + 0.18) / Math.max(1, supports - 0.64);
      const top = section.position.y + z * slope - 0.13;
      if (top > 0.1) {
        for (const x of [-width * 0.36, width * 0.36]) {
          addBox(section, 0.09, top, 0.09, materials.graphite, x, top / 2 - section.position.y, z, 0.01);
          addBox(section, 0.25, 0.065, 0.24, materials.black, x, 0.032 - section.position.y, z, 0.018);
        }
        addBox(section, width * 0.79, 0.08, 0.1, materials.darkSteel, 0, -0.15 + z * slope, z, 0.013);
      }
    }
    item.add(section);
  }
  item.userData.rollers = rollers;
  return item;
}
