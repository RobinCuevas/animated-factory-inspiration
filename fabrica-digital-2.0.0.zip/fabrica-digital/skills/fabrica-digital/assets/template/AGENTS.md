# Trabajar en esta fábrica

Este proyecto explica una arquitectura mediante una fábrica 3D. La prioridad es que el público entienda las responsabilidades, el flujo y sus estados. La configuración inicial y el portal ficticio son un ejemplo, no requisitos del próximo cliente.

Lee `README.md`, `docs/new-project-brief.md` y `docs/reuse-guide.md` antes de adaptar el caso. Comprueba el código actual antes de asumir que el ejemplo conserva su estructura original.

- Configura la identidad en `src/project.js`. No copies marcas, contratos, documentos o notas de otro proyecto.
- Sintetiza primero componentes y conexiones. Distingue arquitectura documentada, elección de representación y decisión pendiente, sin llenar el relato público de notas internas.
- Adapta arquitectura, guion y escena juntos. Un cambio de nombre no convierte un servicio en otro con funciones distintas.
- Reutiliza `kit/`, `shared/` y los controles existentes. Crea cada instancia articulada mediante su API. No clones un grupo con pivotes ni modifiques materiales globales compartidos.
- La animación depende del tiempo del relato. Cada muestreo restablece estados de forma determinista para permitir avance, retroceso y exportación. La cámara usa tiempo real independiente.
- Conserva la identidad del documento móvil. Una copia, una referencia o un resultado nuevo necesitan significado visible. No mantengas folios o bandejas incorporados en un modelo si duplican el objeto que viaja.
- La plataforma del suelo representa un ámbito lógico. No equivale automáticamente a tenant, suscripción, VNet o subred.
- Usa datos sintéticos. Guarda las fuentes privadas fuera de `public/`. La web entregada no debe incluir rutas locales ni instrucciones de agentes.
- Usa `scripts/factory.mjs` para mantener runtime, dependencias, capturas y vídeo fuera del proyecto. No asumas que hay un repositorio Git.
- Verifica el comportamiento cambiado, el recorrido en panorámico y estrecho, la navegación por pasos y el seek inverso. Una comprobación local no equivale a publicación ni validación de la arquitectura.

Los recorridos de IA, agentes, seguridad y escalabilidad son opcionales. No conviertas una metáfora, una propuesta o un escenario ilustrado en una garantía real. Una visualización no autoriza despliegues, gastos, publicaciones ni cambios en sistemas externos.
