import assert from 'node:assert/strict';
import * as THREE from 'three';
import { createQualityGate } from './index.js';

function pose(asset) {
  asset.object.updateMatrixWorld(true);
  const nodes = [];
  asset.object.traverse(node => {
    assert(node.matrixWorld.elements.every(Number.isFinite));
    const paints = node.material ? (Array.isArray(node.material) ? node.material : [node.material]) : [];
    nodes.push({ visible: node.visible, matrix: [...node.matrixWorld.elements],
      colors: paints.map(paint => [paint.color?.getHex(), paint.emissive?.getHex(), paint.emissiveIntensity]) });
  });
  return nodes;
}

const asset = createQualityGate();
asset.object.position.set(4, 0, -2);
asset.object.rotation.y = Math.PI / 2;
asset.object.scale.setScalar(1.25);
const first = asset.update(4.5);
const expected = pose(asset);
asset.update(9.5, { result: 'review' });
assert.deepEqual(asset.update(4.5), first);
assert.deepEqual(pose(asset), expected, 'Seek debe restaurar también luces y materiales');
assert.deepEqual(asset.object.position.toArray(), [4, 0, -2]);
assert.equal(asset.object.rotation.y, Math.PI / 2);
assert.equal(asset.object.scale.x, 1.25);

const intake = asset.update(1, { progress: .15 });
assert.equal(intake.status, 'arriving');
assert(intake.tokenPosition[0] < 0);
assert.equal(intake.inspecting, false);
const rollerAxes = new Map();
asset.object.traverse(node => {
  if (node.name.startsWith('Rodillo')) rollerAxes.set(node, new THREE.Vector3(0, 1, 0).applyQuaternion(node.quaternion));
});
const inspection = asset.update(0, { progress: .45 });
assert.deepEqual(inspection.tokenPosition, [0, 1.205, 0]);
assert.equal(inspection.inspecting, true);
assert.equal(inspection.moving, false);
const accepted = asset.update(0, { progress: .95, result: 'accepted' });
assert.deepEqual(accepted.tokenPosition, asset.object.userData.anchors.output.toArray());
assert.equal(accepted.delivered, true);
const review = asset.update(0, { progress: .95, result: 'review' });
assert.deepEqual(review.tokenPosition, asset.object.userData.anchors.review.toArray());
assert.equal(review.delivered, true);
assert.equal(asset.update(0, { progress: 1, result: 'review' }).visible, true, 'El resultado de la entrega queda visible');
for (const [roller, axis] of rollerAxes) {
  assert(new THREE.Vector3(0, 1, 0).applyQuaternion(roller.quaternion).distanceTo(axis) < 1e-12, 'El rodillo gira sin inclinar su eje');
}
assert.equal(asset.object.userData.parts.document.children.find(node => node.visible).userData.kind, 'copy');
assert.equal(asset.update(0, { progress: .45, present: false }).inspecting, false);

const other = createQualityGate({ theme: 'amber', laneWidth: 2.5 });
other.update(0, { progress: .95, result: 'accepted' });
const otherPose = pose(other);
asset.update(0, { progress: .95, result: 'review' });
assert.deepEqual(pose(other), otherPose, 'Una instancia no modifica la otra');
const childDocument = asset.object.userData.parts.document;
const ownResources = new Set();
asset.object.traverse(node => {
  let parent = node, belongsToDocument = false;
  while (parent) { if (parent === childDocument) belongsToDocument = true; parent = parent.parent; }
  if (!belongsToDocument) {
    if (node.geometry) ownResources.add(node.geometry);
    if (node.material) ownResources.add(node.material);
  }
});
let disposedCount = 0;
for (const resource of ownResources) resource.addEventListener('dispose', () => disposedCount++);
asset.dispose(); asset.dispose();
assert.equal(disposedCount, ownResources.size, 'Cada recurso propio se libera una vez');
assert.deepEqual(pose(other), otherPose);
other.update(4.5);
other.dispose();
assert.throws(() => asset.update(0), /liberado/);

const external = createQualityGate({ demoDocument: false });
assert.equal(external.object.userData.parts.document, null);
assert.equal(external.update(4.5).inspecting, false);
assert.equal(external.update(4.5, { present: true }).inspecting, true);
const bounds = new THREE.Box3();
for (const progress of [0, .15, .45, .7, .85, .95]) {
  external.update(0, { progress, present: true, result: 'review' });
  external.object.updateMatrixWorld(true);
  bounds.union(new THREE.Box3().setFromObject(external.object));
}
assert(!bounds.isEmpty());
assert([...bounds.min, ...bounds.max].every(Number.isFinite));
external.dispose();
assert.throws(() => createQualityGate({ laneWidth: .5 }), /laneWidth/);
assert.throws(() => createQualityGate({ cycleDuration: 0 }), /cycleDuration/);

console.log(JSON.stringify({ status: 'PASS', checks: [
  'Seek reversible incluyendo luces, pose y transformación exterior',
  'Entrada, inspección detenida y dos salidas causales',
  'La copia conserva su identidad en el desvío a revisión',
  'Instancias independientes y liberación exacta de recursos propios',
  'Modo sin documento interno y volumen de encuadre válido',
] }, null, 2));
