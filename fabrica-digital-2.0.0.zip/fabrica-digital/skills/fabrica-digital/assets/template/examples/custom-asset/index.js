import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { createAsset, THEMES, smooth, phase } from '../../kit/index.js';

export const QUALITY_GATE = Object.freeze({
  id: 'quality-gate',
  title: 'Control de calidad',
  description: 'Una copia entra, se detiene bajo un lector y continúa o pasa a revisión.',
  meaning: 'Un control decide el recorrido de la misma copia. El resultado lo define la composición, no un análisis real del documento.',
  states: ['progress', 'result', 'active', 'present'],
  duration: 10,
});

/** New geometry, without modifying the preserved models. All geometry and
 * material caches below belong to one instance, making ownership explicit. */
export function createQualityGate(options = {}) {
  const laneWidth = options.laneWidth ?? 2;
  const cycleDuration = options.cycleDuration ?? QUALITY_GATE.duration;
  if (!Number.isFinite(laneWidth) || laneWidth < 1.8 || laneWidth > 3) {
    throw new RangeError('laneWidth debe estar entre 1.8 y 3.');
  }
  if (!Number.isFinite(cycleDuration) || cycleDuration <= 0) {
    throw new RangeError('cycleDuration debe ser un número positivo.');
  }
  const theme = THEMES[options.theme ?? 'neutral'];
  if (!theme) throw new RangeError('Tema desconocido.');
  const palette = { ivory: 0xe7e2d7, graphite: 0x293437, steel: 0xa9b2b0,
    accent: theme.accent, soft: theme.soft, ...options.palette };
  for (const value of Object.values(palette)) {
    if (!Number.isInteger(value) || value < 0 || value > 0xffffff) {
      throw new RangeError('Cada color de palette debe ser un entero hexadecimal RGB.');
    }
  }

  const object = new THREE.Group();
  object.name = QUALITY_GATE.title;
  object.userData.assetId = QUALITY_GATE.id;
  object.userData.meaning = QUALITY_GATE.meaning;
  const geometries = new Map(), ownedMaterials = new Set();
  const material = (color, roughness = .46, metalness = .18) => {
    const value = new THREE.MeshStandardMaterial({ color, roughness, metalness });
    ownedMaterials.add(value);
    return value;
  };
  const paints = {
    ivory: material(palette.ivory), graphite: material(palette.graphite, .38, .5),
    steel: material(palette.steel, .27, .8), accent: material(palette.accent, .38, .35),
    soft: material(palette.soft), indicator: material(0x6b7773),
    scan: material(0x9eddd0, .4),
  };
  paints.scan.emissive.setHex(0x52b0a8);
  paints.scan.emissiveIntensity = .5;
  const geometry = (key, make) => {
    if (!geometries.has(key)) geometries.set(key, make());
    return geometries.get(key);
  };
  const mesh = (parent, shape, paint, position) => {
    const value = new THREE.Mesh(shape, paint);
    value.position.fromArray(position);
    value.castShadow = true;
    value.receiveShadow = true;
    parent.add(value);
    return value;
  };
  const box = (parent, size, paint, position = [0, 0, 0], radius = .04) => {
    const r = Math.min(radius, ...size.map(value => value / 3));
    return mesh(parent, geometry(`box:${size}:${r}`, () => new RoundedBoxGeometry(...size, 2, r)), paint, position);
  };
  const cylinder = (parent, radius, length, paint, position) => mesh(parent,
    geometry(`cylinder:${radius}:${length}`, () => new THREE.CylinderGeometry(radius, radius, length, 20)), paint, position);

  const surfaceY = 1.18, tokenY = 1.205;
  const input = new THREE.Vector3(-3.2, tokenY, 0);
  const output = new THREE.Vector3(3.2, tokenY, 0);
  const review = new THREE.Vector3(1.6, tokenY, 2.9);
  object.userData.anchors = { input, inspect: new THREE.Vector3(0, tokenY, 0), output, review };
  object.userData.dimensions = [6.65, 3.07, 4.65 + (laneWidth - 2) / 2];

  // Main lane travels along X. The branch opens on +Z, so a diverted copy
  // crosses an actual opening instead of passing through a guard rail.
  box(object, [6.55, .22, laneWidth + .08], paints.graphite, [0, .95, 0]);
  box(object, [laneWidth + .08, .22, 2.9 - laneWidth / 2], paints.graphite,
    [1.6, .95, (2.9 + laneWidth / 2) / 2]);
  for (const [x, z] of [[-2.6, -.68], [-2.6, .68], [2.6, -.68], [2.6, .68], [.94, 2.5], [2.26, 2.5]]) {
    box(object, [.12, .87, .12], paints.graphite, [x, .435, z]);
    box(object, [.34, .11, .34], paints.graphite, [x, .055, z], .025);
  }
  const rollers = [];
  for (let i = 0; i < 23; i++) {
    const roller = cylinder(object, .075, laneWidth - .07, paints.steel, [-3.1 + i * 6.2 / 22, surfaceY - .075, 0]);
    roller.rotation.x = Math.PI / 2;
    roller.name = 'Rodillo de entrada';
    rollers.push({ object: roller, rest: roller.quaternion.clone(), branch: false });
  }
  for (let z = laneWidth / 2 + .16; z < 2.86; z += .27) {
    const roller = cylinder(object, .075, laneWidth - .07, paints.steel, [1.6, surfaceY - .075, z]);
    roller.rotation.z = Math.PI / 2;
    roller.name = 'Rodillo de desvío';
    rollers.push({ object: roller, rest: roller.quaternion.clone(), branch: true });
  }
  box(object, [6.5, .12, .075], paints.accent, [0, 1.115, -laneWidth / 2 - .025], .014);
  const openingLeft = 1.6 - laneWidth / 2, openingRight = 1.6 + laneWidth / 2;
  for (const [a, b] of [[-3.25, openingLeft], [openingRight, 3.25]]) {
    box(object, [b - a, .12, .075], paints.accent, [(a + b) / 2, 1.115, laneWidth / 2 + .025], .014);
  }
  for (const x of [openingLeft - .025, openingRight + .025]) {
    box(object, [.075, .12, 2.9 - laneWidth / 2], paints.accent,
      [x, 1.115, (2.9 + laneWidth / 2) / 2], .014);
  }

  // A broad, open gantry shows the sheet and the reader. Structural pieces
  // have visible supports. The light stripe is the only unsupported element.
  for (const z of [-laneWidth / 2 - .26, laneWidth / 2 + .26]) {
    box(object, [.35, 2.8, .35], paints.ivory, [0, 1.4, z], .06);
    box(object, [.62, .13, .62], paints.graphite, [0, .065, z]);
  }
  box(object, [1.85, .26, laneWidth + .85], paints.ivory, [0, 2.8, 0], .06);
  for (const z of [-.48, .48]) {
    const rail = cylinder(object, .045, 1.64, paints.steel, [0, 2.49, z]);
    rail.rotation.z = Math.PI / 2;
    for (const x of [-.76, .76]) box(object, [.17, .19, .17], paints.graphite, [x, 2.57, z]);
  }
  const reader = new THREE.Group();
  reader.name = 'Lector móvil';
  reader.position.set(-.45, 2.05, 0);
  object.add(reader);
  for (const z of [-.48, .48]) box(reader, [.26, .42, .2], paints.steel, [0, .3, z]);
  box(reader, [.7, .28, laneWidth - .32], paints.accent);
  box(reader, [.52, .06, laneWidth - .47], paints.graphite, [0, -.17, 0]);
  box(reader, [.12, .02, laneWidth - .65], paints.soft, [0, -.209, 0], .008);
  const scanLine = box(object, [.022, .006, 1.35], paints.scan, [-.45, tokenY + .055, 0], .002);
  scanLine.name = 'Luz de inspección';
  scanLine.castShadow = false;
  const beacon = cylinder(object, .12, .13, paints.indicator, [0, 3.005, -laneWidth / 2 - .26]);
  beacon.name = 'Resultado del control';

  const demoDocument = options.demoDocument !== false;
  let document = demoDocument ? createAsset('document', { kind: 'copy' }) : null;
  if (document) object.add(document.object);
  object.userData.parts = { reader, scanLine, beacon, document: document?.object ?? null };
  const spin = new THREE.Quaternion(), localRollerAxis = new THREE.Vector3(0, 1, 0);
  let disposed = false;

  function update(timeSeconds, state = {}) {
    if (disposed) throw new Error('Este asset ya ha sido liberado.');
    const t = Number.isFinite(timeSeconds) ? timeSeconds : 0;
    const active = state.active ?? options.active ?? true;
    const present = state.present ?? options.present ?? demoDocument;
    const progress = state.progress ?? phase(t, cycleDuration) / cycleDuration;
    if (!Number.isFinite(progress)) throw new RangeError('progress debe ser finito.');
    const p = active ? THREE.MathUtils.clamp(progress, 0, 1) : 0;
    const result = state.result ?? options.result ?? 'accepted';
    if (!['accepted', 'review'].includes(result)) throw new RangeError('result debe ser accepted o review.');
    const inspecting = Boolean(active && present && p >= .3 && p < .59);
    const decided = Boolean(active && present && p >= .59);
    const scanProgress = smooth(.31, .56, p) * (1 - smooth(.65, .82, p));
    reader.position.x = -.45 + .9 * (active && present ? scanProgress : 0);
    scanLine.position.x = reader.position.x;
    scanLine.visible = inspecting;
    const lampColor = inspecting ? 0xdb9a30 : decided ? (result === 'accepted' ? 0x52b0a8 : 0xce4148) : 0x6b7773;
    paints.indicator.color.setHex(lampColor);
    paints.indicator.emissive.setHex(inspecting || decided ? lampColor : 0);
    paints.indicator.emissiveIntensity = inspecting || decided ? .25 : 0;

    const tokenPosition = input.clone();
    tokenPosition.x = THREE.MathUtils.lerp(input.x, 0, smooth(.04, .28, p));
    if (p >= .6) {
      if (result === 'accepted') tokenPosition.x = output.x * smooth(.6, .94, p);
      else {
        tokenPosition.x = review.x * smooth(.6, .74, p);
        tokenPosition.z = review.z * smooth(.74, .94, p);
      }
    }
    // Hold the delivered sheet at its exit until the scene takes ownership
    // or the demonstration restarts, so completion has a visible result.
    const visible = Boolean(active && present && p >= .04);
    if (document) {
      document.object.visible = visible;
      document.object.position.copy(tokenPosition);
      document.update(t, { kind: 'copy' });
    }
    const moving = Boolean(active && present && ((p > .04 && p < .28) || (p > .6 && p < .94)));
    for (const roller of rollers) {
      // Rotation depends on path distance, not an accumulated frame delta.
      // Multiply by a local cylinder-axis rotation so different lane
      // orientations do not make the rollers tilt when they spin.
      const angle = roller.branch ? tokenPosition.z / .075 : tokenPosition.x / .075;
      spin.setFromAxisAngle(localRollerAxis, angle);
      roller.object.quaternion.copy(roller.rest).multiply(spin);
    }
    const status = !active || !present ? 'idle' : p < .04 ? 'waiting' : p < .28 ? 'arriving'
      : p < .6 ? 'inspecting' : p < .94 ? 'departing' : 'complete';
    const snapshot = { id: QUALITY_GATE.id, time: t, progress: p, result, status,
      active: Boolean(active), present: Boolean(present), visible, inspecting, moving,
      delivered: Boolean(active && present && p >= .94), tokenPosition: tokenPosition.toArray() };
    object.userData.state = snapshot;
    return snapshot;
  }

  function dispose() {
    if (disposed) return;
    disposed = true;
    object.removeFromParent();
    document?.dispose();
    document = null;
    for (const paint of ownedMaterials) paint.dispose();
    for (const shape of geometries.values()) shape.dispose();
    ownedMaterials.clear(); geometries.clear();
    object.clear();
    delete object.userData.parts;
    object.userData.anchors = {};
  }
  try { update(0); } catch (error) { dispose(); throw error; }
  return { object, update, dispose };
}
