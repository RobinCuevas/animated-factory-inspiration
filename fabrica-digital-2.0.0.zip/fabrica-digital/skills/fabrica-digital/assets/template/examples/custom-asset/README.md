# Ejemplo: control de calidad

Una pieza nueva construida con cajas redondeadas, cilindros y un lector móvil. Una copia blanca entra, se detiene para la inspección y continúa o se desvía a revisión conservando su identidad. Usa el mismo contrato que el kit y puede añadirse a una arquitectura junto a cualquiera de sus figuras.

Abre la [vista interactiva](../../custom-asset.html) desde el servidor local. La [guía de creación](../../docs/creating-assets.md) explica decisiones de forma, materiales, pivotes, anclajes y pruebas.

```js
import { createQualityGate } from './examples/custom-asset/index.js';

const quality = createQualityGate({ theme: 'neutral' });
scene.add(quality.object);
quality.object.position.set(4, 0, -2);

quality.update(4.5); // Copia detenida y lector activo
quality.update(0, { progress: .85, result: 'review' });
quality.dispose();
```

`createQualityGate(options)` devuelve `{object, update, dispose}`. `QUALITY_GATE` exporta `{id, title, description, meaning, states, duration}` y sirve como descripción para una vista o registro local. La pieza no se añade automáticamente a `ASSETS`.

| Opción | Valor por defecto | Uso |
| --- | --- | --- |
| `theme` | `neutral` | `neutral`, `azure`, `amber` o `blue` |
| `laneWidth` | `2` | Ancho entre 1,8 y 3 unidades |
| `cycleDuration` | `10` | Duración positiva del bucle en segundos |
| `palette` | Colores del tema | Overrides numéricos RGB para `ivory`, `graphite`, `steel`, `accent`, `soft` |
| `demoDocument` | `true` | Incluye una copia del kit para inspeccionar el ejemplo aislado |
| `result` | `accepted` | Resultado inicial de la coreografía |
| `active` | `true` | Activa el ciclo |
| `present` | Igual que `demoDocument` | Indica si existe una copia para inspeccionar |

`update(timeSeconds, state)` acepta `progress` (0–1), `result` (`accepted` o `review`), `active` y `present`. Omitir `progress` vuelve al tiempo cíclico. Los estados suministrados prevalecen sobre las opciones iniciales. El resultado es una elección de la escena, no el resultado de un análisis real.

El snapshot devuelve fase, progreso, resultado, presencia, movimiento, inspección, entrega y posición local de la copia. Se recalcula desde cero en cada llamada. No conserva una cola de trabajos ni emite eventos externos.

Con progreso manual 1, la copia permanece visible en la salida para mostrar el resultado. La composición decide cuándo tomarla para el siguiente paso o reiniciar otro trabajo.

Para una composición que controla su propio documento:

```js
const quality = createQualityGate({ demoDocument: false });
scene.add(quality.object);

// La composición posee y mueve la copia que realmente llega a la máquina.
const state = quality.update(time, {
  progress: progressOfThisJob,
  present: true,
  result: 'accepted',
});
const point = quality.object.localToWorld(
  new THREE.Vector3().fromArray(state.tokenPosition),
);
document.object.position.copy(point); // Documento hijo de scene
```

Los anclajes `input`, `inspect`, `output` y `review` están en `quality.object.userData.anchors` y son locales. Y apunta hacia arriba. El recorrido principal es −X → +X y el desvío va hacia +Z. Las dimensiones en `userData` son orientativas. La vista debe encuadrar el volumen de ambas rutas mediante `Box3`.

La máquina posee sus geometrías y materiales. El documento incluido posee sus recursos a través del kit. `dispose()` libera ambos ámbitos de forma independiente y es idempotente. No modifica materiales globales ni geometrías de `kit/models.js`.

Desde la raíz del proyecto, con Node y pnpm disponibles:

```sh
export FACTORY_CACHE_DIR="$HOME/.cache/fabrica-digital/custom-asset"
node scripts/factory.mjs prepare
node "$FACTORY_CACHE_DIR/workspace/examples/custom-asset/check.mjs"
```

La comprobación no escribe archivos. Verifica reversibilidad de poses y luces, secuencia de entrada e inspección, salidas, identidad de la copia, independencia de instancias y liberación de recursos. El render en escritorio y móvil se comprueba en la vista interactiva.
