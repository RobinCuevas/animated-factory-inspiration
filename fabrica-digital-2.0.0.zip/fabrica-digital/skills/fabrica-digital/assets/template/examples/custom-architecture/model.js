/** A small, independent document workflow. IDs are arbitrary, not scene keywords.
 * Use PROJECT.recipe = 'custom' to run this model. Durations are story seconds.
 * focusEntry is a zero-based step index used when Next enters another section.
 * Direct section selection still starts at its first step.
 */
const detail = {
  evidence: 'Ejemplo ilustrativo',
  source: 'Datos sintéticos, sin conexión a sistemas reales.',
  choice: 'Una posible composición de servicios para explicar este recorrido.',
  pending: 'Servicios, contratos y permisos de la arquitectura real.',
  network: 'El plano representa funciones. No delimita redes ni subredes.',
};

export const CUSTOM = {
  title: 'De una solicitud a su respuesta',
  nodes: [
    {
      ...detail, id: 'request', label: 'Puesto de solicitudes', service: 'Aplicación del usuario',
      asset: 'review', position: [-8, 0, 4], scope: 'user',
      receives: 'Respuestas y confirmaciones de sus operaciones.',
      does: 'Permite iniciar una solicitud y consultar su resultado.',
      sends: 'Solicitudes vinculadas a la cuenta autorizada.',
    },
    {
      ...detail, id: 'processor', label: 'Gestión de solicitudes', service: 'Azure Container Apps',
      asset: 'processor', position: [0, 0, 0], scope: 'factory', icon: './brand/azure-backend.svg',
      receives: 'Solicitudes y consultas con su contexto de usuario.',
      does: 'Comprueba los permisos y coordina el registro y la lectura de archivos.',
      sends: 'Operaciones de datos y respuestas para el usuario.',
    },
    {
      ...detail, id: 'records', label: 'Registro de solicitudes', service: 'Azure SQL Database',
      asset: 'database', position: [8, 0, -4], scope: 'factory', icon: './brand/azure-sql.svg',
      receives: 'La información que debe conservarse sobre cada solicitud.',
      does: 'Registra sus datos y permite recuperar su estado.',
      sends: 'Confirmaciones de registro y resultados de consulta.',
    },
    {
      ...detail, id: 'archive', label: 'Archivo de documentos', service: 'Azure Blob Storage',
      asset: 'object-store', position: [8, 0, 5], scope: 'factory', icon: './brand/azure-blob.svg',
      receives: 'Lecturas autorizadas de documentos.',
      does: 'Conserva los archivos con sus permisos de acceso.',
      sends: 'El contenido solicitado al servicio de aplicación.',
    },
  ],
  edges: [
    {id: 'request-processor', from: 'request', to: 'processor', label: 'Solicitud y respuesta', kind: 'request'},
    {id: 'processor-records', from: 'processor', to: 'records', label: 'Registrar y consultar', kind: 'read'},
    {id: 'processor-archive', from: 'processor', to: 'archive', label: 'Lectura autorizada', kind: 'read'},
  ],
  scenarios: [
    {
      id: 'register', tokenId: 'S-001', label: 'Registrar', summary: 'Una solicitud se registra y vuelve una confirmación.', focusEntry: 2,
      steps: [
        {duration: 2, title: 'Una solicitud pone en marcha el recorrido.', copy: 'Una persona pide registrar una nueva solicitud. Seguiremos la operación hasta que vuelva su confirmación.', from: 'request', to: 'request', insight: [{label: 'Entrada', value: 'Solicitud sintética S-001'}]},
        {duration: 2, title: 'La solicitud llega al servicio.', copy: 'La aplicación entrega la solicitud y el contexto de la cuenta que la inicia.', from: 'request', to: 'processor'},
        {duration: 3, title: 'El servicio comprueba lo necesario.', copy: 'Comprueba el permiso y prepara la información que debe quedar registrada.', from: 'processor', to: 'processor', work: ['processor']},
        {duration: 2, title: 'Los datos llegan a su registro.', copy: 'El servicio solicita guardar la información de la solicitud en Azure SQL Database.', from: 'processor', to: 'records'},
        {duration: 2.5, title: 'La base confirma el registro.', copy: 'El resultado de la operación indica que la solicitud ya puede recuperarse por su identificador.', from: 'records', to: 'records', insight: [{label: 'Estado', value: 'Registrada'}, {label: 'Identificador', value: 'S-001'}]},
        {duration: 2, title: 'Vuelve la confirmación al servicio.', copy: 'La respuesta de la base permite comunicar el resultado al usuario.', from: 'records', to: 'processor'},
        {duration: 2, title: 'La respuesta llega a la persona.', copy: 'El usuario recibe la confirmación y el identificador con el que podrá consultar su solicitud.', from: 'processor', to: 'request'},
        {duration: 2, title: 'La operación tiene un resultado visible.', copy: 'La solicitud queda registrada. La siguiente consulta podrá utilizar ese identificador.', from: 'request', to: 'request', insight: [{label: 'Resultado', value: 'Confirmación recibida'}]},
      ],
    },
    {
      id: 'read-file', tokenId: 'DOC-001', label: 'Consultar un archivo', summary: 'El mismo servicio entrega un documento a quien tiene permiso.', focusEntry: 2,
      steps: [
        {duration: 2, title: 'El usuario quiere abrir un documento.', copy: 'Solicita un documento de ejemplo relacionado con su trabajo.', from: 'request', to: 'request'},
        {duration: 2, title: 'La consulta llega al servicio.', copy: 'La aplicación envía la referencia del archivo y la identidad del usuario.', from: 'request', to: 'processor'},
        {duration: 3, title: 'Se comprueba el permiso de lectura.', copy: 'Conocer la referencia de un archivo no concede acceso. El servicio comprueba si esa cuenta puede consultarlo.', from: 'processor', to: 'processor', work: ['processor']},
        {duration: 2, title: 'El servicio pide el archivo.', copy: 'La referencia permite localizar el documento en Azure Blob Storage.', from: 'processor', to: 'archive'},
        {duration: 2.5, title: 'El almacén responde a la lectura.', copy: 'La lectura recupera el contenido del archivo. Consultarlo no es una operación de borrado.', from: 'archive', to: 'archive', insight: [{label: 'Operación', value: 'Lectura autorizada'}]},
        {duration: 2, title: 'El contenido vuelve al servicio.', copy: 'El servicio recibe el archivo y prepara la respuesta para quien lo ha solicitado.', from: 'archive', to: 'processor'},
        {duration: 2, title: 'El documento llega al usuario.', copy: 'La persona puede consultar el contenido que su cuenta tiene permiso para ver.', from: 'processor', to: 'request'},
        {duration: 2, title: 'El archivo sigue disponible.', copy: 'Leer el documento no lo retira del almacén. Otras consultas autorizadas podrán recuperarlo después.', from: 'request', to: 'request', insight: [{label: 'Resultado', value: 'Documento consultado'}, {label: 'Original', value: 'Conservado'}]},
      ],
    },
  ],
};
