import http from 'node:http';
import {readFile,stat} from 'node:fs/promises';
import {resolve,extname,sep} from 'node:path';

export async function startServer(directory,port=0){
  const root=resolve(directory);
  const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.webp':'image/webp','.ttf':'font/ttf','.png':'image/png','.json':'application/json','.md':'text/plain; charset=utf-8'};
  const server=http.createServer(async(req,res)=>{
    try{
      const pathname=decodeURIComponent(new URL(req.url,'http://127.0.0.1').pathname);
      const target=resolve(root,'.'+(pathname.endsWith('/')?pathname+'index.html':pathname));
      if(!target.startsWith(root+sep)){res.writeHead(403);res.end();return}
      const file=await stat(target);if(!file.isFile())throw new Error('Not a file');
      res.writeHead(200,{'Content-Type':mime[extname(target)]||'application/octet-stream','Content-Length':file.size,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
      res.end(req.method==='HEAD'?undefined:await readFile(target));
    }catch{res.writeHead(404);res.end('Archivo no encontrado')}
  });
  await new Promise((done,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',done)});
  return server;
}
