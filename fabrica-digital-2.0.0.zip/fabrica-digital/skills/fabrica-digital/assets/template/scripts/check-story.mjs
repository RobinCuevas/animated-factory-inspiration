import {PROJECT} from '../src/project.js';

// Validate the recipe that the project actually renders. An inactive example
// must not be treated as proof that a different architecture works.
if (PROJECT.recipe === 'commerce') await import('./check-commerce.mjs');
else if (PROJECT.recipe === 'custom') await import('./check-custom.mjs');
else throw new Error('PROJECT.recipe debe ser commerce o custom.');
