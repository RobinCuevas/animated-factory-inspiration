import {mkdir,writeFile,rename,rm} from 'node:fs/promises';
import {dirname,basename,join} from 'node:path';
import {randomUUID,createHash} from 'node:crypto';
import {createReadStream} from 'node:fs';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {chromium} from 'playwright';
import {PROJECT} from '../src/project.js';

const url=new URL(process.env.FACTORY_URL),output=process.env.FACTORY_OUTPUT;
const scenario=process.env.FACTORY_SCENARIO||'consultation';
const width=Number(process.env.FACTORY_WIDTH||1920),height=width*9/16,fps=Number(process.env.FACTORY_FPS||24),scale=width>1920?2:1;
if(!output||![1920,3840].includes(width)||!Number.isInteger(fps)||fps<1||fps>60)throw new Error('Configuración de vídeo no válida.');
url.search=new URLSearchParams({scenario,entry:'full',capture:'1',t:'0'}).toString();
await mkdir(dirname(output),{recursive:true});
const temporary=join(dirname(output),`.${basename(output)}.${randomUUID()}.partial.mp4`),receipt=temporary+'.json';
const errors=[],external=[];
let browser,encoder,decoder;
async function launch(args,stdio){
  const child=spawn(process.env.FACTORY_FFMPEG||'ffmpeg',args,{stdio});
  const done=new Promise(resolve=>{child.once('error',error=>resolve({error:String(error)}));child.once('close',code=>resolve({code}));});
  await new Promise((resolve,reject)=>{child.once('spawn',resolve);child.once('error',reject);});
  return {child,done};
}
async function stop(handle){if(handle&&handle.child.exitCode===null){handle.child.kill('SIGTERM');const timer=setTimeout(()=>handle.child.kill('SIGKILL'),3000);await handle.done;clearTimeout(timer);}}
try{
  browser=await chromium.launch({headless:true,args:process.platform==='darwin'?['--use-angle=metal']:[]});
  const context=await browser.newContext({viewport:{width:width/scale,height:height/scale},deviceScaleFactor:scale});
  await context.route('**/*',route=>{if(new URL(route.request().url()).origin!==url.origin){external.push(route.request().url());return route.abort();}return route.continue();});
  const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));page.on('response',r=>{if(r.status()>=400)errors.push(`${r.status()} ${r.url()}`);});
  await page.goto(url.href);await page.waitForFunction(()=>window.factoryAPI?.ready);await page.evaluate(()=>document.fonts.ready);
  const initial=await page.evaluate(()=>window.factoryAPI.inspect());
  if(initial.scenario!==scenario)throw new Error('El recorrido solicitado no está habilitado.');
  // Texture decoding is asynchronous, even when all assets are local.
  await page.waitForTimeout(600);
  const rate=scenario==='pentest'?PROJECT.playback.pentestSpeed:PROJECT.playback.defaultSpeed;
  const duration=initial.duration/rate,end=Math.min(duration,Number(process.env.FACTORY_DURATION||duration));
  if(!Number.isFinite(end)||end<=0)throw new Error('Duración de vídeo no válida.');
  const frames=Math.ceil(end*fps);
  encoder=await launch(['-hide_banner','-loglevel','error','-y','-f','image2pipe','-vcodec','png','-framerate',String(fps),'-i','pipe:0','-an','-c:v','libx264','-preset','medium','-crf','17','-pix_fmt','yuv420p','-movflags','+faststart',temporary],['pipe','inherit','inherit']);
  let pipeError;encoder.child.stdin.on('error',e=>{pipeError=e;});
  for(let frame=0;frame<frames;frame++){
    if(pipeError)throw pipeError;
    const seconds=frame/fps;
    await page.evaluate(({time,seconds})=>window.factoryAPI.capture(time,seconds),{time:Math.min(initial.duration,seconds*rate),seconds});
    const png=await page.screenshot({type:'png'});
    if(frame===0&&(png.readUInt32BE(16)!==width||png.readUInt32BE(20)!==height))throw new Error('Resolución de captura incorrecta.');
    if(!encoder.child.stdin.write(png))await once(encoder.child.stdin,'drain');
    if(frame%(fps*5)===0)console.log(`${frame}/${frames} fotogramas`);
  }
  encoder.child.stdin.end();const result=await encoder.done;
  if(result.error||result.code!==0||errors.length||external.length)throw new Error(JSON.stringify({result,errors,external}));
  decoder=await launch(['-hide_banner','-loglevel','error','-i',temporary,'-f','null','-'],'inherit');
  const decoded=await decoder.done;if(decoded.error||decoded.code!==0)throw new Error('El vídeo no pasa la decodificación.');
  const hash=createHash('sha256');for await(const chunk of createReadStream(temporary))hash.update(chunk);
  await writeFile(receipt,JSON.stringify({scenario,width,height,fps,frames,seconds:end,speed:rate,decode:true,sha256:hash.digest('hex')},null,2)+'\n');
  await rename(temporary,output);await rename(receipt,output+'.json');
  console.log(`Vídeo verificado: ${output}`);
}finally{await stop(encoder);await stop(decoder);await browser?.close();await rm(temporary,{force:true});await rm(receipt,{force:true});}
