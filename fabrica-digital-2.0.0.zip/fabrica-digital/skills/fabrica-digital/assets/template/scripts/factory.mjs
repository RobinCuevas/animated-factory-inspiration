import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {mkdir,cp,readFile,writeFile,access,rm,realpath} from 'node:fs/promises';
import {dirname,resolve,join,basename,relative,isAbsolute} from 'node:path';
import {fileURLToPath} from 'node:url';
import {homedir} from 'node:os';
import {spawn} from 'node:child_process';
import {startServer} from './serve.mjs';

const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const key=createHash('sha256').update(root).digest('hex').slice(0,12);
const runtime=resolve(process.env.FACTORY_CACHE_DIR||join(homedir(),'.cache','fabrica-digital',key));
const workspace=join(runtime,'workspace'),output=join(runtime,'output');
const command=process.argv[2]||'help',args=process.argv.slice(3);
const port=Number(process.env.FACTORY_PORT||4245);
const env={...process.env,PATH:dirname(process.execPath)+(process.platform==='win32'?';':':')+(process.env.PATH||'')};
const exists=async p=>{try{await access(p);return true}catch{return false}};
const inside=(parent,child)=>{const p=relative(parent,child);return p===''||(!p.startsWith('..')&&!isAbsolute(p));};
async function canonical(path){try{return await realpath(path)}catch(e){if(e.code!=='ENOENT')throw e;return join(await canonical(dirname(path)),basename(path));}}
function run(exe,argv,options={}){
  return new Promise((done,reject)=>{
    const child=spawn(exe,argv,{cwd:workspace,env,stdio:'inherit',...options});
    child.once('error',reject);
    child.once('exit',(code,signal)=>code===0?done():reject(new Error(`${basename(exe)} terminó con ${signal||code}`)));
  });
}
async function prepare(){
  // Never mirror a project into itself or leave dependencies in a synced tree.
  if(inside(await canonical(root),await canonical(runtime)))throw new Error('FACTORY_CACHE_DIR debe estar fuera del proyecto.');
  await mkdir(workspace,{recursive:true});await mkdir(output,{recursive:true});
  const inputs=['package.json','pnpm-lock.yaml','vite.config.mjs','index.html','catalog.html','connections.html','custom-asset.html','custom-asset-viewer.js','src','shared','kit','catalog','connections','examples','public','scripts'];
  for(const name of inputs){
    await rm(join(workspace,name),{recursive:true,force:true});
    if(await exists(join(root,name)))await cp(join(root,name),join(workspace,name),{recursive:true,filter:p=>!['node_modules','.DS_Store','.runtime'].includes(basename(p))});
  }
  const lock=await readFile(join(root,'pnpm-lock.yaml'));
  const hash=createHash('sha256').update(lock).digest('hex'),stamp=join(runtime,'dependencies.sha256');
  if(!await exists(stamp)||(await readFile(stamp,'utf8')).trim()!==hash||!await exists(join(workspace,'node_modules/vite'))){
    console.log('Preparando dependencias fuera del proyecto…');
    await run(process.platform==='win32'?'pnpm.cmd':'pnpm',['install','--frozen-lockfile','--ignore-scripts'],{shell:process.platform==='win32'});
    await writeFile(stamp,hash+'\n');
  }
  return createRequire(join(workspace,'package.json'));
}
async function build(){
  const require=await prepare();
  await run(process.execPath,[join(dirname(require.resolve('vite/package.json')),'bin/vite.js'),'build']);
  console.log(`Web estática: ${join(workspace,'dist')}`);
  return require;
}
async function withServer(task){
  const require=await build();
  const server=await startServer(join(workspace,'dist'),0);
  try{await task({require,url:`http://127.0.0.1:${server.address().port}/`});}
  finally{await new Promise(done=>server.close(done));}
}
async function main(){
  if(command==='help'){
    console.log(`Fábrica digital 2.0\n\nnode scripts/factory.mjs dev       Vista local (reinicia tras editar las fuentes)\nnode scripts/factory.mjs build     Web estática, sin documentos privados\nnode scripts/factory.mjs preview   Sirve la web construida\nnode scripts/factory.mjs check     Narrativa, UI, recorridos y nitidez\nnode scripts/factory.mjs render [scenario] [4k]   Vídeo de un recorrido\n\nRequisitos: Node 22+, pnpm. Vídeo: FFmpeg.\nRuntime: ${runtime}\nSalida: ${output}`);return;
  }
  if(command==='prepare'){await prepare();console.log(workspace);return;}
  if(command==='dev'){
    const require=await prepare();
    console.log('Vista de una copia local. Reinicia el comando después de editar las fuentes.');
    await run(process.execPath,[join(dirname(require.resolve('vite/package.json')),'bin/vite.js'),'--host','127.0.0.1','--port',String(port),'--strictPort']);return;
  }
  if(command==='build'){await build();return;}
  if(command==='preview'){await build();await startServer(join(workspace,'dist'),port);console.log(`Fábrica: http://127.0.0.1:${port}/`);return;}
  if(command==='check'){
    await withServer(async({url})=>{
      await run(process.execPath,['scripts/check-story.mjs']);
      await run(process.execPath,['scripts/check-ui.mjs'],{env:{...env,FACTORY_URL:url,FACTORY_OUTPUT:output}});
    });console.log(`Verificación completada. Capturas: ${output}`);return;
  }
  if(command==='render'){
    const scenario=args.find(arg=>arg!=='4k')||'consultation';
    const fourK=args.includes('4k');
    if(!/^[a-z][a-z-]*$/.test(scenario))throw new Error('Identificador de recorrido no válido.');
    await withServer(async({url})=>run(process.execPath,['scripts/render.mjs'],{env:{...env,FACTORY_URL:url,FACTORY_SCENARIO:scenario,FACTORY_OUTPUT:join(output,`${scenario}-${fourK?'4k':'1080p'}.mp4`),FACTORY_WIDTH:fourK?'3840':'1920',FACTORY_FPS:fourK?'60':'24'}}));return;
  }
  throw new Error(`Comando desconocido: ${command}`);
}
main().catch(error=>{console.error(error.message);process.exitCode=1;});
