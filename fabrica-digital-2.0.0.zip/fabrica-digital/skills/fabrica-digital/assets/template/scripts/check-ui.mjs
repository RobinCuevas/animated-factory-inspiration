import assert from 'node:assert/strict';
import {mkdir,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {chromium} from 'playwright';
import {PROJECT} from '../src/project.js';

const base=process.env.FACTORY_URL;
if(!base)throw new Error('Ejecuta node scripts/factory.mjs check.');
const output=process.env.FACTORY_OUTPUT;
await mkdir(output,{recursive:true});
const browser=await chromium.launch({headless:true,args:process.platform==='darwin'?['--use-angle=metal']:[]});
const failures=[],external=[];
try{
  const context=await browser.newContext({viewport:{width:1512,height:1100},deviceScaleFactor:2});
  await context.route('**/*',route=>{
    if(new URL(route.request().url()).origin!==new URL(base).origin){external.push(route.request().url());return route.abort();}
    return route.continue();
  });
  const page=await context.newPage();
  page.on('pageerror',e=>failures.push(e.message));
  page.on('response',r=>{if(r.status()>=400)failures.push(`${r.status()} ${r.url()}`);});
  await page.goto(base);
  await page.waitForFunction(()=>window.factoryAPI?.ready);
  assert.ok((await page.title()).includes(PROJECT.title));
  assert.ok(await page.locator('#phase-title').textContent());
  const ids=await page.locator('[data-scenario]').evaluateAll(nodes=>nodes.map(n=>n.dataset.scenario));
  assert.ok(ids.length);
  for(const id of ids){
    const data=await page.evaluate(id=>{
      const api=window.factoryAPI;api.selectScenario(id);api.seek(0);
      const duration=api.inspect().duration,samples=[];
      for(const part of [0,.18,.35,.52,.72,.9,1,.52,0]){api.seek(duration*part);const state=api.inspect();samples.push({time:state.time,title:state.state.title,scene:!!state.scene});}
      return samples;
    },id);
    assert.ok(data.every(s=>s.scene&&s.title));
  }
  // A selected step animates, then stops at its reading checkpoint.
  await page.evaluate(id=>{window.factoryAPI.selectScenario(id);window.factoryAPI.seek(0);},ids[0]);
  await page.locator('#next-step').click();
  let state=await page.evaluate(()=>window.factoryAPI.inspect());
  assert.equal(state.playing,true);
  assert.ok(state.playbackStop>state.time);
  const expected=state.playbackStop;
  await page.waitForFunction(()=>!window.factoryAPI.inspect().playing,{},{timeout:20000});
  state=await page.evaluate(()=>window.factoryAPI.inspect());
  assert.ok(Math.abs(state.time-expected)<.001);
  if(ids.length>1){
    await page.evaluate(()=>window.factoryAPI.seek(window.factoryAPI.inspect().duration));
    await page.locator('#next-step').click();
    await page.waitForFunction(id=>window.factoryAPI.inspect().scenario===id,ids[1]);
    state=await page.evaluate(()=>window.factoryAPI.inspect());
    assert.equal(state.entryMode,'focus');
    await page.locator(`[data-scenario="${ids[1]}"]`).click();
    state=await page.evaluate(()=>window.factoryAPI.inspect());
    assert.equal(state.entryMode,'full');
    assert.ok(state.time<.5);
  }
  await page.evaluate(()=>{window.factoryAPI.seek(0);window.factoryAPI.overview();});
  await page.waitForTimeout(1400);
  await page.screenshot({path:join(output,'factory-desktop.png'),fullPage:true});
  const cdp=await context.newCDPSession(page);
  for(const dpr of [2.5,1,2]){
    await cdp.send('Emulation.setDeviceMetricsOverride',{width:1512,height:1100,deviceScaleFactor:dpr,mobile:false});
    await page.waitForTimeout(150);
    const raster=await page.locator('#factory-stage canvas').evaluate(canvas=>({width:canvas.width,height:canvas.height,rect:canvas.getBoundingClientRect().toJSON()}));
    const expectedRatio=Math.min(dpr,Math.sqrt(PROJECT.rendering.maxPixels/(raster.rect.width*raster.rect.height)));
    assert.ok(Math.abs(raster.width-raster.rect.width*expectedRatio)<2,'El canvas sigue DPR y zoom');
    assert.ok(raster.width*raster.height<=PROJECT.rendering.maxPixels+10000,'Presupuesto de raster acotado');
  }
  await page.locator('#map-tab').click();
  const mapBefore=await page.locator('#map-zoom-level').textContent();
  await page.locator('#map-zoom-in').click();
  assert.notEqual(await page.locator('#map-zoom-level').textContent(),mapBefore);
  await page.locator('#logical-map [data-node]').first().click();
  assert.equal(await page.locator('#technical-details').getAttribute('open'),'');
  await page.locator('#factory-tab').click();
  await cdp.send('Emulation.clearDeviceMetricsOverride');
  await page.setViewportSize({width:390,height:844});
  await page.waitForTimeout(300);
  assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),'Sin desbordamiento horizontal en móvil');
  await page.screenshot({path:join(output,'factory-mobile.png'),fullPage:true});
  for(const [path,ready] of [['catalog.html','catalogAPI'],['connections.html','connectionsAPI'],['custom-asset.html','customAssetAPI']]){
    await page.goto(new URL(path,base).href);
    await page.waitForSelector('canvas');
    await page.waitForTimeout(200);
    assert.ok(await page.locator('h1').textContent());
  }
  assert.deepEqual(failures,[]);assert.deepEqual(external,[]);
  const result={pass:true,scenarios:ids,viewports:['1512x1100','390x844'],dpr:[2.5,1,2],checks:['step-play-and-pause',...(ids.length>1?['cross-section-focus','direct-section-full']:[]),'map-zoom-details','workbenches','local-assets','no-console-errors']};
  await writeFile(join(output,'ui-check.json'),JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify(result));
}finally{await browser.close();}
