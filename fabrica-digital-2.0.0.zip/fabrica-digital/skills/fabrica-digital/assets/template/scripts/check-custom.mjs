import assert from 'node:assert/strict';
import {CUSTOM} from '../examples/custom-architecture/model.js';
import {SCENARIOS, sampleScenario, getPhases, getStartTime, getReadingSteps} from '../src/custom-story.js';

const nodes = new Set(CUSTOM.nodes.map(node => node.id));
const services = new Set([...CUSTOM.nodes, ...(CUSTOM.supports ?? [])].map(node => node.id));
assert.ok(nodes.size, 'La arquitectura contiene servicios');
assert.equal(nodes.size, CUSTOM.nodes.length, 'Los servicios tienen identificadores únicos');
assert.equal(services.size, CUSTOM.nodes.length + (CUSTOM.supports?.length ?? 0), 'Los servicios complementarios no duplican identificadores');
assert.ok(SCENARIOS.length, 'La receta contiene al menos un recorrido');
for (const node of CUSTOM.nodes) {
  assert.ok(node.asset && node.label && node.service, `${node.id}: servicio, nombre y pieza`);
  assert.ok(Array.isArray(node.position) && node.position.length === 3 && node.position.every(Number.isFinite), `${node.id}: posición 3D válida`);
}
const connected = (from, to) => CUSTOM.edges.some(edge =>
  edge.from === from && edge.to === to || edge.from === to && edge.to === from);
for (const edge of CUSTOM.edges) assert.ok(nodes.has(edge.from) && nodes.has(edge.to), 'La conexión tiene servicios en ambos extremos');

let samples = 0;
for (const scenario of SCENARIOS) {
  const phases = getPhases(scenario.id);
  assert.equal(getStartTime(scenario.id, 'full'), 0, 'La selección directa conserva el recorrido completo');
  const focusStart = getStartTime(scenario.id, 'focus');
  assert.ok(phases.some(phase => phase.at === focusStart), 'El inicio abreviado coincide con un paso completo');
  for (const mode of ['full', 'focus']) {
    const steps = getReadingSteps(scenario.id, mode);
    assert.equal(steps[0].start, getStartTime(scenario.id, mode));
    assert.equal(steps.at(-1).checkpoint, scenario.duration, 'El último paso incluye el resultado final');
    for (const step of steps) {
      assert.ok(step.checkpoint > step.start && step.checkpoint <= step.end);
      assert.equal(sampleScenario(scenario.id, step.checkpoint).title, step.title, 'La pausa conserva la explicación de la acción realizada');
    }
  }
  let last;
  for (let sample = 0; sample <= Math.ceil(scenario.duration * 20); sample++) {
    const state = sampleScenario(scenario.id, sample / 20);
    samples++;
    assert.equal(state.custom, true);
    assert.ok(state.title && state.copy, 'Cada momento tiene una explicación');
    assert.ok(state.active.every(id => services.has(id)) && state.focus.every(id => nodes.has(id)), 'La escena usa servicios existentes');
    if (state.token.route) {
      assert.ok(connected(...state.token.route), 'La operación recorre una conexión declarada');
      assert.ok(state.token.progress >= 0 && state.token.progress <= 1);
      assert.equal(state.work.length, 0, 'La máquina espera a que llegue la operación');
      if (last?.phaseIndex === state.phaseIndex) assert.ok(state.token.progress >= last.token.progress, 'La pieza avanza por el recorrido');
    } else assert.ok(nodes.has(state.token.node), 'La pieza en reposo pertenece a un servicio');
    for (const id of state.work) assert.equal(id, state.token.node, 'Se trabaja sobre una operación que ya ha llegado');
    if (state.work.length) assert.ok(state.workTime >= 0 && state.workTime <= 3.3, 'El trabajo usa su propio ciclo');
    if (last) assert.equal(state.token.id, last.token.id, 'La operación conserva su identidad durante el recorrido');
    last = state;
  }
  for (const {at} of phases.slice(1)) {
    const before = sampleScenario(scenario.id, at - 1e-7);
    const after = sampleScenario(scenario.id, at);
    assert.equal(before.token.route?.[1] ?? before.token.node, after.token.route?.[0] ?? after.token.node, 'No hay saltos entre servicios al cambiar de paso');
  }
  for (const at of [0, scenario.duration * .21, scenario.duration * .69, scenario.duration]) {
    const expected = sampleScenario(scenario.id, at);
    sampleScenario(SCENARIOS.at(-1).id, 1e6);
    sampleScenario(scenario.id, 0);
    assert.deepEqual(sampleScenario(scenario.id, at), expected, 'Retroceder o cambiar de sección no deja estado acumulado');
  }
}
console.log(JSON.stringify({status: 'PASS', recipe: 'custom', samples, scenarios: SCENARIOS.length, checks: ['Servicios y conexiones', 'Identidad y continuidad de la operación', 'Trabajo después de llegada', 'Pasos completos y pausa para leer', 'Inicio completo y abreviado', 'Retroceso determinista']}, null, 2));
