import assert from 'node:assert/strict';
import {SCENARIOS,sampleScenario,getPhases,getStartTime,getChapters,getReadingSteps} from '../src/story.js';
import {NODES,EDGES,SUPPORTS,STATUS} from '../src/architecture.js';

const ids=new Set(NODES.map(node=>node.id));
const serviceIds=new Set([...NODES,...SUPPORTS].map(node=>node.id));
assert.equal(ids.size,NODES.length,'Los servicios tienen identificadores únicos');
assert.ok(ids.size>0,'La arquitectura contiene servicios');
assert.ok(typeof STATUS==='string'&&STATUS.trim(),'La representación explica su estado');
assert.equal(serviceIds.size,NODES.length+SUPPORTS.length,'Los servicios complementarios no duplican identificadores');
for(const edge of EDGES)assert.ok(ids.has(edge.from)&&ids.has(edge.to));
for(const node of [...NODES,...SUPPORTS])for(const key of ['label','service','receives','does','sends','evidence','source','choice','pending','network'])assert.ok(node[key],`${node.id}: ${key}`);
const connectionExists=([from,to])=>EDGES.some(edge=>(edge.from===from&&edge.to===to)||(edge.from===to&&edge.to===from));
let count=0;
for(const scenario of SCENARIOS){
  let lastAttempts=0;
  for(let i=0;i<=Math.ceil(scenario.duration*20);i++){
    const state=sampleScenario(scenario.id,i/20);count++;
    for(const actor of [...state.active,...state.focus,...state.work])assert.ok(serviceIds.has(actor));
    if(state.token.route){assert.ok(connectionExists(state.token.route),`Ruta desconocida: ${state.token.route}`);assert.ok(state.token.progress>=0&&state.token.progress<=1)}
    else if(!state.extension)assert.ok(ids.has(state.token.node));
    assert.ok(!state.work.length||!state.token.route,'El trabajo espera la llegada del contenido');
    for(const actor of state.work)assert.equal(state.token.node,actor,'La máquina trabaja sobre la pieza que ha recibido');
    if(!state.extension){assert.ok(state.ledger.attempts<=1,'La ilustración solo contiene un envío');
    assert.ok(state.ledger.attempts>=lastAttempts);lastAttempts=state.ledger.attempts;}
    else {
      assert.ok(state.extension.progress>=0&&state.extension.progress<=1);
      assert.equal(state.token.visible,false,'Las historias complementarias no emiten pedidos en el flujo principal');
      assert.equal(state.saved,false);
      assert.ok(scenario.badge&&scenario.context,'Los ejemplos opcionales explican su condición ilustrativa');
      assert.ok(state.insight.length>=2);
    }
    if(state.assistant){
      assert.equal(state.assistant.mode,'suggest');
      assert.equal(state.assistant.modifiesOrder,false,'La sugerencia opcional no altera la selección que se guarda');
      assert.equal(state.token.label,'P-042');
    }
    if(['consultation','preparation'].includes(scenario.id)){
      assert.equal(state.ledger.attempts,0);assert.equal(state.ledger.submission,'No enviado');
      assert.ok(!state.active.includes('queue')&&!state.active.includes('orders'));
    }
    if(scenario.id==='preparation')assert.equal(state.ledger.draft==='Guardado en el portal',state.saved);
    if(scenario.id==='attachments'){
      assert.equal(state.ledger.attempts,0);assert.ok(!state.active.includes('orders'));
      if(state.attachmentLinked)assert.ok(state.attachmentSaved,'La ficha sólo confirma un archivo ya guardado');
      if(state.downloaded)assert.ok(state.attachmentSaved&&state.attachmentLinked,'La copia no elimina sus originales');
      if(state.chapter?.index>=1)assert.ok(state.attachmentSaved,'Al explicar la ficha, el original ya permanece en Blob');
      if(state.chapter?.index>=2)assert.ok(state.attachmentLinked,'La nueva lectura comienza después del registro');
    }
    if(['submission','ambiguous'].includes(scenario.id))assert.notEqual(state.token.node,'queue','El procesador libre recoge sin una espera artificial');
    if(scenario.id==='capacity'){
      const c=state.capacity;
      assert.equal(new Set(c.jobs.map(job=>job.id)).size,c.jobs.length);
      for(const job of c.jobs.filter(job=>job.stage==='processing')){
        assert.equal(c.replicaScales[job.machine],1,'El trabajo empieza con la réplica preparada');
        assert.equal(c.jobs.filter(other=>other.machine===job.machine&&other.stage==='processing').length,1);
      }
      assert.equal(c.jobs.filter(job=>job.visible).length,c.pending+c.processing+c.inFlight+c.completed,'Ninguna solicitud desaparece');
    }
    if(state.uncertain){
      assert.equal(scenario.id,'ambiguous');assert.equal(state.ledger.submission,'Confirmación pendiente');
      assert.equal(state.ledger.attempts,1);assert.equal(state.ledger.commercial,'Sin confirmar');
      assert.equal(state.token.node,'orders');assert.ok(!state.work.includes('orders'));
    }
  }
  const moments=getPhases(scenario.id);
  for(const mode of ['focus','full']){
    const steps=getReadingSteps(scenario.id,mode);
    assert.equal(steps[0].start,getStartTime(scenario.id,mode),'La lectura comienza en el inicio elegido');
    assert.equal(steps.at(-1).checkpoint,scenario.duration,'El último paso permite leer el resultado final');
    for(const step of steps){
      assert.ok(step.checkpoint>step.start&&step.checkpoint<=step.end);
      assert.equal(sampleScenario(scenario.id,step.checkpoint).title,step.title,'La parada conserva la explicación del paso');
    }
  }
  for(const {at} of moments.slice(1)){
    const before=sampleScenario(scenario.id,at-1e-7),after=sampleScenario(scenario.id,at);
    const from=before.token.route?.[1]||before.token.node;
    const to=after.token.route?.[0]||after.token.node;
    assert.equal(from,to,`${scenario.id}: salto sin conexión en ${at}`);
  }
  for(const time of [0,scenario.duration*.33,scenario.duration*.75,scenario.duration]){
    const expected=sampleScenario(scenario.id,time);sampleScenario('ambiguous',999);
    assert.deepEqual(sampleScenario(scenario.id,time),expected,'El seek no hereda estado de otra historia');
  }
}
const preparationSteps=getReadingSteps('preparation');
const suggestionIndex=preparationSteps.findIndex(step=>sampleScenario('preparation',step.checkpoint).assistant);
assert.ok(suggestionIndex>=0,'La preparación conserva la sugerencia de IA');
assert.equal(preparationSteps.filter(step=>sampleScenario('preparation',step.checkpoint).assistant).length,1,'La sugerencia se explica en un único paso');
const saveAfterSuggestion=sampleScenario('preparation',preparationSteps[suggestionIndex+1].checkpoint);
assert.deepEqual(saveAfterSuggestion.work,['backend'],'Después de la sugerencia se prepara directamente el guardado');
assert.equal(saveAfterSuggestion.token.label,'P-042','Se guarda la selección actual sin añadir el complemento sugerido');
const end=id=>sampleScenario(id,SCENARIOS.find(s=>s.id===id).duration);
for(const id of ['preparation','submission','ambiguous','attachments']){
  const start=sampleScenario(id,getStartTime(id));
  assert.equal(start.token.node,'backend','El inicio abreviado empieza con una petición ya recibida');
  assert.equal(start.ledger.attempts,0,'El inicio abreviado no salta ningún envío al sistema de pedidos');
  assert.equal(start.attachmentSaved,false,'El adjunto todavía debe almacenarse');
  assert.equal(getStartTime(id,'full'),0,'La entrada completa sigue disponible');
  assert.equal(start.saved,['submission','ambiguous'].includes(id),'Se conserva el contexto inicial del borrador');
}
assert.equal(getStartTime('consultation'),0);assert.equal(getStartTime('capacity'),0);
assert.equal(end('preparation').ledger.submission,'No enviado');
assert.equal(end('submission').ledger.submission,'Recibido por el sistema de pedidos');
assert.equal(end('submission').ledger.commercial,'Validación pendiente');
assert.equal(end('ambiguous').ledger.submission,'Confirmación pendiente');
assert.equal(end('ambiguous').ledger.attempts,1);
assert.ok(end('attachments').attachmentSaved&&end('attachments').attachmentLinked&&end('attachments').downloaded);
assert.equal(getChapters('attachments').length,4);
assert.equal(getReadingSteps('attachments').length,4,'Los movimientos de un capítulo de archivos se leen juntos');
const fileStops=getReadingSteps('attachments').map(step=>sampleScenario('attachments',step.checkpoint));
assert.ok(fileStops[0].attachmentSaved&&!fileStops[0].attachmentLinked,'Primera parada: el archivo queda guardado');
assert.ok(fileStops[1].attachmentLinked&&!fileStops[1].downloaded,'Segunda parada: la ficha queda registrada');
assert.equal(fileStops[2].storage.mode,'reading','Tercera parada: la copia está preparada');
assert.ok(fileStops[3].downloaded,'Cuarta parada: el cliente dispone de la copia');
assert.match(sampleScenario('attachments',getStartTime('attachments')).copy,/cliente adjunta un plano/,'El inicio abreviado conserva el contexto de negocio');
for(const chapter of getChapters('attachments'))assert.equal(sampleScenario('attachments',chapter.at).chapter.index,chapter.index);
assert.equal(end('capacity').capacity.completed,9);assert.equal(end('capacity').capacity.replicas,1);
console.log(JSON.stringify({status:'PASS',samples:count,scenarios:SCENARIOS.length,checks:['Servicios y conexiones','Trabajo después de llegada','Guardado separado de envío','Recepción separada de validación','Un intento ante respuesta ambigua','Fichero y ficha conservados después de la lectura','Réplicas preparadas antes del trabajo y sin perder solicitudes','Continuidad y retroceso']},null,2));
