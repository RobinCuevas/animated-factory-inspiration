import {defineConfig} from 'vite';
import {resolve} from 'node:path';

export default defineConfig({
  base:'./',
  cacheDir:'.runtime/vite',
  server:{host:'127.0.0.1'},
  build:{
    target:'es2022',
    rollupOptions:{input:Object.fromEntries([
      ...['index','catalog','connections','custom-asset'].map(name=>[name,resolve(`${name}.html`)]),
      ['embed',resolve('examples/embed/index.html')],
    ])},
  },
});
