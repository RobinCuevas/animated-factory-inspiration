import {createViewer} from './catalog/viewer.js';
import {createQualityGate, QUALITY_GATE} from './examples/custom-asset/index.js';

const $ = selector => document.querySelector(selector);
const viewer = createViewer($('#viewer'));
let instance, progress = .4, result = 'accepted', theme = 'neutral', playing = false, snapshot;
function seek(value) {
  progress = Math.max(0, Math.min(1, Number(value) || 0));
  snapshot = instance.update(progress * QUALITY_GATE.duration, {progress, result});
  $('#progress').value = String(progress);
  $('#status').textContent = {
    idle: 'El control espera a que llegue una copia.',
    waiting: 'La copia va a entrar en el control.',
    arriving: 'La copia entra y se detiene bajo el lector.',
    inspecting: 'El lector examina la hoja mientras permanece detenida.',
    departing: result === 'accepted' ? 'El control permite continuar. La misma copia sale por la cinta principal.' : 'El control solicita revisión. La misma copia se aparta por el ramal lateral.',
    complete: result === 'accepted' ? 'La copia ha llegado a la salida principal.' : 'La copia ha llegado a la salida de revisión.',
  }[snapshot.status];
  viewer.render();
  return inspect();
}
function setPlaying(value) {playing = Boolean(value);$('#play').textContent = playing ? 'Pausar' : progress >= 1 ? 'Repetir' : 'Reproducir'}
function assemble() {
  instance?.dispose();
  instance = createQualityGate({theme});
  viewer.mount(instance, {...QUALITY_GATE, framingSamples: [
    {time: 9.5, state: {progress: .95, result: 'accepted'}},
    {time: 9.5, state: {progress: .95, result: 'review'}},
  ]}, progress * QUALITY_GATE.duration, {progress, result});
  seek(progress);
}
function inspect() {return {progress, result, theme, playing, snapshot, viewer: viewer.inspect()}}
$('#play').onclick = () => {if (!playing && progress >= 1) seek(0);setPlaying(!playing)};
$('#progress').oninput = event => {setPlaying(false);seek(event.target.value)};
$('#result').onchange = event => {result = event.target.value;seek(progress)};
$('#theme').onchange = event => {theme = event.target.value;assemble()};
assemble();
let last = performance.now();
viewer.renderer.setAnimationLoop(now => {
  const dt = Math.min((now - last) / 1000, .05);last = now;
  if (playing) {seek(progress + dt / QUALITY_GATE.duration);if (progress >= 1) setPlaying(false)}
  else viewer.render();
});
window.customAssetAPI = {seek, inspect, setPlaying};
