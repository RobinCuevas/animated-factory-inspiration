import * as THREE from 'three';

// A fixed, reversible illustration. These counts and timings are not scaling policies.
export const CAPACITY_DURATION = 20.5;
export const CAPACITY_PHASES = [
  { at: 0, title: 'Una copia atiende las solicitudes.', copy: 'Cada ficha representa una petición sintética de cálculo del portal. Seguimos su identidad hasta el resultado.' },
  { at: 2.5, title: 'Llega más trabajo.', copy: 'Las solicitudes se acumulan en el único puesto disponible. Aumentar capacidad es una opción del servicio, con reglas y límites por validar.' },
  { at: 3.75, title: 'Se abre espacio para repartir el trabajo.', copy: 'Aparecen dos mesas a los lados. Parte de las solicitudes que esperaban en el centro se desplaza a esos nuevos puestos.' },
  { at: 5.25, title: 'Se preparan dos copias más.', copy: 'Cada puesto recibe una copia del mismo backend. Las solicitudes esperan hasta que las nuevas máquinas estén listas.' },
  { at: 6.25, title: 'Tres copias comparten el trabajo.', copy: 'Las tres máquinas realizan la misma función y procesan solicitudes distintas. Los datos siguen siendo comunes.' },
  { at: 10.5, title: 'Baja el volumen de solicitudes.', copy: 'Las copias terminan el trabajo que ya recibieron antes de retirarse.' },
  { at: 13.5, title: 'La capacidad vuelve a reducirse.', copy: 'Se retiran los dos puestos que ya están libres. Sus resultados permanecen disponibles.' },
  { at: 15.25, title: 'Una copia continúa trabajando.', copy: 'La última solicitud recorre el mismo servicio. Reducir copias no borra sus resultados.' },
  { at: 19.5, title: 'La capacidad acompaña a la demanda.', copy: 'El recorrido 1 → 3 → 1 es ilustrativo. Umbrales, mínimos, máximos y tiempos deberán acordarse y probarse.' },
];

export const CAPACITY_MACHINES = [
  { id: 0, x: 0, label: 'Backend · copia 1' },
  { id: 1, x: -7, label: 'Backend · copia 2' },
  { id: 2, x: 7, label: 'Backend · copia 3' },
];

const specifications = [
  ['R-01', 0, 0, 1.5, 2.5, -1.2, 0],
  ['R-02', 0, .5, 4.5, 5.5, -.4, 1],
  ['R-03', 0, 1, 7.5, 8.5, .4, 2],
  ['R-04', 1, 1.5, 6.3, 7.3, -.45, 0],
  ['R-05', 2, 2, 6.3, 7.3, -.45, 0],
  ['R-06', 1, 2.5, 9.3, 10.3, .45, 1],
  ['R-07', 2, 3, 9.3, 10.3, .45, 1],
  ['R-08', 0, 3.5, 10.5, 11.5, 1.2, 3],
  ['R-09', 0, 14.5, 15.5, 16.5, 0, 4],
];

// Opening the work areas, distributing requests and booting replicas are
// deliberately separate beats. No request is processed by a growing replica.
const TABLE_OPEN = [3.75, 4.25];
const TRANSFER = [4.25, 5.25];
const MACHINE_OPEN = [5.25, 6.25];
const MACHINE_CLOSE = [13.5, 14.5];
const TABLE_CLOSE = [14.5, 15.25];

const clamp = value => Math.max(0, Math.min(1, value));
const smooth = value => { const p = clamp(value); return p * p * (3 - 2 * p); };
const phase = (time, start, end) => smooth((time - start) / (end - start));
const point = values => new THREE.Vector3().fromArray(values);
const headings = new WeakMap();
function curve(points) {
  const route = new THREE.CatmullRomCurve3(points.map(point), false, 'centripetal');
  route.arcLengthDivisions = 300;
  route.updateArcLengths();
  const angles = [];
  let previous = Math.PI;
  for (let index = 0; index <= 300; index++) {
    const tangent = route.getTangentAt(index / 300);
    const raw = Math.atan2(tangent.x, tangent.z);
    previous += Math.atan2(Math.sin(raw - previous), Math.cos(raw - previous));
    angles.push(previous);
  }
  headings.set(route, angles);
  return route;
}

export const CAPACITY_JOBS = specifications.map(([id, machine, release, enter, work, offset, slot], index) => {
  const x = CAPACITY_MACHINES[machine].x;
  const initialWaiting = index < 8 ? [-1.2 + (index % 4) * .8, 1.18, index < 4 ? 5.2 : 6.1] : [0, 1.18, 5.7];
  const waiting = machine === 0 ? initialWaiting : [x + offset, 1.18, 5.3];
  const chamber = [x, 1, -.23];
  const destination = [x + 2.35, 1.18 + slot * .075, -4.25];
  return {
    id, machine, release, arrived: release + .6, enter, work,
    worked: work + 1.5, finished: work + 3, slot, initialWaiting, waiting, chamber, destination,
    transfer: machine === 0 ? null : TRANSFER,
    routes: {
      arriving: curve([[initialWaiting[0], 1.18, 7], initialWaiting]),
      ...(machine === 0 ? {} : { redistributing: curve([initialWaiting, [x * .45, 1.18, initialWaiting[2] + .35], [x * .8, 1.18, 5.55], waiting]) }),
      entering: curve([waiting, [x, 1.18, 3.6], [x, 1.18, 1.65], [x, 1.18, .68], chamber]),
      exiting: curve([chamber, [x, 1.18, .68], [x, 1.18, 2.3], [x + 2.35, 1.18, 2.3], [x + 2.35, 1.18, -.6], [x + 2.35, 1.18, -3.6], destination]),
    },
  };
});

function sampleJob(job, time) {
  let stage, progress = 0, position, yaw = Math.PI;
  if (time < job.release) {
    stage = 'unreleased'; position = job.routes.arriving.getPointAt(0).toArray();
  } else if (time < job.arrived) {
    stage = 'arriving'; progress = phase(time, job.release, job.arrived);
  } else if (job.transfer && time < job.transfer[0]) {
    stage = 'waiting'; position = [...job.initialWaiting];
  } else if (job.transfer && time < job.transfer[1]) {
    stage = 'redistributing'; progress = phase(time, ...job.transfer);
  } else if (time < job.enter) {
    stage = 'waiting'; position = [...job.waiting];
  } else if (time < job.work) {
    stage = 'entering'; progress = phase(time, job.enter, job.work);
  } else if (time < job.worked) {
    stage = 'processing'; progress = clamp((time - job.work) / (job.worked - job.work)); position = [...job.chamber];
  } else if (time < job.finished) {
    stage = 'exiting'; progress = phase(time, job.worked, job.finished);
  } else {
    stage = 'completed'; progress = 1; position = [...job.destination];
  }
  if (job.routes[stage]) {
    const route = job.routes[stage];
    position = route.getPointAt(progress).toArray();
    const angles = headings.get(route), segment = progress * 300;
    const index = Math.min(299, Math.floor(segment)), fraction = segment - index;
    const direction = angles[index] + (angles[index + 1] - angles[index]) * fraction;
    const turn = direction - Math.PI;
    const moving = smooth(progress / .15) * smooth((1 - progress) / .15);
    yaw = Math.PI + turn * moving;
  }
  return {
    id: job.id, machine: job.machine, stage, progress, position, yaw,
    table: stage === 'waiting' ? (job.transfer && time < job.transfer[0] ? 0 : job.machine) : null,
    visible: stage !== 'unreleased',
    result: stage === 'exiting' || stage === 'completed',
    processingProgress: stage === 'processing' ? progress : 0,
  };
}

export function sampleCapacity(seconds) {
  const time = Math.max(0, Math.min(CAPACITY_DURATION, Number(seconds) || 0));
  const appearance = phase(time, ...MACHINE_OPEN) * (1 - phase(time, ...MACHINE_CLOSE));
  const tableAppearance = phase(time, ...TABLE_OPEN) * (1 - phase(time, ...TABLE_CLOSE));
  const replicaScales = [1, appearance, appearance];
  const tableScales = [1, tableAppearance, tableAppearance];
  const jobs = CAPACITY_JOBS.map(job => sampleJob(job, time));
  const narrative = CAPACITY_PHASES.findLast(item => item.at <= time) || CAPACITY_PHASES[0];
  return {
    time, duration: CAPACITY_DURATION, title: narrative.title, copy: narrative.copy,
    replicas: time >= MACHINE_OPEN[1] && time < MACHINE_CLOSE[0] ? 3 : 1,
    targetReplicas: time >= TABLE_OPEN[0] && time < MACHINE_CLOSE[0] ? 3 : 1,
    replicaScales, tableScales,
    outputScales: [1, phase(time, ...MACHINE_OPEN), phase(time, ...MACHINE_OPEN)],
    tables: tableScales.filter(scale => scale === 1).length,
    transferring: jobs.filter(job => job.stage === 'redistributing').length,
    pending: jobs.filter(job => job.stage === 'waiting').length,
    processing: jobs.filter(job => job.stage === 'processing').length,
    inFlight: jobs.filter(job => ['arriving', 'redistributing', 'entering', 'exiting'].includes(job.stage)).length,
    completed: jobs.filter(job => job.stage === 'completed').length,
    submitted: jobs.filter(job => job.visible).length,
    jobs,
    illustrative: true,
  };
}
