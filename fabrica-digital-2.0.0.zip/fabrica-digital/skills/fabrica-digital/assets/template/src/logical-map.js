const WIDTH = 1300;
const HEIGHT = 830;
const CARD_WIDTH = 210;
const CARD_HEIGHT = 124;

// Functional layout only. These areas do not represent a VNet or subnets.
const POSITIONS = {
  client: [145, 126], entry: [395, 126], frontend: [645, 126],
  erp: [145, 386], apim: [395, 386], backend: [645, 386],
  queue: [895, 386], worker: [1145, 386],
  pricing: [145, 668], blob: [395, 668], sql: [645, 668], orders: [1145, 668],
};

// Distinct lanes keep commercial queries, own data and order submission apart.
const ROUTES = {
  'client-entry': 'M250 126 H290',
  'entry-frontend': 'M500 126 H540',
  'entry-apim': 'M395 188 V324',
  'apim-backend': 'M500 386 H540',
  'backend-queue': 'M750 386 H790',
  'queue-worker': 'M1000 386 H1040',
  'backend-erp': 'M540 407 H530 Q518 407 518 419 V464 Q518 476 506 476 H157 Q145 476 145 464 V448',
  'backend-pricing': 'M540 429 H538 Q528 429 528 441 V502 Q528 514 516 514 H159 Q145 514 145 528 V606',
  'backend-blob': 'M600 448 V544 Q600 558 586 558 H409 Q395 558 395 572 V606',
  'backend-sql': 'M645 448 V606',
  'worker-sql': 'M1095 448 V526 Q1095 540 1081 540 H794 Q780 540 780 554 V654 Q780 668 766 668 H750',
  'worker-orders': 'M1185 448 V606',
};

const ROUTE_LABELS = {
  'entry-apim': { x: 409, y: 242, text: 'Llamadas API' },
  'backend-erp': { x: 199, y: 466, text: 'Disponibilidad' },
  'backend-pricing': { x: 199, y: 503, text: 'Condiciones' },
  'backend-blob': { x: 408, y: 548, text: 'Ficheros' },
  'backend-sql': { x: 660, y: 497, text: 'Estado propio' },
  'worker-sql': { x: 865, y: 529, text: 'Estado del envío' },
  'worker-orders': { x: 1198, y: 529, text: 'Pedido' },
};

const list = value => Array.isArray(value) ? value : Object.values(value || {});
const escape = value => String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
const readable = value => {
  if (Array.isArray(value)) return value.map(readable).filter(Boolean).join(' · ');
  if (value && typeof value === 'object') return readable(value.label ?? value.title ?? value.text ?? Object.values(value));
  return String(value ?? '');
};

function wrap(value, maxLength) {
  const lines = [];
  let current = '';
  for (const word of value.trim().split(/\s+/)) {
    const next = current ? `${current} ${word}` : word;
    if (current && next.length > maxLength) { lines.push(current); current = word; }
    else current = next;
  }
  if (current) lines.push(current);
  return lines;
}

function textLines(lines, x, firstY, step, className) {
  return `<text class="${className}" x="${x}" y="${firstY}">${lines.map((line, index) => `<tspan x="${x}" y="${firstY + index * step}">${escape(line)}</tspan>`).join('')}</text>`;
}

function fallbackRoute(from, to, positions) {
  const a = positions[from], b = positions[to];
  const horizontal = Math.abs(b[0] - a[0]) > Math.abs(b[1] - a[1]);
  const sign = Math.sign(horizontal ? b[0] - a[0] : b[1] - a[1]) || 1;
  if (horizontal) {
    const start = [a[0] + sign * CARD_WIDTH / 2, a[1]], end = [b[0] - sign * CARD_WIDTH / 2, b[1]], middle = (start[0] + end[0]) / 2;
    return `M${start} C${middle} ${start[1]} ${middle} ${end[1]} ${end}`;
  }
  const start = [a[0], a[1] + sign * CARD_HEIGHT / 2], end = [b[0], b[1] - sign * CARD_HEIGHT / 2], middle = (start[1] + end[1]) / 2;
  return `M${start} C${start[0]} ${middle} ${end[0]} ${middle} ${end}`;
}

/** Render the existing logical graph with readable, separate brand and text areas. */
export function drawLogicalMap(map, nodes, edges, serviceIcons = {}, {layout = 'auto'} = {}) {
  if (!map?.setAttribute) throw new TypeError('Se necesita el elemento SVG del mapa lógico');
  const nodeList = list(nodes);
  // Unrelated recipes get a compact diagram with no commerce-specific zones.
  const commerceLayout = layout === 'commerce' || layout === 'auto' && nodeList.some(node => Object.hasOwn(POSITIONS, node.id));
  const positions = commerceLayout ? {...POSITIONS} : {};
  const columns = Math.min(4, Math.max(1, Math.ceil(Math.sqrt(nodeList.length))));
  let extra = 0;
  for (const node of nodeList) {
    const point = node.mapPosition;
    if (Array.isArray(point) && point.length === 2 && point.every(Number.isFinite)) positions[node.id] = [...point];
    else if (!positions[node.id]) {
      positions[node.id] = commerceLayout
        ? [145 + (extra % 5) * 250, 930 + Math.floor(extra / 5) * 210]
        : [145 + (extra % columns) * 320, 110 + Math.floor(extra / columns) * 250];
      extra += 1;
    }
  }
  const width = Math.max(commerceLayout ? WIDTH : 320, ...nodeList.map(node => positions[node.id][0] + CARD_WIDTH / 2 + 40));
  const height = Math.max(commerceLayout ? HEIGHT : 220, ...nodeList.map(node => positions[node.id][1] + CARD_HEIGHT / 2 + 40));
  const available = new Set(nodeList.map(node => node.id));
  const edgeList = list(edges).filter(edge => available.has(edge.from) && available.has(edge.to));
  const viewBox = `0 0 ${width} ${height}`;
  map.setAttribute('viewBox', viewBox);
  map.setAttribute('preserveAspectRatio', 'xMidYMid meet');
  map.setAttribute('data-map-width', String(width));
  map.setAttribute('data-map-height', String(height));
  map.removeAttribute('data-min-width');

  const definitions = `<defs>
    <marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0 10 5 0 10Z" fill="#b3a59a"/></marker>
    <marker id="arrow-async" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0 10 5 0 10Z" fill="#bca070"/></marker>
  </defs>`;

  const areas = commerceLayout ? `<g class="map-zones" aria-hidden="true">
    <path class="map-zone" d="M540 30 H750 Q770 30 770 50 V260 Q770 280 790 280 H1250 Q1270 280 1270 300 V456 Q1270 476 1250 476 H790 Q770 476 770 496 V758 Q770 778 750 778 H290 Q270 778 270 758 V300 Q270 280 290 280 H500 Q520 280 520 260 V50 Q520 30 540 30Z"/>
    <text class="map-group-label" x="40" y="42">ACCESO AL PORTAL</text>
    <text class="map-group-label" x="539" y="53">PORTAL WEB</text>
    <text class="map-group-label" x="40" y="294">CONSULTAS AL NEGOCIO</text>
    <text class="map-group-label" x="290" y="305">APLICACIÓN E INTEGRACIÓN</text>
    <text class="map-group-label" x="290" y="762">DATOS PROPIOS DEL PORTAL</text>
    <text class="map-group-label" x="1040" y="578">CORE CORPORATIVO</text>
  </g>` : '';

  const connections = edgeList.map(edge => {
    const key = `${edge.from}-${edge.to}`;
    const fixedRoute = [edge.from, edge.to].every(id => POSITIONS[id]?.every((coordinate, index) => coordinate === positions[id][index]));
    const asynchronous = /async|queue|command|submission/i.test(edge.kind || '') || ['queue', 'worker'].includes(edge.from) || edge.to === 'queue';
    const label = readable(edge.label) || `${edge.from} → ${edge.to}`;
    return `<path class="map-edge${asynchronous ? ' async' : ''}" data-edge="${escape(edge.id || key)}" d="${fixedRoute && ROUTES[key] || fallbackRoute(edge.from, edge.to, positions)}" marker-end="url(#${asynchronous ? 'arrow-async' : 'arrow'})"><title>${escape(label)}</title></path>`;
  }).join('');

  const connectionLabels = edgeList.map(edge => {
    const fixedRoute = [edge.from, edge.to].every(id => POSITIONS[id]?.every((coordinate, index) => coordinate === positions[id][index]));
    const label = fixedRoute && ROUTE_LABELS[`${edge.from}-${edge.to}`];
    return label ? `<text class="map-edge-label" x="${label.x}" y="${label.y}" aria-hidden="true">${escape(label.text)}</text>` : '';
  }).join('');

  const cards = nodeList.map(node => {
    const point = positions[node.id], label = readable(node.label), service = readable(node.service);
    const headingLines = wrap(label, 16);
    const serviceLines = service.split(/\s*·\s*/).flatMap(part => wrap(part, 27));
    const icon = serviceIcons[node.id];
    const external = node.scope === 'core' || node.scope === 'user';
    // These are plain abbreviations, not invented product logos.
    const initials = { client: 'B2B', erp: 'ERP', pricing: 'PRE', orders: 'PED' }[node.id] || node.id.toUpperCase().slice(0, 3);
    const mark = icon
      ? `<image class="map-icon" href="${escape(icon)}" x="18" y="17" width="38" height="38" preserveAspectRatio="xMidYMid meet" aria-hidden="true"/>`
      : `<text class="map-initials" x="37" y="42" text-anchor="middle" aria-hidden="true">${escape(initials)}</text>`;
    return `<g class="map-node${external ? ' external' : ''}" data-node="${escape(node.id)}" role="button" tabindex="0" aria-pressed="false" aria-label="${escape(`${label}. ${service}. Abrir ficha`)}" transform="translate(${point[0] - CARD_WIDTH / 2} ${point[1] - CARD_HEIGHT / 2})">
      <rect width="${CARD_WIDTH}" height="${CARD_HEIGHT}" rx="10"/>
      ${mark}
      ${textLines(headingLines, 74, headingLines.length === 1 ? 42 : 30, 22, 'map-node-label')}
      <path class="map-node-divider" d="M18 70 H192" stroke="#e3dbd3" fill="none" aria-hidden="true"/>
      ${textLines(serviceLines, 18, serviceLines.length === 1 ? 99 : 91, 19, 'map-service')}
      <title>${escape(`${label} · ${service}`)}</title>
    </g>`;
  }).join('');

  map.innerHTML = definitions + areas + connections + connectionLabels + cards;
  return { viewBox, width, height, nodeCount: nodeList.length, edgeCount: edgeList.length };
}
