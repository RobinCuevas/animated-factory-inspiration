// A synthetic commerce example. Replace its roles and story with the next project's architecture.
import {CAPACITY_DURATION,CAPACITY_PHASES,sampleCapacity} from './capacity-story.js';
import {EXTENSION_SCENARIOS,getExtensionPhases,sampleExtension} from './extension-story.js';
const idle={draft:'Sin guardar',submission:'No enviado',commercial:'Sin validar',attempts:0};
const saved={...idle,draft:'Guardado en el portal'};
const pending={...saved,submission:'Pendiente de procesar'};
const processing={...saved,submission:'En proceso',attempts:1};
const received={...saved,submission:'Recibido por el sistema de pedidos',commercial:'Validación pendiente',attempts:1};
const unknown={...saved,submission:'Confirmación pendiente',commercial:'Sin confirmar',attempts:1};
const move=(from,to,seconds,title,copy,extra={})=>({seconds,title,copy,route:[from,to],active:[from,to],...extra});
const hold=(node,seconds,title,copy,extra={})=>({seconds,title,copy,node,active:[node],...extra});

const consultation=[
  hold('client',3,'Una consulta con contexto comercial.','La sesión y la cuenta de ejemplo acompañan cada petición. Consultamos una referencia sintética desde el portal ya abierto.'),
  move('client','entry',2.5,'La petición entra protegida.','Front Door y WAF son la entrada del portal. La llamada a la API sigue su propia ruta.'),
  move('entry','apim',2.5,'Una fachada común para las APIs.','API Management aplica las políticas de acceso y dirige la llamada al backend.'),
  move('apim','backend',2.5,'La cuenta determina qué se puede consultar.','El backend recibe identidad, cuenta y ámbito. Estar autenticado no concede acceso a todos los datos.'),
  hold('backend',3.5,'El backend verifica el permiso.','Utiliza la cuenta y el ámbito de la consulta para limitar los datos que el usuario puede ver.',{work:['backend']}),
  move('backend','erp',3,'La disponibilidad se consulta en el ERP.','El portal solicita el dato al sistema corporativo. En este recorrido no se utiliza una caché.'),
  hold('erp',2,'El ERP conserva la autoridad sobre el dato.','La lectura no traslada el ERP a la base del portal.'),
  move('erp','backend',3,'Vuelve una respuesta del sistema fuente.','La respuesta se asocia a la cuenta y al momento de la consulta.',{kind:'result',label:'Consulta C-042 · dato de origen'}),
  move('backend','pricing',3,'Se consultan tarifas y condiciones.','En este ejemplo, el ERP aporta disponibilidad y el motor de precios calcula las condiciones comerciales de la cuenta.',{kind:'request',label:'Consulta C-042 · condiciones'}),
  hold('pricing',2,'El precio necesita contexto.','Cuenta, mercado, divisa y condiciones pueden cambiar el resultado. No hay un precio universal por referencia.'),
  move('pricing','backend',3,'La información vuelve al portal.','Se conserva el contexto comercial. Esta respuesta ilustrativa no sustituye la validación del pedido en el sistema de pedidos.',{kind:'result',label:'Respuesta · C-042'}),
  hold('backend',2,'El backend prepara la respuesta para el usuario.','Disponibilidad y condiciones son datos de consulta, no una aceptación comercial del pedido.'),
  move('backend','apim',2,'La respuesta atraviesa la fachada API.','El contenido permitido vuelve por el canal de la petición.'),
  move('apim','entry',2,'La entrada protegida devuelve la respuesta.','El frontend ya está en el navegador. App Service no tiene que ejecutar cada consulta comercial.'),
  move('entry','client',2.5,'El usuario puede continuar preparando su pedido.','El ejemplo usa datos sintéticos. Ningún sistema corporativo ha sido consultado realmente.'),
  hold('client',3,'Consultar no es validar un pedido.','El portal muestra información comercial. El sistema de pedidos conserva la validación final cuando recibe el pedido.'),
];
const preparation=[
  hold('client',3,'El usuario prepara P-042.','Añade referencias y cantidades para un proyecto. Puede guardar y retomar este pedido sin enviarlo.'),
  move('client','entry',2,'La composición llega al portal.','El usuario solicita ayuda con su composición por la entrada protegida.'),
  move('entry','apim',2,'La petición utiliza la misma fachada.','API Management recibe la composición y su contexto autorizado.'),
  move('apim','backend',2,'El backend comprueba el ámbito.','Solo los usuarios autorizados de la cuenta pueden leer o modificar su composición.'),
  hold('backend',4,'La IA propone un complemento.','El asistente sugiere un accesorio opcional. La sugerencia no cambia el pedido: el usuario conserva el control de su selección.',{assistant:'suggest'}),
  hold('backend',3.5,'Guardamos el pedido para retomarlo.','El portal guarda los productos y cantidades que el usuario ya ha elegido. El complemento sugerido no se añade automáticamente.',{work:['backend']}),
  move('backend','sql',3,'El borrador llega a los datos propios.','La base propia conserva la composición para recuperarla después. Este ejemplo utiliza Azure SQL Database.'),
  hold('sql',6,'El borrador entra en la base de datos.','La puerta se abre, el registro entra y queda conservado. Se guardan la composición, su cuenta y sus líneas.',{persistence:'storing'}),
  hold('sql',3,'P-042 queda guardado en el portal.','El registro permanece dentro. Lo que sale es la confirmación de guardado, todavía no un envío al sistema de pedidos.',{ledger:saved,saved:true,kind:'receipt',label:'Guardado · P-042',persistence:'receipt'}),
  move('sql','backend',2,'El backend recibe la confirmación de guardado.','El borrador permanece en la base al devolver el resultado.'),
  move('backend','apim',2,'El acuse vuelve por la API.','El estado es guardado, todavía no enviado.'),
  move('apim','entry',2,'La respuesta vuelve al portal.','El recorrido de guardado no incluye la cola ni el sistema de pedidos.'),
  move('entry','client',2,'El pedido se puede retomar después.','Cerrar la sesión no equivale a perder la composición persistida.'),
  hold('client',3,'Guardar no significa enviar.','P-042 queda en el portal. Solo una acción de envío inicia la integración con el sistema de pedidos.'),
];
const dispatchStart=[
  hold('client',3,'El usuario decide enviar P-042.','Partimos de un borrador ya guardado. Este recorrido representa una única acción de envío.',{ledger:saved,saved:true}),
  move('client','entry',2,'El envío entra por el canal protegido.','La referencia del pedido y su cuenta viajan con la solicitud.'),
  move('entry','apim',2,'La API recibe la intención de envío.','Aplicar políticas en la fachada no sustituye la autorización del backend.'),
  move('apim','backend',2,'El portal verifica quién puede enviarlo.','El backend comprueba cuenta, permisos y ámbito antes de aceptar el trabajo.'),
  hold('backend',3.5,'El cliente ha decidido enviar su pedido.','El portal prepara el pedido guardado para ponerlo en la cola de envíos. El sistema de pedidos realizará la validación comercial.',{work:['backend']}),
  move('backend','queue',2,'El trabajo entra en Service Bus.','La cola recibe el trabajo pendiente. Todavía no se ha enviado el pedido al sistema de pedidos.',{flow:'continuous'}),
  move('queue','worker',2,'El procesador está disponible y lo recoge.','En este ejemplo continúa sin esperar. Si el procesador estuviera ocupado, el trabajo permanecería pendiente en la cola.',{flow:'continuous',ledger:pending,label:'Pendiente · P-042'}),
  hold('worker',3.5,'El procesador prepara la llamada al sistema de pedidos.','Adapta el contrato y conserva una referencia de seguimiento. No valida por su cuenta precio, mínimos o disponibilidad.',{work:['worker'],ledger:{...pending,submission:'En proceso'},label:'Envío · P-042'}),
  move('worker','orders',4,'Se realiza un intento de envío.','El pedido cruza la integración corporativa. El procesador utiliza el contrato del sistema de pedidos para entregar la solicitud.',{ledger:processing}),
];
const submission=[...dispatchStart,
  hold('orders',3,'El sistema de pedidos comunica la recepción.','En esta variante ilustrativa llega un acuse. Recibir el pedido todavía no equivale a aprobarlo comercialmente.',{ledger:received,kind:'receipt',label:'Acuse · sistema de pedidos · P-042'}),
  move('orders','worker',3,'El acuse vuelve al procesador.','La referencia de recepción permite relacionar el estado con el pedido original.'),
  move('worker','sql',3,'El portal registra el estado de integración.','El portal conserva la recepción comunicada por el sistema de pedidos para poder mostrarla al usuario. Ese registro mantiene la relación con la solicitud original.'),
  hold('sql',2,'La recepción queda disponible para consulta.','El portal podrá recuperar ese estado mediante el backend. El resultado comercial sigue pendiente.'),
  move('sql','backend',2,'El backend consulta el estado propio.','El portal consulta el estado a través del backend. Esta consulta utiliza el registro propio que acaba de actualizar el procesador.'),
  move('backend','apim',2,'El estado vuelve por la API.','Se conserva la separación entre recepción y validación.'),
  move('apim','entry',2,'El portal comunica lo que conoce.','El portal no convierte un acuse técnico en una aprobación comercial.'),
  move('entry','client',2,'Recibido por el sistema de pedidos. Validación pendiente.','Si el sistema de pedidos comunica después aceptación, rechazo u otro resultado, el portal mostrará ese resultado según su contrato.'),
  hold('client',3,'El sistema de pedidos conserva la última palabra comercial.','Precio aplicable, disponibilidad, mínimos y condiciones se validan allí. Esta demostración termina con recepción y validación pendiente.'),
];
const ambiguous=[...dispatchStart,
  hold('orders',4,'No llega una confirmación fiable.','El sistema de pedidos puede haber recibido el pedido y haberse perdido la respuesta. La interrogación representa ese resultado desconocido.',{ledger:unknown,uncertain:true,label:'¿Recibido? · P-042',active:['worker','orders']}),
  hold('orders',4,'La incertidumbre queda registrada en el portal.','La operación permanece con confirmación pendiente. No se declara fallida ni se da por recibida.',{active:['worker','sql','orders']}),
  hold('orders',4,'No sale un segundo pedido.','El pedido puede haber llegado. Se mantiene un solo intento mientras falta confirmación.',{active:['queue','worker','orders']}),
  hold('orders',5,'Comprobar antes de volver a enviar.','Antes de repetir el envío, habrá que comprobar con el sistema de pedidos si el pedido ya existe. Aquí la confirmación sigue pendiente.',{active:['worker','orders','sql']}),
  hold('orders',3,'Confirmación pendiente.', 'El portal conserva el borrador y el estado de la operación. El usuario recibe una explicación de la incertidumbre. Una comprobación posterior permitirá saber qué ocurrió antes de decidir si se repite la operación.',{active:['client','backend','sql','orders']}),
];
const attachmentChapters=[
  {label:'Guardar',title:'El plano queda en el almacén.',copy:'Un cliente adjunta un plano a su consulta técnica. Blob guarda el PDF para poder recuperarlo después.',services:['backend','blob']},
  {label:'Su ficha',title:'La base guarda su ficha.',copy:'El portal registra a qué consulta pertenece y dónde encontrarlo. El PDF permanece en Blob.',services:['blob','sql']},
  {label:'Abrir',title:'El cliente vuelve a abrir su plano.',copy:'El portal comprueba su permiso y pide leer el archivo. El original sigue guardado.',services:['backend','blob']},
  {label:'La copia',title:'Una copia llega al cliente.',copy:'El archivo sigue en Blob y su ficha permanece en la base de datos. Leerlo no vacía el almacén.',services:['blob','sql','client']},
];
const attachments=[
  hold('client',3,'Un plano acompaña a una consulta técnica.','Plano de instalación.pdf es un archivo sintético. Lo adjuntamos a una consulta, no al pedido comercial.'),
  move('client','entry',2,'El adjunto entra por el portal.','El fichero viaja con el contexto de la cuenta que lo aporta.'),
  move('entry','apim',2,'La API recibe el adjunto.','La operación sigue la misma entrada protegida que el resto del portal.'),
  move('apim','backend',2,'El portal comprueba quién puede guardarlo.','El backend verifica cuenta, permisos y relación con la consulta.'),
  hold('backend',2.5,'El backend prepara el almacenamiento.','La consulta conserva su contexto. El contenido del PDF se guardará en Blob, separado de su ficha.',{work:['backend'],chapter:0}),
  move('backend','blob',2,'El archivo llega al almacén.','Azure Blob Storage conserva el contenido del adjunto con acceso controlado.'),
  hold('blob',5,'El plano queda en una balda.','La misma pieza entra y queda guardada. La estantería representa el almacenamiento del fichero.',{storage:'storing'}),
  hold('blob',1.8,'El archivo permanece. Sale su referencia.','El portal recibe una referencia para localizar el adjunto. El PDF sigue dentro del almacén.',{storage:'receipt',attachmentSaved:true,kind:'reference',label:'Ficha · ADJ-042'}),
  move('blob','backend',1.5,'La referencia vuelve al backend.','La referencia identifica el fichero sin transportar otra vez todo su contenido.',{chapter:1}),
  move('backend','sql',1.5,'La base guarda la ficha del adjunto.','La ficha relaciona el archivo con la consulta y la cuenta. El PDF se conserva en Blob.'),
  hold('sql',3.5,'Ficha y fichero quedan relacionados.','La base de datos guarda la referencia y los metadatos. Así se puede localizar el adjunto con sus permisos.',{persistence:'linking'}),
  hold('sql',1.5,'La relación queda guardada.','Se confirma el registro. La referencia guardada permite recuperar el archivo en una consulta posterior.',{persistence:'receipt',attachmentLinked:true,kind:'receipt',label:'Ficha guardada · ADJ-042'}),
  move('sql','backend',1.5,'El portal recupera la ficha.','El cliente vuelve a abrir su plano. El backend dispone de la referencia para localizarlo.',{chapter:2}),
  hold('backend',2,'Se comprueba el permiso de lectura.','El backend comprueba quién puede acceder a la consulta y a su archivo.',{work:['backend']}),
  move('backend','blob',1.5,'El backend pide una lectura del fichero.','El acceso se realiza a través del backend. El almacén privado no se convierte en una descarga pública.',{kind:'reference',label:'Leer · ADJ-042'}),
  hold('blob',4,'Se obtiene una copia para mostrarla.','El fichero guardado permanece en su balda. Una copia de lectura se prepara para el usuario autorizado.',{storage:'reading'}),
  move('blob','backend',1.5,'La copia vuelve al backend.','La lectura no retira ni borra el archivo conservado.',{kind:'file',label:'Copia · ADJ-042',chapter:3}),
  move('backend','apim',1.4,'La vista previa vuelve por la API.','Se entrega sólo el contenido autorizado para esa cuenta.'),
  move('apim','entry',1.4,'La respuesta sale por la entrada protegida.','El usuario recibe el fichero por el canal del portal.'),
  move('entry','client',1.4,'El usuario puede ver su adjunto.','El PDF original sigue en Blob y su ficha en la base de datos.'),
  hold('client',4,'Dos almacenes, dos responsabilidades.','Blob guarda el fichero. La base de datos guarda su relación con la consulta. Gestión Documental conserva su papel corporativo.',{downloaded:true}),
];
function withGate(phases){
  return phases.flatMap(phase=>{
    if(phase.route?.[1]!=='entry')return [phase];
    const inbound=phase.route[0]==='client';
    return [phase,hold('entry',1.25,inbound?'La petición cruza la entrada protegida.':'La respuesta atraviesa la puerta.',inbound?'La puerta se abre antes del paso. Después, la petición continúa hacia la API.':'La misma respuesta cruza hacia el navegador. El control de entrada conserva su función de protección.',{gate:inbound?'in':'out'})];
  });
}
const definitions=[
  {id:'consultation',label:'Consultar',summary:'Disponibilidad y condiciones desde el core.',kind:'request',tokenId:'C-042',focus:['client','entry','apim','backend','erp','pricing'],phases:consultation},
  {id:'preparation',label:'Preparar + IA',summary:'La IA sugiere un complemento opcional y el portal guarda el borrador actual.',kind:'order',tokenId:'P-042',focus:['client','entry','apim','backend','sql'],phases:preparation},
  {id:'submission',label:'Enviar',summary:'Del trabajo pendiente al acuse del sistema de pedidos.',kind:'order',tokenId:'P-042',focus:['backend','sql','queue','worker','orders'],phases:submission},
  {id:'ambiguous',label:'Sin confirmación',summary:'Una respuesta perdida necesita comprobación.',kind:'order',tokenId:'P-042',focus:['backend','sql','queue','worker','orders'],phases:ambiguous},
  {id:'attachments',label:'Archivos',summary:'Un plano de ejemplo. Un archivo en Blob, su ficha en la base y una copia para leerlo.',kind:'file',tokenId:'ADJ-042',focus:['backend','sql','blob'],phases:attachments},
];
for(const scenario of definitions){
  let start=0,ledger={...idle},kind=scenario.kind,label=scenario.tokenId,savedState=false,uncertain=false,attachmentSaved=false,attachmentLinked=false,downloaded=false,chapter=null;
  scenario.phases=withGate(scenario.phases).map((phase,index)=>{
    ledger=phase.ledger||ledger;kind=phase.kind||kind;label=phase.label||label;savedState=phase.saved??savedState;uncertain=phase.uncertain??uncertain;
    attachmentSaved=phase.attachmentSaved??attachmentSaved;attachmentLinked=phase.attachmentLinked??attachmentLinked;downloaded=phase.downloaded??downloaded;
    chapter=phase.chapter??chapter;
    const compiled={...phase,index,start,end:start+phase.seconds,ledger:{...ledger},kind,label,saved:savedState,uncertain,attachmentSaved,attachmentLinked,downloaded,chapter};
    start=compiled.end;return compiled;
  });
  scenario.duration=start;
}
export const SCENARIOS=[...definitions.map(({id,label,summary,duration})=>({id,label,summary,duration})),{id:'capacity',label:'Más demanda',summary:'Más copias del mismo backend. Reglas y límites por validar.',duration:CAPACITY_DURATION},...EXTENSION_SCENARIOS];
export const getPhases=id=>EXTENSION_SCENARIOS.some(s=>s.id===id)?getExtensionPhases(id):id==='capacity'?CAPACITY_PHASES.map((phase,index)=>({...phase,index})):definitions.find(s=>s.id===id)?.phases.map(({start,title,index})=>({at:start,title,index}))||[];
export const getChapters=id=>id==='attachments'?attachmentChapters.map((chapter,index)=>({...chapter,index,at:definitions.find(s=>s.id===id).phases.find(phase=>phase.chapter===index).start})):[];
// Repeat journeys can open at the distinctive work without removing their shared entrance.
export function getStartTime(id,mode='focus'){
  if(mode==='full'||id==='consultation'||id==='capacity')return 0;
  return definitions.find(s=>s.id===id)?.phases.find(phase=>phase.node==='backend'&&(phase.assistant||phase.work?.includes('backend')))?.start??0;
}
// Reading stops retain the explanation on screen after its action has happened.
// File chapters group their transport phases into four distinct ideas.
export function getReadingSteps(id,mode='focus'){
  const definition=SCENARIOS.find(s=>s.id===id);
  if(!definition)return [];
  const phases=getPhases(id),chapters=getChapters(id),start=getStartTime(id,mode);
  const entries=chapters.length?[
    ...phases.filter(phase=>phase.at<chapters[0].at),
    ...chapters.map(chapter=>({at:chapter.at,title:chapter.title})),
  ]:phases;
  return entries.map((entry,index)=>{
    const end=entries[index+1]?.at??definition.duration;
    const checkpoint=index===entries.length-1?end:Math.max(entry.at,end-.05);
    return {start:entry.at,end,checkpoint,title:entry.title};
  }).filter(step=>step.end>start);
}
const smooth=value=>value*value*(3-2*value);
export function sampleScenario(id,time){
  if(EXTENSION_SCENARIOS.some(s=>s.id===id))return sampleExtension(id,time);
  if(id==='capacity'){
    const t=Math.max(0,Math.min(CAPACITY_DURATION,Number(time)||0));
    const phaseIndex=CAPACITY_PHASES.findLastIndex(phase=>t>=phase.at),phase=CAPACITY_PHASES[Math.max(0,phaseIndex)];
    return {scenario:id,time:t,duration:CAPACITY_DURATION,phaseIndex:Math.max(0,phaseIndex),title:phase.title,copy:phase.copy,active:['backend'],focus:['backend'],token:{id:'DEMANDA',node:'backend',visible:false},work:[],workTime:0,ledger:{...idle},saved:false,uncertain:false,capacity:sampleCapacity(t),attachmentSaved:false,attachmentLinked:false};
  }
  const scenario=definitions.find(s=>s.id===id);
  if(!scenario)throw new Error('Recorrido desconocido');
  const t=Math.max(0,Math.min(scenario.duration,Number(time)||0));
  const phase=scenario.phases.find(p=>t<p.end)||scenario.phases.at(-1);
  const elapsed=t-phase.start,fraction=Math.max(0,Math.min(1,elapsed/phase.seconds));
  const progress=phase.flow==='continuous'?fraction:smooth(fraction);
  const active=[...new Set(phase.active||[])];
  // Early entry steps of dispatch still need their origin in view.
  const focus=(id==='submission'||id==='ambiguous'||id==='attachments')&&phase.start<getStartTime(id)?['client','entry','apim','backend']:scenario.focus;
  const chapter=id==='attachments'&&phase.chapter!==null?{...attachmentChapters[phase.chapter],index:phase.chapter}:null;
  return {scenario:id,time:t,duration:scenario.duration,phaseIndex:phase.index,title:chapter?.title??phase.title,copy:chapter?.copy??phase.copy,chapter,phaseTitle:phase.title,phaseCopy:phase.copy,active,focus,
    assistant:phase.assistant?{mode:phase.assistant,progress,modifiesOrder:false}:null,
    token:{id:scenario.tokenId,label:phase.label,kind:phase.kind,...(phase.route?{route:[...phase.route],progress}:{node:phase.node}),visible:true},
    work:[...(phase.work||[])],workTime:Math.max(0,Math.min(3.3,elapsed/phase.seconds*3.3)),
    ledger:{...phase.ledger},saved:phase.saved,uncertain:phase.uncertain,
    gate:phase.gate?{mode:'pass',direction:phase.gate,progress}:null,
    persistence:phase.persistence?{mode:phase.persistence,progress}:null,
    storage:phase.storage?{mode:phase.storage,progress,stored:phase.attachmentSaved}:null,
    attachmentSaved:phase.attachmentSaved,attachmentLinked:phase.attachmentLinked,downloaded:phase.downloaded};
}
