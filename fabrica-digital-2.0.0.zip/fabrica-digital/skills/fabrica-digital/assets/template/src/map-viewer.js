const clamp = (value, low, high) => Math.min(high, Math.max(low, value));

/** A fitted SVG viewport. Only the viewBox changes, so text and logos stay sharp. */
export function createMapViewer({ viewport, svg, zoomIn, zoomOut, fitButton, zoomLabel }) {
  if (!viewport || !svg) throw new TypeError('Se necesitan el mapa y su área de navegación');
  const initial = svg.viewBox.baseVal;
  const bounds = {
    x: initial.x,
    y: initial.y,
    width: Number(svg.dataset.mapWidth) || initial.width,
    height: Number(svg.dataset.mapHeight) || initial.height,
  };
  const MAX_ZOOM = 4;
  const pointers = new Map();
  const cleanups = [];
  let zoom = 1;
  let center = { x: bounds.x + bounds.width / 2, y: bounds.y + bounds.height / 2 };
  let size = { width: 0, height: 0 };
  let view = { ...bounds };
  let gesture = null;
  let suppressClickUntil = 0;
  let disposed = false;

  const listen = (target, type, handler, options) => {
    if (!target) return;
    target.addEventListener(type, handler, options);
    cleanups.push(() => target.removeEventListener(type, handler, options));
  };
  const fitScale = () => Math.min(size.width / bounds.width, size.height / bounds.height);
  const dimensions = () => {
    const scale = fitScale() * zoom;
    return { width: size.width / scale, height: size.height / scale };
  };
  function constrainCenter() {
    const extent = dimensions();
    for (const [axis, length] of [['x', 'width'], ['y', 'height']]) {
      if (extent[length] >= bounds[length]) center[axis] = bounds[axis] + bounds[length] / 2;
      else center[axis] = clamp(center[axis], bounds[axis] + extent[length] / 2 - 24, bounds[axis] + bounds[length] - extent[length] / 2 + 24);
    }
  }
  function render() {
    if (disposed || !size.width || !size.height) return;
    constrainCenter();
    const extent = dimensions();
    view = { x: center.x - extent.width / 2, y: center.y - extent.height / 2, ...extent };
    svg.setAttribute('viewBox', `${view.x} ${view.y} ${view.width} ${view.height}`);
    viewport.dataset.mapZoom = zoom.toFixed(3);
    if (zoomLabel) zoomLabel.textContent = `${Math.round(zoom * 100)}%`;
    if (zoomOut) zoomOut.disabled = zoom <= 1.001;
    if (zoomIn) zoomIn.disabled = zoom >= MAX_ZOOM - .001;
  }
  function refresh() {
    const rect = svg.getBoundingClientRect();
    if (!rect.width || !rect.height) return false;
    size = { width: rect.width, height: rect.height };
    render();
    return true;
  }
  function fit() {
    zoom = 1;
    center = { x: bounds.x + bounds.width / 2, y: bounds.y + bounds.height / 2 };
    refresh();
  }
  function normalizedPoint(clientX, clientY) {
    const rect = svg.getBoundingClientRect();
    return { x: (clientX - rect.left) / rect.width, y: (clientY - rect.top) / rect.height };
  }
  function zoomBy(factor, clientPoint) {
    if (!size.width && !refresh()) return;
    const anchor = clientPoint ? normalizedPoint(clientPoint.x, clientPoint.y) : { x: .5, y: .5 };
    const world = { x: view.x + anchor.x * view.width, y: view.y + anchor.y * view.height };
    zoom = clamp(zoom * factor, 1, MAX_ZOOM);
    const extent = dimensions();
    center = { x: world.x + (.5 - anchor.x) * extent.width, y: world.y + (.5 - anchor.y) * extent.height };
    render();
  }
  function pan(dx, dy) {
    center.x -= dx / size.width * view.width;
    center.y -= dy / size.height * view.height;
    render();
  }
  function reveal(nodeId) {
    const node = [...svg.querySelectorAll('[data-node]')].find(item => item.dataset.node === nodeId);
    if (!node || !refresh()) return;
    const rect = node.getBoundingClientRect(), frame = svg.getBoundingClientRect();
    const margin = 18;
    let dx = 0, dy = 0;
    if (rect.left < frame.left + margin) dx = frame.left + margin - rect.left;
    else if (rect.right > frame.right - margin) dx = frame.right - margin - rect.right;
    if (rect.top < frame.top + margin) dy = frame.top + margin - rect.top;
    else if (rect.bottom > frame.bottom - margin) dy = frame.bottom - margin - rect.bottom;
    if (dx || dy) pan(dx, dy);
  }
  const samples = () => [...pointers.values()];
  const midpoint = points => ({ x: (points[0].x + points[1].x) / 2, y: (points[0].y + points[1].y) / 2 });
  const distance = points => Math.hypot(points[0].x - points[1].x, points[0].y - points[1].y);
  function startGesture() {
    const points = samples();
    if (points.length >= 2) gesture = { kind: 'pinch', middle: midpoint(points), distance: distance(points), moved: true };
    else if (points.length) gesture = { kind: 'pan', origin: { ...points[0] }, last: { ...points[0] }, moved: false };
    else gesture = null;
  }
  listen(viewport, 'pointerdown', event => {
    if (event.button !== 0 || !refresh()) return;
    pointers.set(event.pointerId, { x: event.clientX, y: event.clientY });
    startGesture();
    if (!event.target.closest('[data-node]')) viewport.focus({ preventScroll: true });
  });
  listen(window, 'pointermove', event => {
    if (!pointers.has(event.pointerId) || !gesture) return;
    pointers.set(event.pointerId, { x: event.clientX, y: event.clientY });
    const points = samples();
    if (gesture.kind === 'pinch' && points.length >= 2) {
      const nextMiddle = midpoint(points), nextDistance = distance(points);
      if (gesture.distance > 0) zoomBy(nextDistance / gesture.distance, gesture.middle);
      pan(nextMiddle.x - gesture.middle.x, nextMiddle.y - gesture.middle.y);
      gesture.middle = nextMiddle;
      gesture.distance = nextDistance;
    } else {
      const point = points[0];
      if (!gesture.moved && Math.hypot(point.x - gesture.origin.x, point.y - gesture.origin.y) < 5) return;
      pan(point.x - gesture.last.x, point.y - gesture.last.y);
      gesture.last = point;
      gesture.moved = true;
    }
    viewport.dataset.dragging = 'true';
    suppressClickUntil = performance.now() + 350;
    event.preventDefault();
  }, { passive: false });
  const endPointer = event => {
    if (!pointers.has(event.pointerId)) return;
    if (gesture?.moved) suppressClickUntil = performance.now() + 350;
    pointers.delete(event.pointerId);
    startGesture();
    if (!pointers.size) delete viewport.dataset.dragging;
  };
  listen(window, 'pointerup', endPointer);
  listen(window, 'pointercancel', endPointer);
  listen(window, 'blur', () => { pointers.clear(); gesture = null; delete viewport.dataset.dragging; });
  listen(viewport, 'click', event => {
    if (performance.now() < suppressClickUntil) {
      event.preventDefault();
      event.stopImmediatePropagation();
    }
  }, true);
  listen(viewport, 'wheel', event => {
    if (!refresh()) return;
    const units = event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? size.height : 1;
    zoomBy(Math.exp(-event.deltaY * units * .0015), { x: event.clientX, y: event.clientY });
    event.preventDefault();
  }, { passive: false });
  listen(viewport, 'keydown', event => {
    if (event.altKey || event.metaKey || event.ctrlKey) return;
    const step = event.shiftKey ? 140 : 70;
    const movement = { ArrowLeft: [step, 0], ArrowRight: [-step, 0], ArrowUp: [0, step], ArrowDown: [0, -step] }[event.key];
    if (movement) pan(...movement);
    else if (['+', '='].includes(event.key)) zoomBy(1.25);
    else if (['-', '_'].includes(event.key)) zoomBy(1 / 1.25);
    else if (['0', 'Home'].includes(event.key)) fit();
    else return;
    event.preventDefault();
  });
  listen(svg, 'focusin', event => {
    const node = event.target.closest('[data-node]');
    if (node) reveal(node.dataset.node);
  });
  listen(zoomIn, 'click', () => zoomBy(1.25));
  listen(zoomOut, 'click', () => zoomBy(1 / 1.25));
  listen(fitButton, 'click', fit);
  const observer = new ResizeObserver(refresh);
  observer.observe(viewport);
  refresh();

  return {
    refresh, fit, zoomBy, reveal,
    inspect: () => ({ zoom, fitted: zoom === 1, viewBox: { ...view }, size: { ...size }, bounds: { ...bounds }, dragging: !!gesture?.moved }),
    dispose() {
      disposed = true;
      observer.disconnect();
      cleanups.forEach(cleanup => cleanup());
      pointers.clear();
      delete viewport.dataset.dragging;
    },
  };
}
