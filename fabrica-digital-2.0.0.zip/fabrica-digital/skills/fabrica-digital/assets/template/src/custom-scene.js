import * as THREE from 'three';
import {createAsset} from '../kit/index.js';
import {makeWorkshop} from '../shared/primitives.js';
import {createViewer} from '../shared/viewer.js';
import {createBrandMarks,brandMachine} from '../shared/brand-marks.js';
import {PROJECT,MACHINE_THEME} from './project.js';
import {CUSTOM} from '../examples/custom-architecture/model.js';

/** A deliberately small recipe: arbitrary nodes and routed operation signals.
 * Special storage, queues, physical handoffs and actors belong to a tailored
 * choreography. They are not inferred from a cloud product's name. */
export function createCustomScene(stage,{onSelect=()=>{}}={}){
  const object=new THREE.Group(),decor=makeWorkshop();object.add(decor.root);
  const assets=new Map(),nodes=new Map(),paths=new Map(),geometries=[],materials=[];
  let state=null,mode='guided',shot='',selected=null,disposed=false,pointerStart=null;
  const viewer=createViewer(stage,{padding:1.2,onManual:()=>{mode='manual';}});
  const marks=createBrandMarks({anisotropy:Math.min(8,viewer.renderer.capabilities.getMaxAnisotropy())});
  const labels=document.createElement('div');labels.className='factory-machine-labels';
  labels.style.cssText='position:absolute;inset:0;pointer-events:none;overflow:hidden;z-index:2';
  stage.append(labels);
  const machineRoles={processor:'backend',ingester:'worker',database:'sql',api:'apim',identity:'entry','object-store':'blob',queue:'queue',review:'client',connector:'erp'};
  for(const spec of CUSTOM.nodes){
    const asset=createAsset(spec.asset,{theme:MACHINE_THEME});assets.set(spec.id,asset);
    asset.object.position.fromArray(spec.position);asset.object.rotation.y=spec.rotation||0;asset.object.scale.setScalar(spec.scale||1);
    asset.object.userData.nodeId=spec.id;object.add(asset.object);
    asset.update(0,{processing:false,count:0,open:0,running:false});
    const model=asset.object.userData.model;
    if(model?.userData.document)model.userData.document.visible=false;
    if(spec.icon)brandMachine(marks,asset,machineRoles[spec.asset],{icon:spec.icon,label:spec.label,serviceLabel:spec.service,customer:PROJECT.customer});
    decor.box(5.5,.1,5,decor.palette.ivory,[spec.position[0],-.12,spec.position[2]]);
    asset.object.updateWorldMatrix(true,true);
    const bounds=new THREE.Box3().setFromObject(asset.object),top=new THREE.Vector3(spec.position[0],bounds.max.y+.25,spec.position[2]);
    const dock=asset.object.localToWorld(new THREE.Vector3(...(spec.dock||[0,1.3,2.5])));
    const button=document.createElement('button');button.type='button';button.className='factory-machine-label';button.textContent=spec.label;
    button.style.pointerEvents='auto';button.addEventListener('click',()=>onSelect(spec.id));labels.append(button);
    nodes.set(spec.id,{spec,asset,bounds,top,dock,button});
  }
  const whole=new THREE.Box3();for(const node of nodes.values())whole.union(node.bounds);
  if(PROJECT.customer.logo){
    const center=whole.getCenter(new THREE.Vector3());
    marks.stamp(object,PROJECT.customer.logo,[center.x,.008,whole.max.z+3],[6,2],{rotation:[-Math.PI/2,0,0],resolution:4096,surface:'suelo'});
    whole.expandByPoint(new THREE.Vector3(center.x,0,whole.max.z+5));
  }
  for(const edge of CUSTOM.edges){
    const a=nodes.get(edge.from).dock,b=nodes.get(edge.to).dock;
    const points=edge.points?.map(p=>new THREE.Vector3(...p))||[a,a.clone().lerp(b,.28).add(new THREE.Vector3(0,0,1.1)),a.clone().lerp(b,.72).add(new THREE.Vector3(0,0,1.1)),b];
    const curve=new THREE.CatmullRomCurve3(points);
    const geometry=new THREE.TubeGeometry(curve,48,.055,6,false),material=new THREE.MeshStandardMaterial({color:PROJECT.palette.soft,roughness:.8});
    geometries.push(geometry);materials.push(material);object.add(new THREE.Mesh(geometry,material));
    paths.set(`${edge.from}:${edge.to}`,{curve,reverse:false});paths.set(`${edge.to}:${edge.from}`,{curve,reverse:true});
  }
  const signal=createAsset('document');signal.update(0,{kind:'job'});object.add(signal.object);
  signal.object.scale.setScalar(.8);
  function boundsFor(ids){const box=new THREE.Box3();for(const id of ids||[])if(nodes.has(id))box.union(nodes.get(id).bounds);return box.isEmpty()?whole.clone():box;}
  function focus(ids,immediate=false){
    const box=boundsFor(ids),route=state?.token?.route||[];
    const path=paths.get(route.join(':'));
    if(path)for(const point of path.curve.getPoints(24))box.expandByPoint(point);
    viewer.focus(box.expandByScalar(.65),{immediate,padding:1.3});
  }
  function update(next){
    state=next;
    for(const [id,asset] of assets){
      const working=next.work?.includes(id)||false;
      asset.update(working?next.workTime:0,{processing:working,open:working?1:0,authorized:working,running:working,count:0});
      const model=asset.object.userData.model;if(model?.userData.document)model.userData.document.visible=false;
    }
    const route=next.token.route||[next.token.node,next.token.node],path=paths.get(route.join(':')),a=nodes.get(route[0]),b=nodes.get(route.at(-1));
    if(!a||!b)throw new Error('Un paso hace referencia a una máquina que no existe.');
    const t=next.token.progress??next.token.t??0;
    if(path)signal.object.position.copy(path.curve.getPointAt(path.reverse?1-t:t));
    else signal.object.position.copy(a.dock);
    signal.object.visible=next.token.visible;
    const key=[...(next.focus||[])].sort().join(':');
    if(mode==='guided'&&shot!==key){shot=key;focus(next.focus);}
  }
  function project(point){const p=point.clone().project(viewer.camera);return {x:(p.x/2+.5)*stage.clientWidth,y:(-p.y/2+.5)*stage.clientHeight,z:p.z};}
  const overlap=(a,b)=>Math.max(0,Math.min(a.x+a.w,b.x+b.w)-Math.max(a.x,b.x))*Math.max(0,Math.min(a.y+a.h,b.y+b.h)-Math.max(a.y,b.y));
  function screenBox(box){
    const points=[];for(const x of [box.min.x,box.max.x])for(const y of [box.min.y,box.max.y])for(const z of [box.min.z,box.max.z])points.push(project(new THREE.Vector3(x,y,z)));
    const x=Math.min(...points.map(p=>p.x)),y=Math.min(...points.map(p=>p.y));return {x,y,w:Math.max(...points.map(p=>p.x))-x,h:Math.max(...points.map(p=>p.y))-y};
  }
  function layoutLabels(){
    const w=stage.clientWidth,h=stage.clientHeight,occupied=[],obstacles=[...nodes.values()].map(n=>screenBox(n.bounds));
    const ticket=project(signal.object.position);obstacles.push({x:ticket.x-24,y:ticket.y-16,w:48,h:32});
    const order=[...nodes.values()].sort((a,b)=>Number(b.spec.id===selected)-Number(a.spec.id===selected));
    for(const n of order){
      const point=project(n.top),active=mode==='overview'||selected===n.spec.id||state?.focus.includes(n.spec.id);
      n.button.hidden=!active||point.z < -1||point.z>1;if(n.button.hidden)continue;
      const bw=n.button.offsetWidth||150,bh=n.button.offsetHeight||32,box=screenBox(n.bounds),candidates=[];
      for(const [x,y] of [[point.x-bw/2,box.y-bh-14],[box.x-bw-14,box.y],[box.x+box.w+14,box.y],[point.x-bw/2,box.y+box.h+12],...[12,h-bh-14].flatMap(y=>[12,(w-bw)/2,w-bw-12].map(x=>[x,y]))]){
        const r={x:Math.max(8,Math.min(w-bw-8,x)),y:Math.max(8,Math.min(h-bh-8,y)),w:bw,h:bh};
        r.cost=obstacles.reduce((sum,b)=>sum+overlap(r,b)*10,0)+occupied.reduce((sum,b)=>sum+overlap(r,b)*100,0)+Math.hypot(r.x+bw/2-point.x,r.y+bh/2-point.y);candidates.push(r);
      }
      candidates.sort((a,b)=>a.cost-b.cost);const best=candidates[0];
      if(occupied.some(b=>overlap(best,b)>0)){n.button.hidden=true;continue;}
      n.button.style.left=`${best.x}px`;n.button.style.top=`${best.y}px`;occupied.push(best);
    }
  }
  function render(){if(disposed)return;viewer.render();layoutLabels();}
  function reset(ids){mode='guided';selected=null;shot='';focus(ids||state?.focus);}
  function overview(){mode='overview';selected=null;viewer.focus(whole.clone().expandByScalar(1),{padding:1.2});}
  function select(id){if(!nodes.has(id)){if(selected)reset();return;}mode='selected';selected=id;focus([id]);}
  const raycaster=new THREE.Raycaster(),pointer=new THREE.Vector2();
  const down=e=>{pointerStart=e.button===0?[e.clientX,e.clientY]:null;};
  const up=e=>{
    if(!pointerStart||Math.hypot(e.clientX-pointerStart[0],e.clientY-pointerStart[1])>6)return;
    pointerStart=null;const r=viewer.renderer.domElement.getBoundingClientRect();pointer.set((e.clientX-r.left)/r.width*2-1,1-(e.clientY-r.top)/r.height*2);raycaster.setFromCamera(pointer,viewer.camera);
    for(const hit of raycaster.intersectObjects([...assets.values()].map(a=>a.object),true)){let n=hit.object;while(n&&!n.userData.nodeId)n=n.parent;if(n){onSelect(n.userData.nodeId);break;}}
  };
  viewer.renderer.domElement.addEventListener('pointerdown',down);viewer.renderer.domElement.addEventListener('pointerup',up);
  viewer.mount({object});viewer.focus(whole,{immediate:true});
  function inspect(){return {custom:true,token:{uuid:signal.object.uuid,position:signal.object.position.toArray(),visible:signal.object.visible},nodes:[...nodes.keys()],viewer:viewer.inspect(),brandRendering:marks.inspect()};}
  function dispose(){disposed=true;viewer.renderer.domElement.removeEventListener('pointerdown',down);viewer.renderer.domElement.removeEventListener('pointerup',up);signal.dispose();for(const a of assets.values())a.dispose();marks.dispose();decor.dispose();for(const g of geometries)g.dispose();for(const m of materials)m.dispose();labels.remove();viewer.dispose();}
  return {update,render,reset,overview,select,inspect,dispose,setClock:fn=>viewer.setClock(fn)};
}
