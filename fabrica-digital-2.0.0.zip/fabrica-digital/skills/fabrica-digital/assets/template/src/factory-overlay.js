import * as THREE from 'three';
import { makeWorkshop } from '../shared/primitives.js';
import { createAIRobot, createWhiteHatTester } from '../shared/characters.js';

const clamp = value => THREE.MathUtils.clamp(Number.isFinite(value) ? value : 0, 0, 1);
const ease = value => { const t = clamp(value); return t * t * (3 - 2 * t); };
const part = (value, from, to) => ease((value - from) / (to - from));
const V = values => new THREE.Vector3().fromArray(values);

/** Illustrative activities around the actual Portal factory. These objects do
 * not replace its services, and no customer request is sent to the order system here. */
export function createFactoryOverlay({ nodes, edges }) {
  const object = new THREE.Group();
  object.name = 'Actividades sobre la fábrica';
  const workshop = makeWorkshop(); object.add(workshop.root);
  const { palette: p, box, cylinder, rod, label } = workshop;
  const pentest = new THREE.Group(), agents = new THREE.Group();
  pentest.name = 'Pentesting externo · ilustración de una validación futura';
  agents.name = 'Acceso de agentes · propuesta para debatir';
  workshop.root.add(pentest, agents);
  let disposed = false, sampled = null;
  const add = (parent, item) => { parent.add(item); return item; };
  const material = (color, options = {}) => new THREE.MeshStandardMaterial({ color, roughness: .48, metalness: .12, ...options });
  const client = nodes.get('client');
  const clientModel = client?.asset.object.userData.model;
  const human = clientModel?.userData.human;
  const chair = clientModel?.userData.chair;
  if (!client || !human || !chair) throw new Error('La escena de agentes necesita el puesto original del cliente, su persona y su silla.');
  const originalHuman = {
    position: human.position.clone(), quaternion: human.quaternion.clone(), scale: human.scale.clone(), visible: human.visible,
    legs: (human.userData.legs || []).map(leg => leg.quaternion.clone()),
    feet: (human.userData.feet || []).map(foot => foot.quaternion.clone()),
  };
  const originalChair = { position: chair.position.clone(), quaternion: chair.quaternion.clone(), scale: chair.scale.clone(), visible: chair.visible };
  client.asset.object.updateMatrixWorld(true);
  const clientPoint = point => clientModel.localToWorld(V(point));
  const atNode = (id, point) => nodes.get(id).asset.object.localToWorld(V(point));
  const nodePoint = id => nodes.get(id).dock.clone();
  const entryPosition = nodes.get('entry').asset.object.position.clone();
  const backendPosition = nodes.get('backend').asset.object.position.clone();
  const clientFrame = new THREE.Group();
  clientFrame.matrixAutoUpdate = false; clientFrame.matrix.copy(clientModel.matrixWorld); agents.add(clientFrame);

  function restoreClient() {
    human.position.copy(originalHuman.position); human.quaternion.copy(originalHuman.quaternion); human.scale.copy(originalHuman.scale); human.visible = originalHuman.visible;
    (human.userData.legs || []).forEach((leg, index) => leg.quaternion.copy(originalHuman.legs[index]));
    (human.userData.feet || []).forEach((foot, index) => foot.quaternion.copy(originalHuman.feet[index]));
    chair.position.copy(originalChair.position); chair.quaternion.copy(originalChair.quaternion); chair.scale.copy(originalChair.scale); chair.visible = originalChair.visible;
    client.asset.object.updateMatrixWorld(true);
  }

  function paper(parent, title, color = 0xf9f3e6) {
    const group = new THREE.Group(); parent.add(group); group.name = title;
    const skin = material(color, { roughness: .8, metalness: 0 });
    add(group, box(1.12, .065, .84, skin, [0, 0, 0], .025));
    add(group, box(.11, .014, .71, p.teal, [-.46, .042, 0], .005));
    const tag = add(group, label(title, [.07, .044, -.16], { width: .84, height: .22, color: '#58465d', background: null }));
    tag.rotation.x = -Math.PI / 2;
    for (let i = 0; i < 3; i++) add(group, box(.66 - .08 * (i % 2), .011, .025, p.steel, [.06, .047, .015 + i * .105], .003));
    return { object: group, skin, tag };
  }

  // Keep the familiar assistant's upper body, with legs that really bend at
  // the knees. Its original first six meshes are the fixed feet and shins.
  const robot = createAIRobot(); clientFrame.add(robot.object);
  robot.object.name = 'Agente IA en la silla original del cliente';
  const robotRoot = robot.object.children[0];
  const originalRobotLegs = robotRoot.children.slice(0, 6);
  originalRobotLegs.forEach(piece => { piece.visible = false; });
  const robotLegs = [], robotKnees = [], robotFeet = [], robotShins = [];
  for (const x of [-.23, .23]) {
    const hip = new THREE.Group(); hip.position.set(x, .6, 0); robotRoot.add(hip);
    const joint = add(hip, cylinder(.12, .22, p.steel)); joint.rotation.z = Math.PI / 2;
    add(hip, box(.24, .29, .25, p.ivory, [0, -.15, 0], .055));
    const knee = new THREE.Group(); knee.position.set(0, -.3, 0); hip.add(knee);
    const kneeJoint = add(knee, cylinder(.105, .22, p.steel)); kneeJoint.rotation.z = Math.PI / 2;
    const shin = add(knee, box(.19, .25, .2, p.ivory, [0, -.125, 0], .04));
    const foot = new THREE.Group(); foot.position.set(0, -.255, 0); knee.add(foot);
    add(foot, box(.27, .12, .4, p.dark, [0, -.005, .06], .04));
    robotLegs.push(hip); robotKnees.push(knee); robotFeet.push(foot); robotShins.push(shin);
  }
  const robotBack = add(robotRoot, box(.49, .3, .025, p.teal, [0, .89, -.236], .05));
  robotBack.name = 'IA · identificación visible desde el puesto';
  const robotBackLabel = add(robotRoot, label('IA', [0, .9, -.257], { width: .36, height: .23, color: '#fffaf0', background: null }));
  robotBackLabel.rotation.y = Math.PI;
  const robotScale = 1.08;
  robot.object.scale.setScalar(robotScale);
  const robotStart = V([-3.8, 0, 3.3]), robotCorner = V([-1.7, 0, 2.55]);
  const chairCenter = originalChair.position.clone();
  const robotSeat = chairCenter.clone().add(new THREE.Vector3(0, .205, -.005));
  const robotApproach = chairCenter.clone().add(new THREE.Vector3(0, 0, .45));
  const humanAside = originalHuman.position.clone().add(new THREE.Vector3(2.35, -.08, .72));
  // A pointing surface on the existing desk gives the agent a visible,
  // physical interaction with the computer. The arm stops on this surface.
  const pointerPad = add(clientFrame, box(.3, .025, .18, p.steel, [-.425, 1.242, .15], .025));
  function robotPose(sitting, stride, time) {
    robot.update(time, { working: sitting > .98, progress: .4, workTarget: [1.25, .68], contact: 1 });
    robotLegs.forEach((hip, index) => {
      hip.rotation.x = -Math.PI / 2 * sitting + stride * (index ? -1 : 1) * (1 - sitting);
      robotKnees[index].rotation.x = Math.PI / 2 * sitting;
      robotFeet[index].rotation.x = -stride * (index ? -1 : 1) * (1 - sitting);
      // Telescopic robot shins keep the soles on the floor while the hips
      // fold onto the existing chair, instead of leaving short legs dangling.
      const groundedLength = .6 - .3 * Math.cos(hip.rotation.x) - (.075 - robot.object.position.y) / robotScale;
      const length = THREE.MathUtils.lerp(.255, groundedLength, sitting);
      robotShins[index].scale.y = length / .25; robotShins[index].position.y = -length / 2;
      robotFeet[index].position.y = -length;
    });
    robot.object.userData.seated = sitting >= .99;
  }
  const reviewTray = new THREE.Group(); clientFrame.add(reviewTray); reviewTray.position.set(1.65, .99, 1.84);
  add(reviewTray, box(1.45, .09, 1.05, p.ivory));
  add(reviewTray, box(.1, 1, .1, p.steel, [-.55, -.53, 0]));
  add(reviewTray, box(.1, 1, .1, p.steel, [.55, -.53, 0]));
  const reviewTag = add(reviewTray, label('REVISA LA PERSONA', [0, .065, .67], { width: 2.2, height: .29, color: '#785a81', background: null }));
  reviewTag.rotation.x = -Math.PI / 2;
  const agentDocument = paper(agents, 'BORRADOR', 0xf1e9fa);
  const approvalHalo = add(reviewTray, cylinder(.82, .013, material(0xaa88bd, { transparent: true, opacity: .17, depthWrite: false }), [0, .064, 0]));
  approvalHalo.scale.z = .7;

  function chain(ids) {
    const pieces = [];
    for (let index = 0; index < ids.length - 1; index++) {
      const from = ids[index], to = ids[index + 1];
      const edge = edges.get(`${from}-${to}`), reverse = edges.get(`${to}-${from}`);
      if (!edge && !reverse) throw new Error(`Falta la conexión de fábrica ${from} → ${to}.`);
      const source = edge || reverse, reversed = !edge;
      const points = source.curve.getSpacedPoints(80); if (reversed) points.reverse();
      if (pieces.length) {
        const previous = pieces[pieces.length - 1], first = points[0];
        const distance = previous.distanceTo(first);
        if (distance > .001) for (let step = 1; step < 8; step++) pieces.push(previous.clone().lerp(first, step / 8));
      }
      pieces.push(...points);
    }
    const lengths = [0];
    for (let index = 1; index < pieces.length; index++) lengths.push(lengths[index - 1] + pieces[index - 1].distanceTo(pieces[index]));
    return { points: pieces, lengths, length: lengths[lengths.length - 1], ids };
  }
  function followChain(route, amount) {
    const distance = clamp(amount) * route.length;
    let index = 1; while (index < route.lengths.length - 1 && route.lengths[index] < distance) index++;
    const from = route.points[index - 1], to = route.points[index];
    const fraction = (distance - route.lengths[index - 1]) / Math.max(.0001, route.lengths[index] - route.lengths[index - 1]);
    return { point: from.clone().lerp(to, fraction), direction: to.clone().sub(from).normalize() };
  }
  const agentRoute = chain(['client', 'entry', 'apim', 'backend']);
  const identityRoute = chain(['entry', 'apim', 'backend']);
  function placeDocument(document, route, amount) {
    const { point, direction } = followChain(route, amount);
    document.object.position.copy(point); document.object.rotation.set(0, Math.atan2(direction.x, direction.z), 0);
  }
  const expectedEntryBack = atNode('entry', [0, 1.05, -1.4]);

  // The external professional stays outside Portal, next to its actual entry.
  const testerPosition = entryPosition.clone().add(new THREE.Vector3(-6.8, 0, -.5));
  const testerStage = new THREE.Group(); pentest.add(testerStage); testerStage.position.copy(testerPosition);
  add(testerStage, box(3.65, .13, 3.3, p.ivory, [0, -.065, 0], .08));
  const testerLabel = add(testerStage, label('PENTESTING EXTERNO', [0, .009, 1.27], { width: 3.5, height: .42, color: '#70583c', background: null }));
  testerLabel.rotation.x = -Math.PI / 2;
  const tester = createWhiteHatTester();
  tester.object.position.set(-.74, .04, 0); tester.object.rotation.y = Math.PI / 2; testerStage.add(tester.object);
  const testerHome = tester.object.position.clone();
  const testerArrival = testerHome.clone().add(new THREE.Vector3(-2.15, 0, 1.05));
  add(testerStage, box(1.34, .11, .88, p.ivory, [.65, 1.18, 0], .05));
  for (const x of [.15, 1.15]) add(testerStage, box(.085, 1.15, .085, p.steel, [x, .59, 0], .015));
  add(testerStage, box(.95, .065, .55, p.dark, [.65, 1.28, 0], .045));
  const laptopScreen = new THREE.Group(); testerStage.add(laptopScreen); laptopScreen.position.set(.65, 1.32, -.25); laptopScreen.rotation.x = -.13;
  add(laptopScreen, box(.96, .65, .055, p.dark, [0, .31, 0], .045));
  add(laptopScreen, box(.83, .52, .025, p.ivory, [0, .32, .035], .025));
  const scopeTag = add(laptopScreen, label('PRUEBAS', [0, .38, .057], { width: .72, height: .18, color: '#785837', background: null }));
  const probeOrigin = testerPosition.clone().add(new THREE.Vector3(1.15, 1.5, .1));
  const testerHomeWorld = testerPosition.clone().add(testerHome);
  const walkIntoFactory = [testerHomeWorld, entryPosition.clone().add(new THREE.Vector3(-4.8, .04, 2.5)), entryPosition.clone().add(new THREE.Vector3(0, .04, 3.8)), entryPosition.clone().add(new THREE.Vector3(0, .04, 1.5)), entryPosition.clone().add(new THREE.Vector3(0, .04, -2.4)), entryPosition.clone().add(new THREE.Vector3(2.6, .04, -2.4))];
  function pathPose(points, amount) {
    const lengths = points.slice(1).map((point, index) => point.distanceTo(points[index]));
    let distance = clamp(amount) * lengths.reduce((sum, length) => sum + length, 0);
    for (let index = 0; index < lengths.length; index++) {
      if (distance <= lengths[index] || index === lengths.length - 1) return { point: points[index].clone().lerp(points[index + 1], clamp(distance / lengths[index])), direction: points[index + 1].clone().sub(points[index]).normalize() };
      distance -= lengths[index];
    }
    return { point: points[0].clone(), direction: new THREE.Vector3(0, 0, 1) };
  }
  function poseTester(point, angle, walking, time) {
    tester.object.position.copy(point).sub(testerPosition); tester.object.rotation.y = angle;
    tester.update(time, { walking, document: false, identified: true });
  }

  function makeShield(name, position, width = 1, angle = 0) {
    const group = new THREE.Group(); pentest.add(group); group.position.copy(position); group.rotation.y = angle; group.scale.setScalar(width); group.name = name;
    const outline = [[0, 1.64], [1.32, 1.11], [1.18, -.25], [.72, -.98], [0, -1.46], [-.72, -.98], [-1.18, -.25], [-1.32, 1.11]];
    const shapeFrom = scale => { const shape = new THREE.Shape(); outline.forEach(([x, y], index) => index ? shape.lineTo(x * scale, y * scale) : shape.moveTo(x * scale, y * scale)); shape.closePath(); return shape; };
    const rimShape = shapeFrom(1);
    const hole = new THREE.Path(); [...outline].reverse().forEach(([x, y], index) => index ? hole.lineTo(x * .84, y * .84) : hole.moveTo(x * .84, y * .84)); hole.closePath(); rimShape.holes.push(hole);
    const frameMaterial = material(0x63757c, { metalness: .82, roughness: .25 });
    const rim = new THREE.Mesh(new THREE.ExtrudeGeometry(rimShape, { depth: .2, bevelEnabled: true, bevelSize: .055, bevelThickness: .045, bevelSegments: 2, steps: 1 }), frameMaterial); group.add(rim); rim.castShadow = true;
    const faceMaterial = material(0x599bb5, { transparent: true, opacity: .54, emissive: 0x3b839e, emissiveIntensity: .16, roughness: .23, metalness: .3, side: THREE.DoubleSide, depthWrite: false });
    const face = new THREE.Mesh(new THREE.ExtrudeGeometry(shapeFrom(.855), { depth: .065, bevelEnabled: false }), faceMaterial); face.position.z = .21; group.add(face); face.renderOrder = 3;
    const edgeMaterial = material(0x90d5e5, { emissive: 0x4aabc7, emissiveIntensity: .4, roughness: .24, metalness: .32 });
    for (let index = 0; index < outline.length; index++) {
      const a = outline[index], b = outline[(index + 1) % outline.length];
      add(group, rod([a[0] * .91, a[1] * .91, .295], [b[0] * .91, b[1] * .91, .295], .032, edgeMaterial));
    }
    // A lock, rather than an approved tick: the boundary is being tested.
    add(group, box(.48, .45, .09, edgeMaterial, [0, -.02, .26], .06));
    const lockBow = new THREE.Mesh(new THREE.TorusGeometry(.19, .052, 8, 22, Math.PI), edgeMaterial); lockBow.position.set(0, .22, .26); group.add(lockBow);
    add(group, cylinder(.052, .12, p.dark, [0, -.03, .33])).rotation.x = Math.PI / 2;
    const shockwaves = [];
    for (let index = 0; index < 3; index++) {
      const shockMaterial = new THREE.MeshBasicMaterial({ color: 0xd8f8ff, transparent: true, opacity: 0, depthWrite: false, toneMapped: false });
      const shock = new THREE.Mesh(new THREE.TorusGeometry(.36, .031, 6, 42), shockMaterial); shock.position.set(0, .14, .34 + index * .015); group.add(shock); shockwaves.push(shock);
    }
    const flashMaterial = new THREE.MeshBasicMaterial({ color: 0xd6f6ff, transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false, toneMapped: false });
    const flash = new THREE.Mesh(new THREE.CircleGeometry(.44, 32), flashMaterial); flash.position.set(0, .14, .31); group.add(flash);
    function update(impact = 0, wave = 0) {
      faceMaterial.opacity = .54 + .18 * impact; faceMaterial.emissiveIntensity = .16 + .95 * impact;
      edgeMaterial.emissiveIntensity = .42 + 1.6 * impact; flashMaterial.opacity = .6 * impact;
      shockwaves.forEach((shock, index) => {
        const age = (wave + index / 3) % 1;
        shock.visible = impact > .015;
        shock.scale.setScalar(.4 + age * 3.4); shock.material.opacity = (1 - age) * impact * .8;
      });
    }
    group.updateMatrixWorld(true);
    const normal = new THREE.Vector3(Math.sin(angle), 0, Math.cos(angle));
    const rotation = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), angle);
    let emergence = 1, growth = 1;
    // A shared face plane drives contact, projectile clearance and particles.
    // At z=.30, effects sit just outside the .275-deep energy surface.
    function facePoint(x = 0, y = .14) {
      return new THREE.Vector3(x * width * growth, y * width * growth, .30 * width)
        .applyQuaternion(rotation).add(position).add(new THREE.Vector3(0, width * 1.46 * (growth - 1), 0));
    }
    const distanceToFace = point => point.clone().sub(facePoint(0, 0)).dot(normal);
    function emerge(amount = 1, expansion = 1) {
      emergence = clamp(amount); growth = expansion;
      group.scale.set(width * (.6 + .4 * emergence) * growth, width * emergence * growth, width);
      group.position.y = position.y - width * 1.46 * (1 - emergence * growth);
      group.visible = emergence > .001;
    }
    return { object: group, update, emerge, faceMaterial, position, normal, rotation, facePoint, distanceToFace, hitPoint: () => facePoint(), inspect: () => ({ name, opacity: faceMaterial.opacity, solidFrame: true, frameDepth: .2, shockwaves: shockwaves.filter(w => w.visible).length, position: group.position.toArray(), visible: group.visible, emergence, growth, normal: normal.toArray(), contactPlane: facePoint(0, 0).toArray(), angle }) };
  }
  // Both the tester and the audience see this outside face. The old almost
  // frontal shield placed the launch position behind its membrane.
  const entryShield = makeShield('Prueba en la entrada protegida original', entryPosition.clone().add(new THREE.Vector3(0, 1.73, 2.15)), 1.18, -Math.PI / 4);
  const backendShield = makeShield('Permisos en el backend original', backendPosition.clone().add(new THREE.Vector3(0, 1.7, 2.6)), .94, 0);
  const shieldCaption = add(pentest, label('PRUEBAS ILUSTRATIVAS · PENDIENTES DE VALIDAR', entryPosition.clone().add(new THREE.Vector3(-2.1, .03, 4.2)).toArray(), { width: 8.3, height: .44, color: '#866540', background: null }));
  shieldCaption.rotation.x = -Math.PI / 2;
  const ATTACK_COLOR = 0xd79b55;
  const probeMaterial = material(ATTACK_COLOR, { emissive: 0xc78935, emissiveIntensity: .6 });
  const particlePools = {};
  function instancePool(key, geometry, skin, capacity) {
    const mesh = new THREE.InstancedMesh(geometry, skin, capacity);
    mesh.name = `Pentest · ${key}`; mesh.count = 0; mesh.frustumCulled = false;
    mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage); pentest.add(mesh); particlePools[key] = mesh;
    return mesh;
  }
  // One body, one trail, one shard and one ring draw call for the whole burst.
  // No object is created while sampling an animation frame.
  const projectilePool = instancePool('peticiones', new THREE.BoxGeometry(.17, .13, .46), probeMaterial, 32);
  const trailPool = instancePool('estelas', new THREE.CylinderGeometry(.019, .04, 1, 5), new THREE.MeshBasicMaterial({ color: 0xe4a655, transparent: true, opacity: .74, depthWrite: false }), 32);
  const shardPool = instancePool('desintegración exterior', new THREE.BoxGeometry(.10, .065, .075), new THREE.MeshBasicMaterial({ color: 0xffc16f, transparent: true, opacity: .9, depthWrite: false, toneMapped: false }), 160);
  const impactPool = instancePool('anillos de impacto', new THREE.RingGeometry(.31, .35, 18), new THREE.MeshBasicMaterial({ color: 0xffe2a4, side: THREE.DoubleSide, transparent: true, opacity: .72, depthWrite: false, toneMapped: false }), 24);
  shardPool.renderOrder = 5; impactPool.renderOrder = 5;
  const particleTransform = new THREE.Object3D();
  function putInstance(pool, position, rotation, scale = new THREE.Vector3(1, 1, 1)) {
    if (pool.count >= pool.instanceMatrix.count) return;
    particleTransform.position.copy(position); particleTransform.quaternion.copy(rotation); particleTransform.scale.copy(scale); particleTransform.updateMatrix();
    pool.setMatrixAt(pool.count++, particleTransform.matrix);
  }
  const scopeProbe = paper(pentest, 'OTRA CUENTA', ATTACK_COLOR); scopeProbe.object.scale.setScalar(.86);
  scopeProbe.skin.copy(probeMaterial);
  const attackSchedule = [{ slot: 0, start: .02, impact: .205, first: true, x: -.48, y: .56 }];
  for (let index = 0; index < 96; index++) {
    const start = .265 + index * .00675, angle = index * 2.3999632297;
    const radius = .28 + .34 * (index % 5) / 4;
    attackSchedule.push({ slot: index % 8, start, impact: start + .074, first: false, x: Math.sin(angle) * radius, y: .15 + Math.cos(angle) * .67 });
  }
  // The account probe stops on the incoming side of the backend's shield.
  // It never continues along a data connection and has no return trajectory.
  const backendBoundaryZ = backendShield.hitPoint().z + .57;
  let identityStop = .96;
  for (let index = identityRoute.points.length - 1; index > 0; index--) {
    const a = identityRoute.points[index - 1], b = identityRoute.points[index];
    if (Math.abs(b.x - backendPosition.x) < 1.2 && a.z >= backendBoundaryZ && b.z <= backendBoundaryZ) {
      const f = (a.z - backendBoundaryZ) / Math.max(.0001, a.z - b.z);
      identityStop = (identityRoute.lengths[index - 1] + a.distanceTo(b) * f) / identityRoute.length;
      break;
    }
  }
  const accountStop = followChain(identityRoute, identityStop).point;
  const accountContact = accountStop.clone().addScaledVector(backendShield.normal, -backendShield.distanceToFace(accountStop));
  const report = paper(pentest, 'HALLAZGOS', 0xfff4de);
  const reportTarget = testerPosition.clone().add(new THREE.Vector3(.68, 1.36, .28));
  const reportSource = backendPosition.clone().add(new THREE.Vector3(0, 2.6, 2.8));
  const reportCurve = new THREE.CatmullRomCurve3([reportSource, reportSource.clone().add(new THREE.Vector3(-4, 1.4, 3)), reportTarget.clone().add(new THREE.Vector3(3.5, 1.8, 2)), reportTarget]);
  const evidenceRibbon = new THREE.Mesh(new THREE.TubeGeometry(reportCurve, 60, .024, 5, false), material(0xc8b899, { transparent: true, opacity: .42 })); pentest.add(evidenceRibbon);
  let activeRoute = null, scopeBlocked = false, probeEndpoints = [], testerWalking = false, stage = null, destroyedCount = 0, authorizedSession = false, fragmentPlaneDistances = [];

  function hideTransient() {
    agentDocument.object.visible = false; reviewTray.visible = false;
    agentDocument.object.position.copy(nodePoint('client')); agentDocument.object.rotation.set(0, 0, 0); agentDocument.object.scale.setScalar(.93);
    robot.object.position.copy(robotStart); robot.object.rotation.set(0, 0, 0); robotPose(0, 0, 0);
    Object.values(particlePools).forEach(pool => { pool.count = 0; });
    scopeProbe.object.visible = false; report.object.visible = false; evidenceRibbon.visible = false;
    entryShield.emerge(0); backendShield.emerge(0);
    entryShield.update(0, 0); backendShield.update(0, 0);
    poseTester(testerHomeWorld, Math.PI / 2, false, 0);
    activeRoute = null; scopeBlocked = false; probeEndpoints = []; testerWalking = false; stage = null; destroyedCount = 0; authorizedSession = false; fragmentPlaneDistances = [];
  }

  function updateAgents(phase, progress, time) {
    const transfer = phase === 0 ? progress : 1;
    const rise = part(transfer, .025, .16), aside = part(transfer, .14, .43);
    human.position.copy(originalHuman.position).lerp(humanAside, aside);
    human.position.y += .18 * rise * (1 - aside);
    human.rotation.y = Math.PI + (Math.PI / 2) * aside;
    human.userData.setStride?.(transfer > .14 && transfer < .43 ? Math.sin(transfer * Math.PI * 22) * .28 : 0);
    const walking = part(transfer, .38, .83), sitting = part(transfer, .83, 1);
    if (walking < .5) robot.object.position.copy(robotStart).lerp(robotCorner, walking * 2);
    else robot.object.position.copy(robotCorner).lerp(robotApproach, (walking - .5) * 2);
    robot.object.position.lerp(robotSeat, sitting);
    const walkingAngle = walking < .5 ? Math.atan2(robotCorner.x - robotStart.x, robotCorner.z - robotStart.z) : Math.atan2(robotApproach.x - robotCorner.x, robotApproach.z - robotCorner.z);
    robot.object.rotation.set(0, THREE.MathUtils.lerp(walkingAngle, Math.PI, part(transfer, .73, .87)), 0);
    robotPose(sitting, transfer > .38 && transfer < .83 ? Math.sin(transfer * Math.PI * 25) * .36 : 0, time);
    robot.object.visible = true;
    reviewTray.visible = phase === 3 || phase === 4;
    agentDocument.object.visible = phase === 2 || phase === 3 || phase === 4;
    agentDocument.object.scale.setScalar(.93); agentDocument.object.rotation.set(0, 0, 0);
    if (phase === 2) {
      placeDocument(agentDocument, agentRoute, ease(progress)); activeRoute = agentRoute.ids;
    } else if (phase === 3) {
      // Return over the same entry/API path, then hand the draft to the person.
      const back = part(progress, 0, .76), handover = part(progress, .76, 1);
      placeDocument(agentDocument, agentRoute, 1 - back); activeRoute = [...agentRoute.ids].reverse();
      if (handover > 0) agentDocument.object.position.copy(nodePoint('client')).lerp(clientPoint([1.65, 1.11, 1.84]), handover);
    } else if (phase === 4) agentDocument.object.position.copy(clientPoint([1.65, 1.11, 1.84]));
    if (phase >= 3) {
      const reading = phase === 4 ? 1 : part(progress, .83, 1);
      human.rotation.y = THREE.MathUtils.lerp(Math.PI * 1.5, Math.PI + .25, reading);
      approvalHalo.material.opacity = .13 + .07 * reading;
    }
    const passing = phase === 2 && progress > .13 && progress < .46 || phase === 3 && progress > .31 && progress < .68;
    nodes.get('entry').asset.update(time, { authorized: passing, open: passing ? 1 : 0 });
  }

  function probeTrail(from, to) {
    const direction = to.clone().sub(from);
    const rotation = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), direction.clone().normalize());
    putInstance(trailPool, from.clone().lerp(to, .5), rotation, new THREE.Vector3(1, Math.max(.01, direction.length()), 1));
  }
  function destroyProbe(contact, shield, age, seed = 0) {
    if (age < 0 || age >= 1) return;
    const outward = shield.normal;
    const side = new THREE.Vector3(-outward.z, 0, outward.x);
    for (let index = 0; index < 7; index++) {
      const angle = (index / 7 + seed * .17) * Math.PI * 2;
      const position = contact.clone().addScaledVector(outward, .10 + age * (.43 + .075 * (index % 3)))
        .addScaledVector(side, Math.cos(angle) * age * .64).add(new THREE.Vector3(0, Math.sin(angle) * age * .64, 0));
      const rotation = new THREE.Quaternion().setFromEuler(new THREE.Euler(age * (index + 1), age * 3, angle + age * 2));
      putInstance(shardPool, position, rotation, new THREE.Vector3().setScalar(1 - age * .86));
      fragmentPlaneDistances.push(shield.distanceToFace(position));
    }
    putInstance(impactPool, contact.clone().addScaledVector(outward, .065), shield.rotation, new THREE.Vector3().setScalar(.3 + age * 1.9));
  }
  function projectileContact(origin, contact, shield) {
    const center = contact.clone(), normal = shield.normal;
    let direction, rotation, support = 0;
    for (let iteration = 0; iteration < 3; iteration++) {
      direction = center.clone().sub(origin).normalize();
      rotation = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 0, 1), direction);
      const xAxis = new THREE.Vector3(1, 0, 0).applyQuaternion(rotation), yAxis = new THREE.Vector3(0, 1, 0).applyQuaternion(rotation);
      support = .085 * Math.abs(xAxis.dot(normal)) + .065 * Math.abs(yAxis.dot(normal)) + .23 * Math.abs(direction.dot(normal));
      center.copy(contact).addScaledVector(normal, support + .028);
    }
    return { center, direction, rotation, support };
  }
  function updatePentest(phase, progress, time) {
    if (phase === 0) {
      stage = 'arrival';
      const arrival = part(progress, .025, .74);
      const local = testerArrival.clone().lerp(testerHome, arrival);
      const direction = testerHome.clone().sub(testerArrival);
      const walkingAngle = Math.atan2(direction.x, direction.z);
      testerWalking = progress > .025 && progress < .74;
      poseTester(testerPosition.clone().add(local), THREE.MathUtils.lerp(walkingAngle, Math.PI / 2, part(progress, .70, .82)), testerWalking, time);
    } else if (phase === 1) {
      stage = 'perimeter';
      const emergence = part(progress, .153, .195), growth = 1 + .09 * part(progress, .265, .94);
      entryShield.emerge(emergence, growth);
      let strongestImpact = 0;
      for (const event of attackSchedule) {
        const started = progress >= event.start, destroyed = progress >= event.impact;
        if (!started) continue;
        if (destroyed) destroyedCount++;
        if (destroyed && progress - event.impact >= .055 && !event.first) continue;
        const index = event.slot;
        const origin = probeOrigin.clone().add(new THREE.Vector3(event.first ? 0 : (index % 2 - .5) * .35, event.first ? 0 : (index % 4 - 1.5) * .31, event.first ? 0 : (index % 3 - 1) * .4));
        const contact = entryShield.facePoint(event.x, event.y);
        const body = projectileContact(origin, contact, entryShield);
        const approaching = started && !destroyed;
        const position = origin.clone().lerp(body.center, clamp((progress - event.start) / (event.impact - event.start)));
        if (approaching) {
          putInstance(projectilePool, position, body.rotation);
          probeTrail(position.clone().addScaledVector(body.direction, -.95), position.clone().addScaledVector(body.direction, -.13));
        }
        if (destroyed) {
          const age = (progress - event.impact) / .055;
          destroyProbe(contact, entryShield, age, index);
          strongestImpact = Math.max(strongestImpact, Math.max(0, 1 - age));
        }
        probeEndpoints.push({ first: event.first, origin: origin.toArray(), boundary: contact.toArray(), deflected: false, destroyed, visible: approaching, state: destroyed ? 'destroyed' : 'approaching', position: position.toArray(), contactPlaneDistance: entryShield.distanceToFace(contact), originPlaneDistance: entryShield.distanceToFace(origin), geometryClearance: entryShield.distanceToFace(position) - body.support });
      }
      entryShield.update(strongestImpact, progress * 18 % 1);
    } else if (phase === 2) {
      stage = progress < .21 ? 'authorized-walk' : 'account-test';
      entryShield.emerge(1 - part(progress, 0, .08), 1.09);
      const walk = part(progress, .01, .195), pose = pathPose(walkIntoFactory, walk);
      testerWalking = progress > .01 && progress < .195;
      poseTester(pose.point, Math.atan2(pose.direction.x, pose.direction.z), testerWalking, time);
      authorizedSession = progress >= .195;
      const gate = walk > .54 && walk < .995;
      nodes.get('entry').asset.update(time, { authorized: gate || authorizedSession, open: gate ? 1 : 0 });
      const travel = part(progress, .22, .76);
      scopeProbe.object.visible = progress >= .22 && progress < .76;
      placeDocument(scopeProbe, identityRoute, travel * identityStop);
      if (progress >= .22) activeRoute = identityRoute.ids;
      backendShield.emerge(part(progress, .69, .745));
      scopeBlocked = progress >= .76;
      if (scopeBlocked) {
        destroyedCount = 1;
        destroyProbe(accountContact, backendShield, (progress - .76) / .075);
      }
      backendShield.update(scopeBlocked ? Math.max(0, 1 - (progress - .76) / .12) : .1, progress * 4 % 1);
      probeEndpoints.push({ origin: identityRoute.points[0].toArray(), boundary: accountContact.toArray(), deflected: false, destroyed: scopeBlocked, visible: scopeProbe.object.visible, state: scopeBlocked ? 'destroyed' : scopeProbe.object.visible ? 'approaching' : 'waiting', position: scopeProbe.object.position.toArray(), contactPlaneDistance: backendShield.distanceToFace(accountContact), finalCenterClearance: backendShield.distanceToFace(accountStop) });
    } else if (phase === 3 || phase === 4) {
      stage = phase === 3 ? 'report' : 'review';
      backendShield.emerge(1);
      if (phase === 3) {
        const back = part(progress, 0, .26), pose = pathPose(walkIntoFactory, 1 - back);
        testerWalking = progress > 0 && progress < .26;
        const walkingAngle = Math.atan2(-pose.direction.x, -pose.direction.z);
        poseTester(pose.point, THREE.MathUtils.lerp(walkingAngle, Math.PI / 2, part(progress, .24, .30)), testerWalking, time);
        const gate = back < .49;
        nodes.get('entry').asset.update(time, { authorized: gate, open: gate ? 1 : 0 });
      }
      report.object.visible = phase === 4 || progress >= .30; evidenceRibbon.visible = phase === 3 && progress >= .30;
      report.object.rotation.set(0, .13, 0);
      report.object.position.copy(phase === 4 ? reportTarget : reportCurve.getPoint(part(progress, .30, .78)));
      report.object.scale.setScalar(1.12);
      scopeTag.userData.setText(phase === 4 ? 'REVISAR' : 'PRUEBAS');
    }
    if (phase < 3) scopeTag.userData.setText('PRUEBAS');
  }

  function reset() {
    if (disposed) return;
    restoreClient(); hideTransient(); object.visible = false; pentest.visible = false; agents.visible = false; sampled = null;
    robot.object.userData.seated = false;
  }
  function update(extension) {
    if (disposed) return;
    restoreClient(); hideTransient();
    const id = extension?.id;
    if (!['pentest', 'agents'].includes(id)) { reset(); return; }
    const phase = THREE.MathUtils.clamp(Math.floor(Number(extension.phaseIndex) || 0), 0, 4);
    const progress = clamp(extension.progress), time = Number.isFinite(extension.time) ? extension.time : 0;
    sampled = { id, phaseIndex: phase, progress, time };
    object.visible = true; pentest.visible = id === 'pentest'; agents.visible = id === 'agents';
    if (id === 'agents') updateAgents(phase, progress, time); else updatePentest(phase, progress, time);
    Object.values(particlePools).forEach(pool => { pool.instanceMatrix.needsUpdate = true; });
    client.asset.object.updateMatrixWorld(true); object.updateMatrixWorld(true);
  }
  const agentBounds = new THREE.Box3().setFromPoints([clientPoint([-5, -.1, -1.6]), clientPoint([4, 3.6, 5])]);
  const testerArrivalWorld = testerPosition.clone().add(testerArrival);
  const pentestBounds = new THREE.Box3().setFromPoints([testerArrivalWorld.clone().add(new THREE.Vector3(-1, -.1, -2)), testerPosition.clone().add(new THREE.Vector3(-2.1, -.1, -2)), entryPosition.clone().add(new THREE.Vector3(2.4, 4.5, 5.9)), backendPosition.clone().add(new THREE.Vector3(2.4, 4.5, 5.5))]);
  const bounds = agentBounds.clone().union(pentestBounds);
  const boundsByScenario = { agents: agentBounds, pentest: pentestBounds };
  function getFocusIds(extension = sampled) {
    if (!extension) return [];
    if (extension.id === 'pentest' && extension.phaseIndex === 2) return extension.progress < .21 ? ['entry'] : ['entry', 'apim', 'backend'];
    return ({ agents: [['client'], ['client'], ['client', 'entry', 'apim', 'backend'], ['client', 'entry', 'apim', 'backend'], ['client']], pentest: [['entry'], ['entry'], ['entry', 'apim', 'backend'], ['entry', 'backend'], []] })[extension.id]?.[extension.phaseIndex] || [];
  }
  function getPhaseBounds(extension = sampled) {
    if (!extension) return bounds.clone();
    if (extension.id === 'agents') return agentBounds.clone();
    if (extension.phaseIndex === 0) return new THREE.Box3().setFromPoints([testerArrivalWorld.clone().add(new THREE.Vector3(-1, -.1, -2)), entryPosition.clone().add(new THREE.Vector3(2.4, 4.5, 4.8))]);
    if (extension.phaseIndex === 1) return new THREE.Box3().setFromPoints([testerPosition.clone().add(new THREE.Vector3(-2.1, -.1, -2)), entryPosition.clone().add(new THREE.Vector3(2.4, 4.5, 5.9))]);
    if (extension.phaseIndex === 2 && extension.progress < .21) return new THREE.Box3().setFromPoints(walkIntoFactory).expandByVector(new THREE.Vector3(1.6, 3.2, 1.4));
    if (extension.phaseIndex === 2) return new THREE.Box3().setFromPoints([entryPosition.clone().add(new THREE.Vector3(-1.8, -.1, -1.8)), backendPosition.clone().add(new THREE.Vector3(2.4, 4.4, 5))]);
    return pentestBounds.clone();
  }
  function inspect() {
    object.updateMatrixWorld(true); client.asset.object.updateMatrixWorld(true);
    const humanPosition = human.getWorldPosition(new THREE.Vector3()), chairPosition = chair.getWorldPosition(new THREE.Vector3());
    const robotPosition = robot.object.getWorldPosition(new THREE.Vector3());
    return {
      active: object.visible ? sampled?.id || null : null, ...sampled,
      actualFactory: true, existingClientReused: true, existingChairReused: true,
      originalClientRestored: human.position.distanceTo(originalHuman.position) < .00001 && human.quaternion.angleTo(originalHuman.quaternion) < .00001 && chair.position.distanceTo(originalChair.position) < .00001,
      human: { position: humanPosition.toArray(), aside: human.position.distanceTo(originalHuman.position) > 1.8, seated: human.position.distanceTo(originalHuman.position) < .12 },
      robot: { position: robotPosition.toArray(), seated: Boolean(object.visible && agents.visible && robot.object.userData.seated), knees: robotKnees.map(knee => knee.rotation.x), hipBend: robotLegs.map(hip => hip.rotation.x), feet: robotFeet.map(foot => foot.getWorldPosition(new THREE.Vector3()).toArray()), stylusTip: robot.inspect().stylusTip, pointerSurface: pointerPad.getWorldPosition(new THREE.Vector3()).toArray(), distanceToChair: Math.hypot(robotPosition.x - chairPosition.x, robotPosition.z - chairPosition.z) },
      chair: { position: chairPosition.toArray(), unchanged: chair.position.distanceTo(originalChair.position) < .00001 && chair.quaternion.angleTo(originalChair.quaternion) < .00001 },
      stage, activeRoute, sentToOrders: false, scopeBlocked, blockedBeforeSQL: scopeBlocked,
      probeEndpoints, shields: [entryShield.inspect(), backendShield.inspect()],
      destruction: { count: destroyedCount, scheduled: attackSchedule.length, noRebound: true, fragmentsRemainOutside: fragmentPlaneDistances.every(distance => distance >= .099), minimumFragmentCenterDistance: fragmentPlaneDistances.length ? Math.min(...fragmentPlaneDistances) : null },
      particleInstances: Object.fromEntries(Object.entries(particlePools).map(([key, pool]) => [key, pool.count])),
      particleDrawCallsMaximum: 4, permissionFloorSigns: false,
      attackColor: probeMaterial.color.getHexString(), accountProbeColor: scopeProbe.skin.color.getHexString(),
      document: { visible: object.visible && agents.visible && agentDocument.object.visible, position: agentDocument.object.position.toArray() },
      tester: { position: tester.object.getWorldPosition(new THREE.Vector3()).toArray(), desk: testerHomeWorld.toArray(), arrival: testerArrivalWorld.toArray(), walking: testerWalking, authorizedSession, atDesk: tester.object.position.distanceTo(testerHome) < .04, external: true, futureValidation: true },
      reportVisible: object.visible && pentest.visible && report.object.visible,
      entryPassage: { front: nodePoint('entry').toArray(), back: expectedEntryBack.toArray() },
    };
  }
  function dispose() {
    if (disposed) return;
    reset(); disposed = true; Object.values(particlePools).forEach(pool => pool.dispose()); robot.dispose(); tester.dispose(); workshop.dispose(); object.removeFromParent(); object.clear();
  }
  reset();
  return { object, bounds, boundsByScenario, getPhaseBounds, getFocusIds, update, reset, inspect, dispose };
}
