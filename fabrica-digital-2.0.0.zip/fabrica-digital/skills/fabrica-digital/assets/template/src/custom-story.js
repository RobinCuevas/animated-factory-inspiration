import {CUSTOM} from '../examples/custom-architecture/model.js';

// This adapter knows steps and connections, not commerce-specific service IDs.
// Validation makes a missing machine or an unconnected journey visible early.
const nodeIds = new Set(CUSTOM.nodes.map(node => node.id));
if (nodeIds.size !== CUSTOM.nodes.length) throw new Error('La receta contiene servicios duplicados');
if (CUSTOM.edges.some(edge => !nodeIds.has(edge.from) || !nodeIds.has(edge.to))) throw new Error('Una conexión utiliza un servicio que no existe');
const connected = (from, to) => from === to || CUSTOM.edges.some(edge =>
  edge.from === from && edge.to === to || edge.from === to && edge.to === from);
const definitions = CUSTOM.scenarios.map(scenario => {
  if (!scenario.steps?.length) throw new Error(`La sección ${scenario.id} necesita pasos`);
  const focusEntry = scenario.focusEntry ?? 0;
  if (!Number.isInteger(focusEntry) || focusEntry < 0 || focusEntry >= scenario.steps.length) {
    throw new Error(`Inicio abreviado inválido en ${scenario.id}`);
  }
  let duration = 0;
  const phases = scenario.steps.map((step, index) => {
    if (!Number.isFinite(step.duration) || step.duration <= 0) throw new Error(`Duración inválida en ${scenario.id}:${index}`);
    if (!nodeIds.has(step.from) || !nodeIds.has(step.to)) throw new Error(`Servicio desconocido en ${scenario.id}:${index}`);
    if (!connected(step.from, step.to)) throw new Error(`Falta una conexión entre ${step.from} y ${step.to}`);
    if (index && scenario.steps[index - 1].to !== step.from) throw new Error(`El objeto salta de servicio en ${scenario.id}:${index}`);
    if (step.work?.some(id => id !== step.to) || step.work?.length && step.from !== step.to) {
      throw new Error(`La máquina debe recibir el objeto antes de trabajar: ${scenario.id}:${index}`);
    }
    if (!step.title || !step.copy) throw new Error(`Falta la explicación en ${scenario.id}:${index}`);
    const result = {...step, index, at: duration, start: duration, end: duration + step.duration};
    duration = result.end;
    return result;
  });
  return {...scenario, focusEntry, phases, duration};
});
if (new Set(definitions.map(scenario => scenario.id)).size !== definitions.length) throw new Error('La receta contiene secciones duplicadas');

export const SCENARIOS = definitions.map(({id, label, summary, duration}) => ({id, label, summary, duration}));
export const getPhases = id => definitions.find(scenario => scenario.id === id)?.phases.map(({at, title, index}) => ({at, title, index})) ?? [];
export const getChapters = () => [];
export function getStartTime(id, mode = 'focus') {
  const scenario = definitions.find(scenario => scenario.id === id);
  return mode === 'full' ? 0 : scenario?.phases[scenario.focusEntry].at ?? 0;
}
export function getReadingSteps(id, mode = 'focus') {
  const scenario = definitions.find(scenario => scenario.id === id);
  if (!scenario) return [];
  const start = getStartTime(id, mode);
  return scenario.phases.filter(phase => phase.end > start).map((phase, index, phases) => ({
    start: phase.start,
    end: phase.end,
    // Keep the completed step's explanation on screen, before the next boundary.
    checkpoint: index === phases.length - 1 ? phase.end : Math.max(phase.start, phase.end - Math.min(.05, phase.duration / 10)),
    title: phase.title,
  }));
}
const clamp = value => Math.max(0, Math.min(1, value));
const smooth = value => value * value * (3 - 2 * value);
export function sampleScenario(id, time) {
  const scenario = definitions.find(scenario => scenario.id === id);
  if (!scenario) throw new Error(`Recorrido desconocido: ${id}`);
  const t = Math.max(0, Math.min(scenario.duration, Number(time) || 0));
  const phase = scenario.phases.find(candidate => t < candidate.end) ?? scenario.phases.at(-1);
  const progress = smooth(clamp((t - phase.start) / phase.duration));
  const route = phase.from === phase.to ? null : [phase.from, phase.to];
  return {
    custom: true, scenario: id, time: t, duration: scenario.duration, phaseIndex: phase.index,
    title: phase.title, copy: phase.copy,
    active: [...new Set([phase.from, phase.to])], focus: [...new Set([phase.from, phase.to])],
    token: {id: scenario.tokenId ?? 'DOC-001', label: scenario.tokenId ?? 'DOC-001', kind: 'file', visible: true,
      ...(route ? {route, progress, t: progress} : {node: phase.to})},
    work: [...(phase.work ?? [])], workTime: clamp((t - phase.start) / phase.duration) * 3.3,
    ledger: {}, saved: false, uncertain: false,
    insight: (phase.insight ?? []).map(item => ({...item})),
  };
}
