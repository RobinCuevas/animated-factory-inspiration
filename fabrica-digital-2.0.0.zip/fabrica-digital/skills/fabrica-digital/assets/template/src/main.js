import {PROJECT} from './project.js';
import {NODES,SUPPORTS,EDGES,STATUS,SERVICE_ICONS,SCENARIOS,sampleScenario,getStartTime,getChapters,getReadingSteps,createScene} from './experience.js';
import { drawLogicalMap } from './logical-map.js';
import { createMapViewer } from './map-viewer.js';
import { connectPresentation } from './embed.js';

const $ = (selector) => document.querySelector(selector);
const list = (value) => Array.isArray(value) ? value : Object.values(value || {});
const nodes = [...list(NODES), ...list(SUPPORTS)];
const nodeById = new Map(nodes.map((node) => [node.id, node]));
const scopeLabels = { user: 'Usuario', global: 'Servicio global', factory: 'Aplicación', core: 'Sistema corporativo' };
const enabledSections=PROJECT.recipe==='custom'?PROJECT.customSections:PROJECT.sections;
const scenarios=enabledSections?enabledSections.map(id=>{const found=list(SCENARIOS).find(item=>item.id===id);if(!found)throw new Error(`Recorrido no definido: ${id}`);return found;}):list(SCENARIOS);
if (!scenarios.length) throw new Error('Selecciona al menos un recorrido en src/project.js');
const escape = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
const readable = (value) => {
  if (value == null) return '';
  if (Array.isArray(value)) return value.map(readable).filter(Boolean).join(' · ');
  if (typeof value === 'object') return readable(value.label ?? value.title ?? value.text ?? Object.values(value));
  return String(value);
};
const detail = (value) => Array.isArray(value)
  ? `<ul class="detail-list">${value.filter(Boolean).map((item) => `<li>${escape(readable(item))}</li>`).join('')}</ul>`
  : escape(readable(value));
const clock = (seconds) => `${Math.floor(Math.max(0, seconds) / 60)}:${String(Math.floor(Math.max(0, seconds) % 60)).padStart(2, '0')}`;
const serviceIcon = id => id==='ai'&&SERVICE_ICONS.openai&&SERVICE_ICONS.search?`<span class="service-icon-group" aria-hidden="true"><img class="service-icon" src="${escape(SERVICE_ICONS.openai)}" alt="" title="Azure OpenAI" /><img class="service-icon" src="${escape(SERVICE_ICONS.search)}" alt="" title="Azure AI Search" /></span>`:SERVICE_ICONS[id]?`<img class="service-icon${id==='logistics'?' service-wordmark':''}" src="${escape(SERVICE_ICONS[id])}" alt="" />`:'';
const brandTerms=[['Azure Container Apps Jobs','worker'],['Container Apps Jobs','worker'],['Container Apps Job','worker'],['Azure Container Apps','backend'],['Container Apps','backend'],['Azure SQL Database','sql'],['Azure Blob Storage','blob'],['Blob Storage','blob'],['Azure Service Bus','queue'],['Service Bus','queue'],['API Management','apim'],['Front Door','entry'],['App Service','frontend'],['Azure SQL','sql'],['SQL','sql'],['Blob','blob'],['Microsoft Entra ID','identity'],['Entra ID','identity'],['Dynamics 365 Sales','crm'],['Dynamics 365','crm'],['ERP','erp']];
brandTerms.unshift(['Azure AI Search','search'],['Azure OpenAI','openai'],['Logística','logistics']);
for(const node of nodes)if(SERVICE_ICONS[node.id])brandTerms.unshift([node.service.split(' · ')[0],node.id]);
const brandsByTerm=new Map(brandTerms);
const regexEscape=text=>text.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
const brandPattern=new RegExp(`\\b(${[...brandsByTerm.keys()].sort((a,b)=>b.length-a.length).map(regexEscape).join('|')})\\b([.,:!?]?)`,'g');
function brandedText(value){
  const text=String(value??'');let result='',cursor=0;
  for(const match of text.matchAll(brandPattern)){
    result+=escape(text.slice(cursor,match.index));
    const id=brandsByTerm.get(match[1]);
    const space=match[0].indexOf(' ');
    const lead=space<0?match[0]:match[0].slice(0,space);
    const rest=space<0?'':match[0].slice(space);
    result+=SERVICE_ICONS[id]?`<span class="inline-brand"><span class="inline-brand-lead">${serviceIcon(id)}${escape(lead)}</span>${escape(rest)}</span>`:escape(match[0]);
    cursor=match.index+match[0].length;
  }
  return result+escape(text.slice(cursor));
}
const params = new URLSearchParams(location.search);
let scenario = scenarios.find((item) => item.id === params.get('scenario')) || scenarios[0];
let entryMode = params.get('entry') === 'focus' ? 'focus' : 'full';
const playbackRate = () => scenario.speed ?? (scenario.id === 'pentest' ? PROJECT.playback.pentestSpeed : PROJECT.playback.defaultSpeed);
let time = Math.min(scenario.duration, Math.max(0, params.has('t') ? Number(params.get('t')) || 0 : getStartTime(scenario.id,entryMode)));
let playing = false;
const captureMode=params.get('capture')==='1';
if(captureMode)document.documentElement.dataset.capture='true';
let captureClock=0;
let playbackStop = null;
let sectionTransition = null;
let selectedNode = null;
let activeView = 'factory';
let scene;
let latestState;
let lastUiKey;
let previousFrame = performance.now();
let disposed = false;
let ready = false;
let mapViewer;
const presentation = connectPresentation({pause:()=>{cancelTransition();setPlaying(false);syncUrl();}});


document.title = PROJECT.title==='Fábrica digital'?PROJECT.title:`${PROJECT.title} · Fábrica digital`;
$('#project-title').textContent=PROJECT.title;
$('#project-subtitle').textContent=PROJECT.subtitle;
$('#intro-title').textContent=PROJECT.headline || 'Una plataforma, por dentro.';
$('#intro-copy').textContent=PROJECT.description || 'Explora qué hace cada servicio y cómo se mueve la información.';
$('#footer-title').textContent=PROJECT.customer.name || PROJECT.title;
document.documentElement.style.setProperty('--accent', PROJECT.palette.accent);
document.documentElement.style.setProperty('--teal', PROJECT.palette.accent);
document.documentElement.style.backgroundColor=PROJECT.palette.background;
if(PROJECT.customer.logo){const logo=$('#customer-logo');logo.src=PROJECT.customer.logo;logo.alt=PROJECT.customer.name || 'Identidad del proyecto';logo.hidden=false;}

$('#architecture-status').textContent = STATUS;
$('.support-section').hidden=!list(SUPPORTS).length;
if(PROJECT.recipe==='custom')$('.network-section').hidden=true;
const scenarioButton=(item,index)=>`<button class="scenario-button" data-scenario="${escape(item.id)}" aria-pressed="false"><span class="scenario-number">${String(index + 1).padStart(2, '0')}</span><span class="scenario-label">${escape(item.label)}</span></button>`;
const mainStories=scenarios.filter(item=>!['knowledge','pentest','agents'].includes(item.id));
const optionalStories=scenarios.filter(item=>['knowledge','pentest','agents'].includes(item.id));
$('#scenario-list').innerHTML = `<div class="scenario-primary">${mainStories.map(item=>scenarioButton(item,scenarios.indexOf(item))).join('')}</div>${optionalStories.length?`<div class="scenario-extension"><span class="extension-caption">EXPLORAR</span>${optionalStories.map(item=>scenarioButton(item,scenarios.indexOf(item))).join('')}</div>`:''}`;
$('#support-list').innerHTML = list(SUPPORTS).map((node) => `<button class="support-button" data-node="${escape(node.id)}" aria-pressed="false">${serviceIcon(node.id)}${escape(node.label)}<span>${escape(node.service)}</span></button>`).join('');

function syncUrl() {
  const url = new URL(location.href);
  url.searchParams.set('scenario', scenario.id);
  url.searchParams.set('t', time.toFixed(2));
  url.searchParams.set('entry', entryMode);
  url.searchParams.delete('speed');
  history.replaceState(null, '', url);
}

function setPlaying(value) {
  playing = Boolean(value);
  if (playing && time >= scenario.duration) {time = getStartTime(scenario.id,entryMode);playbackStop = null;}
  if (playing && scene) scene.reset(sampleScenario(scenario.id, time).focus);
  $('#play-button').innerHTML = playing ? '<span aria-hidden="true">Ⅱ</span> Pausar' : '<span aria-hidden="true">▶</span> Reproducir';
  $('#play-button').setAttribute('aria-label', playing ? 'Pausar recorrido' : 'Reproducir recorrido');
  previousFrame = performance.now();
}

function togglePlayback() {
  cancelTransition();
  if(!playing&&playbackStop!==null&&time>=playbackStop)playbackStop=null;
  setPlaying(!playing);
  refresh();
  syncUrl();
}

function renderIntro() {
  $('#inspector-content').innerHTML = `<div class="intro-inspector"><p>Selecciona una máquina para ver qué servicio utiliza, qué recibe y qué decisiones siguen pendientes.</p></div>`;
}

function selectNode(id, { focus = false } = {}) {
  const node = nodeById.get(id);
  if (!node) {
    selectedNode = null;
    renderIntro();
    if($('#technical-details'))$('#technical-details').open=false;
  } else {
    cancelTransition();
    selectedNode = id;
    setPlaying(false);
    const evidence = readable(node.evidence);
    $('#inspector-content').innerHTML = `<div class="inspector-header"><button class="inspector-close" aria-label="Cerrar ficha" title="Cerrar ficha">×</button><p class="eyebrow">${escape(scopeLabels[node.scope] || 'Servicio de la arquitectura')}</p><h2>${escape(node.label)}</h2><p class="service-name">${serviceIcon(node.id)}${escape(node.service)}</p></div><div class="inspector-body"><dl class="node-details"><div><dt>RECIBE</dt><dd>${detail(node.receives)}</dd></div><div><dt>HACE</dt><dd>${detail(node.does)}</dd></div><div><dt>ENTREGA</dt><dd>${detail(node.sends)}</dd></div></dl>${evidence ? `<section class="detail-section"><h3>Estado de esta representación</h3><p>${escape(evidence)}</p></section>` : ''}${node.choice ? `<section class="detail-section"><h3>En esta visualización</h3><div class="detail-content">${detail(node.choice)}</div></section>` : ''}${node.pending ? `<section class="detail-section pending-section"><h3>Por validar</h3><div class="detail-content">${detail(node.pending)}</div></section>` : ''}${node.network ? `<section class="detail-section"><h3>Conectividad</h3><div class="detail-content">${detail(node.network)}</div></section>` : ''}${node.source ? `<p class="detail-source"><strong>Referencia:</strong> ${escape(readable(node.source))}</p>` : ''}</div>`;
    $('.inspector-close').addEventListener('click', () => selectNode(null));
    if($('#technical-details'))$('#technical-details').open=true;
    if(focus&&activeView==='map')mapViewer?.reveal(id);
    if (focus && innerWidth < 700) $('#inspector').scrollIntoView({ block: 'start', behavior: 'auto' });
  }
  document.querySelectorAll('[data-node]').forEach((button) => button.setAttribute('aria-pressed', String(button.dataset.node === selectedNode)));
  scene?.select(selectedNode);
  scene?.render();
  return selectedNode;
}

function updateUi(state) {
  const readingSteps=getReadingSteps(scenario.id,entryMode);
  const stepIndex=readingSteps.findLastIndex(step=>time>=step.start);
  const sectionIndex=scenarios.findIndex(item=>item.id===scenario.id);
  const previousSection=scenarios[sectionIndex-1],nextSection=scenarios[sectionIndex+1];
  $('#previous-step').disabled=stepIndex<=0&&!previousSection;
  $('#next-step').disabled=stepIndex>=readingSteps.length-1&&!nextSection;
  $('#step-count').textContent=stepIndex<0?'Entrada':`Paso ${stepIndex+1} / ${readingSteps.length}`;
  $('#previous-step').title=stepIndex>0?`Reproducir: ${readingSteps[stepIndex-1].title}`:previousSection?`Sección anterior: ${previousSection.label}`:'Primer paso';
  $('#next-step').title=stepIndex<readingSteps.length-1?`Reproducir: ${readingSteps[stepIndex+1].title}`:nextSection?`Continuar con ${String(sectionIndex+2).padStart(2,'0')} ${nextSection.label}`:'Último paso';
  $('#timeline').max = String(scenario.duration);
  $('#timeline').value = String(time);
  $('#timeline').setAttribute('aria-valuetext', `${clock(time)} de ${clock(scenario.duration)}. ${state.title}`);
  $('#time-output').textContent = `${clock(time)} / ${clock(scenario.duration)}`;
  const key = JSON.stringify([scenario.id, entryMode, state.phaseIndex, state.title, state.copy, state.ledger, state.uncertain,state.attachmentSaved,state.attachmentLinked,state.downloaded,state.capacity?.replicas,state.capacity?.pending,state.capacity?.completed]);
  if (key === lastUiKey) return;
  lastUiKey = key;
  $('#scenario-name').textContent = scenario.label;
  $('#scenario-summary').textContent = scenario.summary;
  $('#scenario-badge').hidden=!scenario.badge;
  $('#scenario-badge').textContent=scenario.badge||'';
  $('#scenario-badge').dataset.kind=scenario.id;
  $('#scenario-context').hidden=!scenario.context;
  $('#scenario-context').textContent=scenario.context||'';
  const chapters=getChapters(scenario.id);
  $('#story-chapters').hidden=!chapters.length;
  $('#story-chapters').innerHTML=chapters.map(item=>`<button data-chapter="${item.index}" aria-current="${state.chapter?.index===item.index?'step':'false'}" title="Ir a: ${escape(item.title)}"><span>${item.index+1}</span>${escape(item.label)}</button>`).join('');
  $('#phase-title').textContent = state.title;
  $('#phase-copy').innerHTML = brandedText(state.copy);
  if($('#phase-services'))$('#phase-services').innerHTML=[...new Set(state.chapter?.services??state.active)].map(id=>{
    const node=nodeById.get(id);
    return node?`<button class="service-chip" data-node="${escape(id)}">${serviceIcon(id)}<span>${escape(id==='ai'?'Azure OpenAI + AI Search':node.service.split(' · ')[0])}</span></button>`:'';
  }).join('');
  document.querySelectorAll('[data-scenario]').forEach((button) => button.setAttribute('aria-pressed', String(button.dataset.scenario === scenario.id)));
  const ledger = state.ledger || {};
  $('#order-ledger').hidden = scenario.id === 'consultation';
  $('#order-ledger').setAttribute('aria-label', scenario.id === 'attachments' ? 'Estado del adjunto sintético' : scenario.id === 'capacity' ? 'Estado de la demanda simulada' : 'Estado del pedido sintético');
  $('#order-ledger').classList.toggle('is-uncertain', Boolean(state.uncertain));
  $('#order-ledger').classList.toggle('is-file', scenario.id==='attachments');
  if(state.extension||state.custom){
    $('#order-ledger').setAttribute('aria-label','Contexto de la demostración');
    $('#order-ledger').hidden=!(state.insight||[]).length;
    $('#order-ledger').innerHTML=(state.insight||[]).map(item=>`<div><dt>${escape(item.label)}</dt><dd>${escape(item.value)}</dd></div>`).join('');
    return;
  }
  if(scenario.id==='capacity'){
    const c=state.capacity;
    $('#order-ledger').innerHTML=`<div><dt>Copias activas del backend</dt><dd>${c.replicas}</dd></div><div><dt>Peticiones esperando</dt><dd>${c.pending}</dd></div><div><dt>Respuestas completadas</dt><dd>${c.completed}</dd></div><div><dt>Escalabilidad</dt><dd>Ejemplo por validar</dd></div>`;
    return;
  }
  if(scenario.id==='attachments'){
    $('#order-ledger').innerHTML=`<div class="file-record" data-kept="${state.attachmentSaved}"><span class="file-symbol original" aria-hidden="true">PDF</span><div><dt>Archivo · En Blob</dt><dd>${state.attachmentSaved?'Guardado en el almacén':'Documento de ejemplo.pdf'}</dd></div></div><div class="file-record" data-kept="${state.attachmentLinked}"><span class="file-symbol reference" aria-hidden="true">↗</span><div><dt>Ficha · En la base</dt><dd>${state.attachmentLinked?'Consulta + ubicación del archivo':'Pendiente de registrar'}</dd></div></div><div class="file-record" data-kept="${state.downloaded}"><span class="file-symbol copy" aria-hidden="true">PDF</span><div><dt>Copia · Para el cliente</dt><dd>${state.downloaded?'Disponible para leer':state.chapter?.index>=2?'Lectura autorizada en curso':'Se obtiene al abrirlo'}</dd></div></div>`;
    return;
  }
  $('#order-ledger').innerHTML = `<div><dt>Borrador</dt><dd>${escape(readable(ledger.draft) || 'Sin cambios')}</dd></div><div><dt>Envío al gestor</dt><dd>${escape(readable(ledger.submission) || 'Sin enviar')}</dd></div><div><dt>Resultado comercial</dt><dd>${escape(readable(ledger.commercial) || 'Sin resultado')}</dd></div><div><dt>Intentos de envío</dt><dd>${escape(readable(ledger.attempts) || '0')}</dd></div>`;
}

function refresh() {
  latestState = sampleScenario(scenario.id, time);
  if (scene && activeView === 'factory') {
    scene.update(latestState);
    scene.render();
  }
  updateUi(latestState);
  return latestState;
}

function seek(value) {
  cancelTransition();
  setPlaying(false);
  playbackStop = null;
  time = Math.min(scenario.duration, Math.max(0, Number(value) || 0));
  if(time<getStartTime(scenario.id,entryMode))entryMode='full';
  refresh();
  syncUrl();
  return latestState;
}

function playStep(step,{autoplay=true,preserveTransition=false}={}){
  if(!step)return latestState;
  if(!preserveTransition)cancelTransition();
  setPlaying(false);
  selectNode(null);
  time=step.start;
  playbackStop=step.checkpoint;
  refresh();
  setPlaying(autoplay);
  scene?.render();
  syncUrl();
  return latestState;
}

function moveStep(direction){
  const steps=getReadingSteps(scenario.id,entryMode);
  const current=Math.max(0,steps.findLastIndex(step=>time>=step.start));
  const target=current+(direction<0?-1:1);
  if(target>=0&&target<steps.length)return playStep(steps[target]);
  const sectionIndex=scenarios.findIndex(item=>item.id===scenario.id);
  const nextSection=scenarios[sectionIndex+(direction<0?-1:1)];
  if(!nextSection)return latestState;
  return transitionSection(nextSection.id,{entry:'focus',lastStep:direction<0});
}

function cancelTransition(){
  sectionTransition=null;
  $('#section-transition').style.opacity='0';
}

function transitionSection(id,options){
  cancelTransition();
  if(matchMedia('(prefers-reduced-motion: reduce)').matches)return openScenario(id,options);
  setPlaying(false);
  playbackStop=null;
  sectionTransition={id,options,elapsed:0,switched:false};
  previousFrame=performance.now();
  return latestState;
}

function advanceTransition(delta){
  const transition=sectionTransition;
  if(!transition)return;
  transition.elapsed+=delta;
  const cover=.16,reveal=.30,finish=.58;
  const easing=value=>{const x=Math.max(0,Math.min(1,value));return x*x*(3-2*x);};
  if(transition.elapsed>=cover&&!transition.switched){
    transition.switched=true;
    openScenario(transition.id,{...transition.options,autoplay:false,preserveTransition:true});
  }
  const opacity=transition.elapsed<cover?easing(transition.elapsed/cover):1-easing((transition.elapsed-reveal)/(finish-reveal));
  $('#section-transition').style.opacity=String(opacity);
  if(transition.elapsed>=finish){
    cancelTransition();
    setPlaying(true);
    syncUrl();
  }
}

function openScenario(id,{entry='full',lastStep=false,autoplay=true,preserveTransition=false}={}) {
  const found = scenarios.find((item) => item.id === id);
  if (!found) return false;
  if(!preserveTransition)cancelTransition();
  setPlaying(false);
  playbackStop=null;
  scenario = found;
  entryMode=entry;
  time = getStartTime(scenario.id,entryMode);
  lastUiKey = null;
  selectNode(null);
  setView('factory',{preserveTransition});
  const steps=getReadingSteps(scenario.id,entryMode);
  return playStep(lastStep?steps.at(-1):steps[0],{autoplay,preserveTransition});
}

function selectScenario(id) {return openScenario(id);}

function overview() {
  scene?.overview();
  if (activeView === 'factory') scene?.render();
}

function setView(view,{preserveTransition=false}={}) {
  if(!preserveTransition)cancelTransition();
  activeView = view === 'map' ? 'map' : 'factory';
  setPlaying(false);
  const isMap = activeView === 'map';
  $('#factory-view').hidden = isMap;
  $('#map-view').hidden = !isMap;
  $('.workspace').classList.toggle('is-map', isMap);
  $('#factory-tab').setAttribute('aria-selected', String(!isMap));
  $('#map-tab').setAttribute('aria-selected', String(isMap));
  $('#factory-tab').tabIndex = isMap ? -1 : 0;
  $('#map-tab').tabIndex = isMap ? 0 : -1;
  if (isMap) requestAnimationFrame(() => mapViewer?.refresh());
  if (!isMap) requestAnimationFrame(() => {
    dispatchEvent(new Event('resize'));
    refresh();
  });
}

drawLogicalMap($('#logical-map'),NODES,EDGES,SERVICE_ICONS,{layout:PROJECT.recipe});
mapViewer=createMapViewer({viewport:$('#map-viewport'),svg:$('#logical-map'),zoomIn:$('#map-zoom-in'),zoomOut:$('#map-zoom-out'),fitButton:$('#map-fit'),zoomLabel:$('#map-zoom-level')});
renderIntro();
$('#scenario-list').addEventListener('click', (event) => {
  const button = event.target.closest('[data-scenario]');
  if (button) selectScenario(button.dataset.scenario);
});
$('#story-chapters').addEventListener('click',event=>{
  const button=event.target.closest('[data-chapter]');
  if(!button)return;
  const chapter=getChapters(scenario.id)[Number(button.dataset.chapter)];
  if(chapter){
    const stop=getReadingSteps(scenario.id,entryMode).find(step=>step.start===chapter.at);
    playStep(stop);
  }
});
document.addEventListener('click', (event) => {
  const button = event.target.closest('[data-node]');
  if (button) selectNode(button.dataset.node, { focus: true });
});
$('#logical-map').addEventListener('keydown', (event) => {
  const node = event.target.closest('[data-node]');
  if (node && ['Enter', ' '].includes(event.key)) {
    event.preventDefault();
    selectNode(node.dataset.node, { focus: true });
  }
});
$('#play-button').addEventListener('click', togglePlayback);
$('#restart-button').addEventListener('click', () => seek(getStartTime(scenario.id,entryMode)));
$('#previous-step').addEventListener('click',()=>moveStep(-1));
$('#next-step').addEventListener('click',()=>moveStep(1));
$('#timeline').addEventListener('input', (event) => seek(event.target.value));
$('#overview-button').addEventListener('click', overview);
$('#factory-tab').addEventListener('click', () => setView('factory'));
$('#map-tab').addEventListener('click', () => setView('map'));
$('.view-tabs').addEventListener('keydown', (event) => {
  if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
  event.preventDefault();
  const next = event.key === 'Home' ? 'factory' : event.key === 'End' ? 'map' : activeView === 'factory' ? 'map' : 'factory';
  setView(next);
  $(`#${next}-tab`).focus();
});
$('#factory-stage').addEventListener('keydown', (event) => {
  if (event.key === ' ') { event.preventDefault(); togglePlayback(); }
  if (event.key === 'Home') { event.preventDefault(); seek(getStartTime(scenario.id,entryMode)); }
  if (event.key === 'Escape') selectNode(null);
  if (event.key === 'PageDown') {event.preventDefault();moveStep(1);}
  if (event.key === 'PageUp') {event.preventDefault();moveStep(-1);}
});
document.addEventListener('visibilitychange', () => { if (document.hidden) { cancelTransition();setPlaying(false); syncUrl(); } });

window.factoryAPI = {
  get ready() { return ready; },
  seek,
  selectScenario,
  selectNode,
  overview,
  moveStep,
  capture:(at,wallSeconds=0)=>{if(!captureMode)throw new Error('Usa ?capture=1 para exportar');captureClock=Math.max(0,wallSeconds)*1000;seek(at);scene?.render();return latestState;},
  inspect: () => ({ ready, scenario: scenario.id, time, duration: scenario.duration, playing, playbackStop,transition:sectionTransition?{target:sectionTransition.id,elapsed:sectionTransition.elapsed,switched:sectionTransition.switched}:null,entryMode,playbackRate:playbackRate(),startTime:getStartTime(scenario.id,entryMode),readingSteps:getReadingSteps(scenario.id,entryMode),view: activeView, map:mapViewer?.inspect(), selected: selectedNode, state: latestState, scene: scene?.inspect() ?? null }),
};

try {
  await document.fonts.ready;
  scene = createScene($('#factory-stage'), { onSelect: (id) => selectNode(id, { focus: true }) });
  if(captureMode)scene.setClock(()=>captureClock);
  refresh();
  if(time===0&&!latestState.extension)scene.overview();
  else scene.reset(latestState.focus);
  scene.render();
  $('#loading-message').hidden = true;
  ready = true;
  syncUrl();
} catch (error) {
  console.error('No se ha podido preparar la fábrica.', error);
  $('#loading-message').classList.add('is-error');
  $('#loading-message').textContent = 'No se ha podido iniciar la vista 3D. Puedes explorar los servicios en Mapa y red.';
  $('#play-button').disabled = true;
  refresh();
}

function frame(now) {
  if (disposed) return;
  if (!presentation.visible) { previousFrame=now;requestAnimationFrame(frame);return; }
  const delta = Math.min(.1, Math.max(0, (now - previousFrame) / 1000));
  previousFrame = now;
  const wasTransitioning=Boolean(sectionTransition);
  if(sectionTransition)advanceTransition(delta);
  if (playing && !wasTransitioning && activeView === 'factory') {
    const end=playbackStop??scenario.duration;
    time = Math.min(end, time + delta * playbackRate());
    if (time >= end) { setPlaying(false); syncUrl(); }
  }
  refresh();
  requestAnimationFrame(frame);
}
if(!captureMode)requestAnimationFrame(frame);
window.addEventListener('pagehide', (event) => {
  if (!event.persisted) { disposed = true; scene?.dispose(); mapViewer?.dispose(); }
});
