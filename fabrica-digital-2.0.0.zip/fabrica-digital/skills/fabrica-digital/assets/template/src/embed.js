// The presentation hosts the same factory, with its own surrounding branding.
export function connectPresentation({ pause }) {
  const embedded = new URLSearchParams(location.search).get('embed') === '1';
  const state = { embedded, visible: true };
  if (!embedded) return state;
  document.documentElement.classList.add('is-embedded');
  const support = document.querySelector('.support-section');
  const disclosure = document.createElement('details');
  disclosure.className = 'embedded-support';
  const summary = document.createElement('summary');
  summary.textContent = 'Servicios relacionados';
  support.replaceWith(disclosure);
  disclosure.append(summary, support);
  let previousHeight = 0;
  const reportSize = () => {
    const height = Math.ceil(document.querySelector('main').getBoundingClientRect().height);
    if (height === previousHeight) return;
    previousHeight = height;
    if (parent !== window) parent.postMessage({ type: 'factory:resize', height }, location.origin);
  };
  new ResizeObserver(reportSize).observe(document.querySelector('main'));
  addEventListener('message', event => {
    if (event.source !== parent || event.origin !== location.origin) return;
    if (event.data?.type === 'factory:visibility') {
      state.visible = event.data.visible !== false;
      if (!state.visible) pause();
    }
  });
  addEventListener('keydown', event => {
    if (event.key === 'Escape' && parent !== window) parent.postMessage({type:'factory:exit-expanded'}, location.origin);
  });
  return state;
}
