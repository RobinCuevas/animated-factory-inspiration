// Optional, synthetic examples. Enable only the capabilities relevant to the next project.
// The animation performs no live integrations, security tests or autonomous transactions.
const phase = (title, copy, active, insight) => ({title, copy, active, insight});

const stories = [
  {
    id: 'knowledge',
    label: 'IA y conocimiento',
    summary: 'Una consulta técnica, fuentes contrastables y conocimiento validado por personas.',
    category: 'capacidad',
    badge: 'Ejemplo de asistencia',
    phaseDurations: [4, 6, 4, 4, 4, 4, 4],
    context: 'Ejemplo de búsqueda y respuesta con fuentes autorizadas. Una persona revisa la respuesta antes de incorporarla al conocimiento reutilizable.',
    phases: [
      phase('Una pregunta llega al asistente.',
        'Un cliente plantea una consulta técnica. La IA ayuda a entenderla y organizarla. La pregunta y el documento de este ejemplo son sintéticos.',
        ['client', 'ai'],
        [{label:'Consulta', value:'Ejemplo sintético'}, {label:'Propósito', value:'Asistencia técnica'}]),
      phase('Busca en fuentes que puede consultar.',
        'La búsqueda recupera documentación aprobada y consultas ya resueltas, respetando los permisos. Azure AI Search localiza las fuentes que Azure OpenAI utiliza para preparar el borrador.',
        ['ai', 'identity'],
        [{label:'Fuentes', value:'Aprobadas y autorizadas'}, {label:'Servicios Azure', value:'Búsqueda y generación'}]),
      phase('Prepara una respuesta con sus fuentes.',
        'El asistente relaciona la pregunta con la información encontrada y redacta un borrador con citas. El cliente y el técnico deben poder comprobar de dónde sale cada respuesta.',
        ['ai'],
        [{label:'Respuesta', value:'Borrador con citas'}, {label:'Conocimiento nuevo', value:'Todavía no incorporado'}]),
      phase('Cuando hace falta criterio, pasa a una persona.',
        'Esta consulta necesita revisión técnica. El asistente entrega la pregunta, las fuentes y su borrador para que el equipo técnico pueda resolverla con contexto.',
        ['ai', 'crm'],
        [{label:'Caso ilustrado', value:'Requiere criterio técnico'}, {label:'Siguiente responsable', value:'Equipo técnico'}]),
      phase('El técnico corrige y valida la respuesta.',
        'Una persona revisa la propuesta y sus fuentes. Puede corregirla antes de aprobarla. Ninguna respuesta entra en el conocimiento reutilizable sin esa validación humana.',
        ['ai', 'crm'],
        [{label:'Control humano', value:'Revisar, corregir y aprobar'}, {label:'Respuesta del ejemplo', value:'Validada para reutilizar'}]),
      phase('La respuesta vuelve al cliente.',
        'El cliente recibe la respuesta revisada y las fuentes que la sostienen. El mismo caso recorre todo el proceso, desde la consulta inicial hasta su resolución.',
        ['client', 'ai'],
        [{label:'Cliente', value:'Recibe respuesta y fuentes'}, {label:'Caso ilustrado', value:'Revisado por una persona'}]),
      phase('Una ficha validada ayuda en la siguiente consulta.',
        'Después de responder al cliente, una ficha diferenciada conserva la pregunta, su contexto y la respuesta aprobada para consultas futuras. El equipo puede corregirla o retirarla. Se amplían las fuentes, no se reentrena el modelo.',
        ['ai'],
        [{label:'Resultado', value:'Conocimiento revisable'}, {label:'Futuras consultas', value:'Más fuentes validadas'}]),
    ],
  },
  {
    id: 'pentest',
    label: 'Pentesting',
    summary: 'Un especialista pone a prueba los controles desde fuera y desde una cuenta autorizada.',
    category: 'validacion',
    badge: 'Simulación de una evaluación',
    context: 'Una evaluación de seguridad busca fallos y comprueba las correcciones. Los rechazos de esta escena son ilustrativos, no resultados de una prueba real.',
    phaseDurations: [3, 3, 7, 5, 4],
    phases: [
      phase('Llega el especialista que pondrá a prueba el portal.',
        'El especialista trabaja dentro de un alcance autorizado. El entorno, los accesos y las pruebas permitidas se acuerdan antes de comenzar.',
        ['identity'],
        [{label:'Responsable', value:'Especialista autorizado'}, {label:'Situación', value:'Ejemplo simulado'}]),
      phase('La entrada debe detener las peticiones no permitidas.',
        'El especialista empieza con una petición y después lanza una ráfaga de intentos no permitidos. El escudo ilustra su rechazo en la entrada. La prueba real comprobará los controles y buscará sus debilidades.',
        ['entry', 'apim'],
        [{label:'Prueba ilustrada', value:'Acceso no permitido'}, {label:'Resultado esperado', value:'Rechazo por verificar'}]),
      phase('Estar dentro no da acceso a otra cuenta.',
        'Ahora el especialista entra con una cuenta de prueba autorizada. Desde la cuenta A intenta consultar un pedido de la cuenta B. El backend debe denegar la petición antes de entregar información de otro cliente.',
        ['backend', 'identity', 'sql'],
        [{label:'Cuenta A → datos B', value:'Acceso que debe denegarse'}, {label:'Dónde se comprueba', value:'Permisos del backend'}]),
      phase('Las pruebas dejan evidencias para corregir.',
        'Cada hallazgo se registra con evidencia, impacto y prioridad. El equipo puede corregirlo y decidir qué debe resolverse antes de continuar.',
        ['observe', 'backend'],
        [{label:'Hallazgo', value:'Evidencia y prioridad'}, {label:'Corrección', value:'Responsable y seguimiento'}]),
      phase('Volver a comprobar después de corregir.',
        'El especialista vuelve a probar los controles afectados y registra el resultado. Una corrección propuesta y una corrección verificada son estados distintos.',
        ['observe', 'identity'],
        [{label:'Seguimiento', value:'Prueba tras la corrección'}, {label:'Resultado', value:'Debe verificarse en el sistema real'}]),
    ],
  },
  {
    id: 'agents',
    label: '¿Y si accede un agente?',
    summary: 'Propuesta para debatir: acceso de agentes con permisos elegidos por cada cuenta y control humano.',
    category: 'idea',
    badge: 'Idea opcional',
    context: 'Un posible acceso de agentes a las mismas APIs. Este ejemplo termina con un borrador para revisión humana y no envía pedidos.',
    phaseDurations: [8, 4, 4, 4, 4],
    phases: [
      phase('Una idea para debatir: otro modo de usar el portal.',
        'La persona cede su puesto y un agente utiliza el mismo portal en nombre de una cuenta. Cambia quién inicia la operación, pero se mantienen los controles y responsabilidades.',
        ['client'],
        [{label:'Estado', value:'Posibilidad ilustrada'}, {label:'Agente', value:'En nombre de una cuenta'}]),
      phase('Cada cuenta decide qué le permite hacer.',
        'La propuesta separa permisos de lectura, creación y gestión. Una cuenta podría permitir solo consultar pedidos. Ampliar esos permisos necesitaría una decisión explícita y un diseño acordado.',
        ['client', 'identity'],
        [{label:'Permisos posibles', value:'Leer · Crear · Gestionar'}, {label:'Quién los decide', value:'La cuenta, según el modelo acordado'}]),
      phase('Las APIs comprueban también al agente.',
        'Cada operación tendría que acreditar identidad, cuenta y permisos. El backend aplicaría las mismas restricciones sobre los datos. Ser un agente no permitiría saltarse los controles del portal.',
        ['apim', 'backend', 'identity'],
        [{label:'Acceso', value:'Identidad y ámbito de cuenta'}, {label:'Control', value:'Permiso para cada operación'}]),
      phase('El agente propone. Una persona confirma.',
        'En este ejemplo, el robot prepara un borrador sintético y lo entrega a una persona para revisarlo y confirmar su contenido. No se envía ningún pedido al sistema de pedidos.',
        ['client', 'backend'],
        [{label:'Acción ilustrada', value:'Proponer un borrador'}, {label:'Envío de pedido', value:'No realizado'}]),
      phase('El siguiente paso es acordar los límites.',
        'Una integración real debe definir operaciones, permisos, aprobaciones y trazabilidad. La animación ilustra un borrador supervisado, sin conceder al agente permiso para enviar pedidos.',
        ['client', 'identity', 'observe'],
        [{label:'Por decidir', value:'Permisos, aprobaciones y registro'}, {label:'Integración real', value:'Por diseñar y validar'}]),
    ],
  },
];

const PHASE_SECONDS = 4;
function timing(story) {
  let at = 0;
  const phases = story.phases.map((phase, index) => {
    const duration = story.phaseDurations?.[index] ?? PHASE_SECONDS;
    const timed = {...phase, at, duration, index};
    at += duration;
    return timed;
  });
  return {phases, duration: at};
}
export const EXTENSION_SCENARIOS = stories.map(story => {
  const {id, label, summary, category, badge, context} = story;
  return {id, label, summary, category, badge, context, duration: timing(story).duration};
});

export function getExtensionPhases(id) {
  const story = stories.find(story => story.id === id);
  return story ? timing(story).phases.map(({at, title, index}) => ({at, title, index})) : [];
}

export function sampleExtension(id, time) {
  const story = stories.find(candidate => candidate.id === id);
  if (!story) throw new Error('Recorrido complementario desconocido');
  const {phases, duration} = timing(story);
  const t = Math.max(0, Math.min(duration, Number(time) || 0));
  const phaseIndex = phases.findLastIndex(phase => t >= phase.at);
  const current = phases[phaseIndex];
  const progress = Math.max(0, Math.min(1, (t - current.at) / current.duration));
  return {
    scenario: id,
    time: t,
    duration,
    phaseIndex,
    title: current.title,
    copy: current.copy,
    active: [...current.active],
    focus: [],
    token: {visible: false},
    work: [],
    workTime: 0,
    ledger: {},
    saved: false,
    uncertain: false,
    extension: {id, phaseIndex, progress, time: t},
    insight: current.insight.map(item => ({...item})),
  };
}
