import {PROJECT} from './project.js';
if(!['commerce','custom'].includes(PROJECT.recipe))throw new Error('PROJECT.recipe debe ser commerce o custom.');
const isCustom=PROJECT.recipe==='custom';
// An unfinished inactive recipe must not execute or block the selected one.
const story=isCustom?await import('./custom-story.js'):await import('./story.js');
const architecture=isCustom?(await import('../examples/custom-architecture/model.js')).CUSTOM:await import('./architecture.js');
export const {SCENARIOS,sampleScenario,getStartTime,getChapters,getReadingSteps}=story;
export const NODES=isCustom?architecture.nodes:architecture.NODES;
export const EDGES=isCustom?architecture.edges:architecture.EDGES;
export const SUPPORTS=isCustom?(architecture.supports||[]):architecture.SUPPORTS;
export const STATUS=PROJECT.status;
export const SERVICE_ICONS={...(isCustom?{}:architecture.SERVICE_ICONS),...Object.fromEntries([...NODES,...SUPPORTS].filter(n=>Object.hasOwn(n,'icon')).map(n=>[n.id,n.icon]))};
export const createScene=isCustom?(await import('./custom-scene.js')).createCustomScene:(await import('./scene.js')).createScene;
