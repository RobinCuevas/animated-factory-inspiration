import { PROJECT, MACHINE_THEME } from './project.js';
import * as THREE from 'three';
import { createAsset } from '../kit/index.js';
import { makeWorkshop } from '../shared/primitives.js';
import { CAPACITY_JOBS, CAPACITY_MACHINES, sampleCapacity } from './capacity-story.js';
import { createBrandMarks, brandMachine } from '../shared/brand-marks.js';
import { SERVICE_ICONS, NODES } from './architecture.js';

const ACCENT = PROJECT.palette.accent;
const REQUEST = 0xd9b87a;
const RESULT = 0x739b83;
const theme = MACHINE_THEME;

export function createCapacityDemo() {
  const object = new THREE.Group();
  object.name = 'Capacidad · copias del mismo backend';
  const decor = makeWorkshop();
  object.add(decor.root);
  const assets = [], machines = [], tickets = new Map(), geometries = new Set(), materials = new Set();
  let state = sampleCapacity(0), disposed = false;
  const brandMarks = createBrandMarks();
  const material = color => {
    const value = new THREE.MeshStandardMaterial({ color, roughness: .56, metalness: .15 });
    materials.add(value); return value;
  };
  const pathMaterial = material(0xb79489), darkMaterial = material(0x64524c);
  decor.box(23.8, .2, 12.7, decor.palette.ivory, [0, -.16, 1.05], .08);
  const title = decor.label('COPIAS DEL MISMO BACKEND', [0, .012, -5.02], { width: 10.5, height: .5, color: '#7b514b', background: null });
  title.rotation.x = -Math.PI / 2;
  const incoming = decor.label('SOLICITUDES DE CÁLCULO', [0, .015, 7.02], { width: 10, height: .4, color: '#805b52', background: null });
  incoming.rotation.x = -Math.PI / 2;

  function group(name, position) {
    const value = new THREE.Group();
    value.name = name; value.position.fromArray(position); decor.root.add(value);
    return value;
  }
  const put = (parent, item) => { parent.attach(item); return item; };
  function path(route, { radius = .025, y = -.05, target = object } = {}) {
    const geometry = new THREE.TubeGeometry(route, 90, radius, 5, false);
    geometries.add(geometry);
    const mesh = new THREE.Mesh(geometry, pathMaterial);
    mesh.position.y = y; mesh.castShadow = true; object.add(mesh); target.attach(mesh);
    return mesh;
  }

  for (const specification of CAPACITY_MACHINES) {
    const x = specification.x;
    const asset = createAsset('processor', { theme });
    asset.object.position.set(x, 0, 0);
    object.add(asset.object); assets.push(asset);
    const support = group(`Infraestructura de la copia ${specification.id + 1}`, [x, 0, 0]);
    const bench = group(`Mesa de solicitudes ${specification.id + 1}`, [x, 0, 5.7]);
    const output = group(`Resultados conservados de la copia ${specification.id + 1}`, [x + 2.35, 0, -4.25]);
    const base = put(support, decor.box(3.7, .07, 3.5, decor.palette.ivory, [x, -.014, 0], .05));
    const service = NODES.find(node => node.id === 'backend');
    brandMachine(brandMarks, asset, 'backend', { label: specification.label, icon: service?.icon === undefined ? SERVICE_ICONS.backend : service.icon, serviceLabel: service?.mark?.label ?? service?.service?.split(' · ')[0] });
    const status = put(support, decor.label('En espera', [x, .032, -1.95], { width: 3.6, height: .36, color: '#846b60', background: null }));
    status.rotation.x = -Math.PI / 2;
    // The staging bench suggests requests waiting for compute, not an extra broker.
    put(bench, decor.box(3.7, .12, 1.9, decor.palette.ivory, [x, 1.08, 5.7], .04));
    for (const side of [-1, 1]) {
      put(bench, decor.box(.12, 1.05, .12, decor.palette.steel, [x + side * 1.6, .53, 5.7], .02));
      put(bench, decor.box(.06, .08, 1.9, decor.palette.teal, [x + side * 1.82, 1.18, 5.7], .015));
    }
    // An intake bridge clears the front console. The chamber itself stays open.
    put(support, decor.box(1.2, .07, 2.55, decor.palette.steel, [x, 1.12, 2.02], .015));
    for (const side of [-1, 1]) put(support, decor.box(.05, .09, 2.55, decor.palette.teal, [x + side * .62, 1.17, 2.02], .01));
    put(support, decor.box(.1, 1.06, .1, decor.palette.steel, [x, .53, 3.2], .012));
    const tray = put(output, decor.box(1.5, .08, 1.32, decor.palette.steel, [x + 2.35, 1.095, -4.25], .025));
    for (const side of [-1, 1]) put(output, decor.box(.08, 1.05, .08, decor.palette.steel, [x + 2.35 + side * .51, .525, -4.25], .01));
    const resultSign = put(output, decor.label('Resultados', [x + 2.35, .02, -3.25], { width: 2.1, height: .33, color: '#607667', background: null }));
    resultSign.rotation.x = -Math.PI / 2;
    const exemplar = CAPACITY_JOBS.find(job => job.machine === specification.id);
    path(exemplar.routes.exiting, { radius: .042, y: -.055, target: support });
    // Two continuous guide rails around the sealed side/back of the machine.
    const outerPoints = [
      [x + .63, 1.11, 2.27], [x + 2.35, 1.11, 2.72],
      [x + 2.8, 1.11, 2.12], [x + 2.8, 1.11, -3.7], [x + 2.35, 1.11, -4.3],
    ];
    const outside = new THREE.CatmullRomCurve3(outerPoints.map(p => new THREE.Vector3().fromArray(p)), false, 'centripetal');
    path(outside, { radius: .024, y: 0, target: support });
    for (const z of [2.3, -.8, -3.45]) put(support, decor.box(.055, 1.05, .055, decor.palette.steel, [x + 2.35, .525, z], .01));
    machines.push({ asset, base, status, tray, bench, support, output });
  }

  for (const job of CAPACITY_JOBS) {
    path(job.routes.entering, { radius: .017, y: -.07, target: machines[job.machine].support });
    const ticket = new THREE.Group(); ticket.name = job.id; decor.root.add(ticket);
    const bodyMaterial = material(REQUEST);
    const body = decor.box(.72, .05, .54, bodyMaterial, [0, 0, 0], .02); ticket.add(body);
    const label = decor.label(job.id, [0, .028, 0], { width: .6, height: .36, color: '#503d35', background: '#fff9ef' });
    label.rotation.x = -Math.PI / 2; ticket.add(label);
    const stripe = decor.box(.055, .008, .46, darkMaterial, [-.3, .029, 0], .002); ticket.add(stripe);
    tickets.set(job.id, { object: ticket, bodyMaterial, label });
  }

  const bounds = new THREE.Box3(new THREE.Vector3(-12, -.3, -5.5), new THREE.Vector3(12, 4.1, 7.45));

  function update(capacity) {
    if (disposed) throw new Error('La demostración de capacidad ya está liberada.');
    state = capacity;
    for (let index = 0; index < machines.length; index++) {
      const { asset, status, bench, support, output } = machines[index];
      const scale = capacity.replicaScales[index];
      const current = capacity.jobs.find(job => job.machine === index && job.stage === 'processing');
      const serving = capacity.jobs.some(job => job.machine === index && ['entering', 'processing', 'exiting'].includes(job.stage));
      asset.object.visible = scale > .001;
      asset.object.scale.setScalar(Math.max(.001, scale));
      support.visible = scale > .001;
      support.scale.setScalar(Math.max(.001, scale));
      bench.visible = capacity.tableScales[index] > .001;
      bench.scale.setScalar(Math.max(.001, capacity.tableScales[index]));
      output.visible = capacity.outputScales[index] > .001;
      output.scale.setScalar(Math.max(.001, capacity.outputScales[index]));
      asset.update(current ? current.processingProgress * 3.3 : 0, { processing: Boolean(current) });
      asset.object.userData.model.userData.document.visible = false;
      status.userData.setText(scale < .001 ? 'Disponible si hace falta' : scale < .999 ? (capacity.time < 6.25 ? 'Preparando copia' : 'Retirando copia') : current ? `Procesando ${current.id}` : serving ? 'Recibiendo / entregando' : 'Lista para trabajar');
    }
    for (const job of capacity.jobs) {
      const ticket = tickets.get(job.id);
      ticket.object.visible = job.visible;
      ticket.object.position.fromArray(job.position);
      ticket.object.rotation.y = job.yaw;
      ticket.bodyMaterial.color.setHex(job.result ? RESULT : REQUEST);
    }
    return inspect();
  }

  function inspect() {
    return {
      time: state.time, duration: state.duration, replicas: state.replicas, pending: state.pending, completed: state.completed,
      processing: state.processing, totalTickets: tickets.size, transferring: state.transferring,
      brandRendering: brandMarks.inspect(),
      tables: machines.map(({ bench }, index) => ({ id: index, visible: bench.visible, scale: bench.scale.x, pending: state.jobs.filter(job => job.table === index).map(job => job.id) })),
      outputs: machines.map(({ output }, index) => ({ id: index, visible: output.visible, scale: output.scale.x, results: state.jobs.filter(job => job.machine === index && job.stage === 'completed').map(job => job.id) })),
      machines: machines.map(({ asset, support }, index) => ({ id: index, visible: asset.object.visible, scale: asset.object.scale.x, supportVisible: support.visible, stamping: Boolean(asset.object.userData.model?.userData.stamping), internalDocumentVisible: Boolean(asset.object.userData.model?.userData.document.visible) })),
      jobs: state.jobs.map(job => ({ id: job.id, uuid: tickets.get(job.id).object.uuid, machine: job.machine, table: job.table, stage: job.stage, position: tickets.get(job.id).object.position.toArray(), visible: tickets.get(job.id).object.visible, result: job.result })),
    };
  }

  function dispose() {
    if (disposed) return;
    disposed = true;
    const workshopMaterials = new Set();
    decor.root.traverse(item => {
      for (const owned of item.material ? (Array.isArray(item.material) ? item.material : [item.material]) : []) workshopMaterials.add(owned);
    });
    brandMarks.dispose();
    for (const asset of assets) asset.dispose();
    decor.dispose();
    for (const geometry of geometries) geometry.dispose();
    for (const owned of materials) if (!workshopMaterials.has(owned)) owned.dispose();
    object.removeFromParent(); object.clear();
  }
  update(state);
  return { object, bounds, update, inspect, dispose };
}
