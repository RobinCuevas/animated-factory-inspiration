/** Project identity and presentation defaults. Customer assets are optional.
 * Keep provider logos in their original colours. Scene colours belong here.
 * The commerce recipe is a worked example, not an infrastructure requirement. */
export const PROJECT = {
  title: 'Fábrica digital',
  subtitle: 'Del usuario al resultado',
  recipe: 'commerce',
  customer: { name: null, logo: null },
  palette: {
    accent: '#386f83', soft: '#a9c6ce', frame: '#4d6672',
    dark: '#34464e', steel: '#8a979b', background: '#f4f5f2',
  },
  status: 'Ejemplo ilustrativo · Datos sintéticos',
  playback: { defaultSpeed: 2, pentestSpeed: 1, cameraSeconds: 1.1 },
  rendering: { maxPixels: 8_388_608 },
  sections: ['consultation', 'preparation', 'submission', 'ambiguous', 'attachments', 'capacity', 'knowledge', 'pentest', 'agents'],
};

// The procedural kit consumes hexadecimal numbers rather than CSS colours.
const hex = value => Number.parseInt(value.replace('#', ''), 16);
export const MACHINE_THEME = Object.fromEntries(
  ['accent', 'soft', 'frame'].map(key => [key, hex(PROJECT.palette[key])]),
);

/** Workshop materials are owned by each instance, so recolouring is isolated. */
export function applyProjectPalette(palette, colours = PROJECT.palette) {
  for (const [material, key] of [['teal', 'accent'], ['dark', 'dark'], ['steel', 'steel']]) {
    if (palette[material] && colours[key]) palette[material].color.set(colours[key]);
  }
  return palette;
}
