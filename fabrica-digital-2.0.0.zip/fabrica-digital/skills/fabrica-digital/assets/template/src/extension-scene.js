import * as THREE from 'three';
import { makeWorkshop } from '../shared/primitives.js';
import { createAsset } from '../kit/index.js';
import { createBrandMarks } from '../shared/brand-marks.js';
import { createAIRobot } from '../shared/characters.js';
import { PROJECT, MACHINE_THEME } from './project.js';

const ACCENT = PROJECT.palette.accent;
const theme = MACHINE_THEME;
const clamp = value => THREE.MathUtils.clamp(Number.isFinite(value) ? value : 0, 0, 1);
const ease = value => { const t = clamp(value); return t * t * (3 - 2 * t); };
const pulse = value => Math.sin(clamp(value) * Math.PI);

// Character helpers are reusable outside this worked example.
export { createAIRobot } from '../shared/characters.js';

function makeStage(title, tone = 'normal') {
  const object = new THREE.Group(); object.name = title;
  const workshop = makeWorkshop(); object.add(workshop.root);
  const { palette: p, box, cylinder, rod, label } = workshop;
  const assets = [], robots = [], stations = [], papers = [], highlights = [];
  box(20, .18, 12, p.ivory, [0, -.15, 0], .1);
  box(20.05, .055, 12.05, p.steel, [0, -.28, 0], .03);
  const caption = label(title, [0, -.045, -5.25], { width: 15.8, height: .52, color: tone === 'explore' ? '#946b32' : '#855550', background: null });
  caption.rotation.x = -Math.PI / 2;
  function floorLabel(text, x, z, width = 3.7, color = '#715751') {
    const item = label(text, [x, .006, z], { width, height: .43, color, background: null });
    item.rotation.x = -Math.PI / 2; return item;
  }
  function station(id, text, x, z, { width = 3.5, depth = 3.1 } = {}) {
    box(width, .035, depth, p.white, [x, -.03, z], .06);
    const lightMaterial = new THREE.MeshStandardMaterial({ color: ACCENT, emissive: ACCENT, emissiveIntensity: 0, roughness: .5 });
    const light = box(width - .35, .045, .065, lightMaterial, [x, .007, z + depth / 2 - .14], .01);
    highlights.push({ id, material: lightMaterial });
    const tag = floorLabel(text, x, z + depth / 2 + .36, width + .3);
    stations.push({ id, position: [x, 0, z], label: text });
    return { light, tag };
  }
  function asset(id, x, z, scale = .7, options = {}) {
    const value = createAsset(id, { theme, ...options });
    value.object.position.set(x, 0, z); value.object.scale.setScalar(scale);
    object.add(value.object); assets.push(value); return value;
  }
  function robot(x, z, scale = 1, options = {}) {
    const value = createAIRobot(options); value.object.position.set(x, 0, z); value.object.scale.setScalar(scale);
    object.add(value.object); robots.push(value); return value;
  }
  function route(points, { color = 0xbeada2, dashed = false } = {}) {
    const curve = new THREE.CatmullRomCurve3(points.map(point => new THREE.Vector3().fromArray(point)), false, 'centripetal');
    const material = new THREE.MeshStandardMaterial({ color, roughness: .7, metalness: .08 });
    if (dashed) {
      const path = curve.getPoints(50);
      for (let i = 0; i < path.length - 1; i += 2) rod(path[i].toArray(), path[i + 1].toArray(), .028, material);
    } else {
      const mesh = new THREE.Mesh(new THREE.TubeGeometry(curve, 64, .029, 6, false), material);
      workshop.root.add(mesh); mesh.receiveShadow = true;
    }
    return curve;
  }
  function paper(name, color = 0xfffaf0, { citation = false } = {}) {
    const group = new THREE.Group(); group.name = name; workshop.root.add(group);
    const material = new THREE.MeshStandardMaterial({ color, roughness: .75, metalness: 0 });
    group.add(box(.82, .06, 1.08, material, [0, 0, 0], .025));
    group.add(box(.12, .015, .94, p.teal, [-.29, .042, 0], .009));
    for (let i = 0; i < 4; i++) group.add(box(.46 - (i % 2) * .1, .012, .026, p.steel, [.04, .042, -.3 + i * .13], .002));
    const citations = new THREE.Group(); group.add(citations);
    if (citation) for (let i = 0; i < 2; i++) citations.add(box(.19, .02, .15, p.purple, [-.05 + i * .23, .047, .32], .015));
    const value = { object: group, material, name, citations }; papers.push(value); return value;
  }
  function table(x, z, width = 2, depth = 1.15) {
    const top = box(width, .12, depth, p.ivory, [x, .95, z], .05);
    for (const side of [-1, 1]) box(.12, .91, .12, p.steel, [x + side * (width / 2 - .16), .46, z], .018);
    return top;
  }
  function screen(x, z, { width = 1.65, text = '', color = '#7b514b' } = {}) {
    box(width, .96, .14, p.dark, [x, 1.61, z], .07);
    box(width - .15, .8, .025, p.white, [x, 1.63, z + .087], .03);
    box(.08, .43, .08, p.steel, [x, 1.08, z], .01);
    box(.65, .05, .36, p.steel, [x, .99, z], .02);
    const tag = label(text, [x, 1.7, z + .11], { width: width - .25, height: .29, color, background: null });
    for (let i = 0; i < 2; i++) box(width * .55, .025, .018, p.steel, [x, 1.47 - i * .12, z + .112], .003);
    return tag;
  }
  function move(value, curve, progress, height = 0) {
    const t = ease(progress); value.object.position.copy(curve.getPoint(t)); value.object.position.y += height;
    const tangent = curve.getTangent(t); value.object.rotation.y = Math.atan2(tangent.x, tangent.z);
  }
  function activate(ids = []) {
    for (const item of highlights) item.material.emissiveIntensity = ids.includes(item.id) ? .35 : 0;
  }
  let disposed = false;
  function dispose() {
    if (disposed) return; disposed = true;
    for (const value of assets) value.dispose();
    for (const value of robots) value.dispose();
    workshop.dispose(); object.removeFromParent(); object.clear();
  }
  return { object, workshop, p, box, cylinder, rod, label, floorLabel, station, asset, robot, route, paper, table, screen, move, activate, stations, papers, robots, dispose };
}

function makeKnowledge() {
  const stage = makeStage('CONSULTA · RESPUESTA AL CLIENTE · CONOCIMIENTO VALIDADO');
  const { p, box } = stage;
  const brandStatus = {};
  const marks = createBrandMarks({ status: brandStatus });
  stage.station('question', 'Cliente · consulta y respuesta', -7.8, 2.3, { width: 3.3, depth: 3.3 });
  stage.table(-7.8, 1.9, 2.35, 1.55);
  const clientScreen = stage.screen(-7.8, 1.48, { text: 'Mi consulta' });
  const client = stage.asset('human', -7.8, 3.2, 1.1);
  client.object.rotation.y = Math.PI;
  stage.station('sources', 'Fuentes autorizadas', -6.1, -2.15, { width: 4.3, depth: 3.2 });
  const archive = stage.asset('archive', -6.1, -2.2, .58);
  stage.station('search', 'Azure AI Search', -.95, -2.15, { width: 3.9, depth: 3.2 });
  box(2.1, 1.55, 1.95, p.ivory, [-.95, .8, -2.15], .13);
  box(2.18, .16, 2.04, p.white, [-.95, 1.63, -2.15], .04);
  marks.stamp(stage.object, './brand/azure-ai-search.svg', [-.95, 1.717, -2.15], [1.52, 1.52], {
    rotation: [-Math.PI / 2, 0, 0], nodeId: 'ai-search', surface: 'techo de búsqueda',
  });
  marks.text(stage.object, 'Azure AI Search', [-.95, 1.35, -1.162], [1.8, .27], { surface: 'frontal de búsqueda' });
  box(1.16, .065, 1.25, p.steel, [-.95, 1.005, -.5], .035);
  for (const side of [-1, 1]) box(.08, .96, .08, p.steel, [-.95 + side * .46, .48, -.5], .01);
  // Ten persistent reading copies make retrieval visible. The retained originals
  // never leave the archive. Each copy returns to exactly the slot it came from.
  const sourceDocuments = [];
  const originalFolios = archive.object.userData.model.userData.originals;
  for (const row of [0, 1]) box(2.7, .065, .16, p.steel, [-6.1, 1.255 + row * .64, -1.145], .014);
  for (let index = 0; index < 10; index++) {
    const row = Math.floor(index / 5), column = index % 5;
    const type = index < 6 ? 'technical-document' : 'resolved-inquiry';
    const id = `SOURCE-${String(index + 1).padStart(2, '0')}`;
    const object = new THREE.Group(); object.name = `Copia de consulta ${id}`; stage.workshop.root.add(object);
    object.userData.documentId = id; object.userData.kind = 'source-reading-copy';
    const material = new THREE.MeshStandardMaterial({color: type === 'technical-document' ? 0xf4fbff : 0xf8f3ff, emissive: 0x6c83bb, emissiveIntensity: 0, roughness: .78});
    object.add(box(.43, .036, .56, material, [0, 0, 0], .014));
    const stripeMaterial = new THREE.MeshStandardMaterial({color: type === 'technical-document' ? 0x498aaa : 0x8972aa, roughness: .6});
    object.add(box(.065, .01, .49, stripeMaterial, [-.164, .025, 0], .005));
    for (let line = 0; line < 3; line++) object.add(box(.24 - line * .025, .007, .018, p.steel, [.035, .025, -.03 + line * .075], .002));
    const tag = stage.label(`${type === 'technical-document' ? 'DOC' : 'CASO'} ${String(index + 1).padStart(2, '0')}`, [.025, .027, -.18], {width:.3,height:.105,color:type === 'technical-document' ? '#376c87' : '#755992',background:null});
    tag.rotation.x = -Math.PI / 2; object.add(tag);
    const home = new THREE.Vector3(-7.14 + column * .52, 1.57 + row * .64, -1.145 + row * .015);
    const search = new THREE.Vector3(-2.13 + column * .59, 1.98 + row * .64, -.91 + row * .09);
    const curve = new THREE.CatmullRomCurve3([
      home,
      home.clone().add(new THREE.Vector3(.6, .38, .46)),
      new THREE.Vector3(-3.05 + column * .035, search.y + .12, -.15 + row * .09),
      search,
    ], false, 'centripetal');
    const source = {id, type, object, material, home, search, curve, state:'archived', travel:0};
    sourceDocuments.push(source);
  }
  const scanMaterial = new THREE.MeshStandardMaterial({color:0x7bade1,emissive:0x578dcc,emissiveIntensity:.4,transparent:true,opacity:.5,depthWrite:false,roughness:.5});
  const sourceScanner = box(3.03, .032, .045, scanMaterial, [-.95, 2.2, -.77], .01);
  sourceScanner.visible = false;
  stage.route([[-6.1, 1.18, -1.1], [-4.2, 1.18, -.85], [-2.55, 1.18, -1.34], [-.95, 1.18, -1.1]], { color: 0xb2a0c5, dashed: true });
  function updateSourceDocuments(phase, progress) {
    const p = phase === 1 ? progress : 0;
    sourceDocuments.forEach((source, index) => {
      const outStart = .03 + index * .014, outEnd = outStart + .23;
      const backStart = .54 + index * .013, backEnd = backStart + .29;
      let travel = 0, state = 'archived';
      if (phase === 1 && p >= outStart && p < outEnd) { travel = ease((p - outStart) / .23); state = 'retrieving'; }
      else if (phase === 1 && p >= outEnd && p < backStart) { travel = 1; state = 'searching'; }
      else if (phase === 1 && p >= backStart && p < backEnd) { travel = 1 - ease((p - backStart) / .29); state = 'returning'; }
      source.state = state; source.travel = travel;
      source.object.visible = true;
      source.object.position.copy(source.curve.getPoint(travel));
      source.object.rotation.set(Math.PI / 2 - .28 * Math.sin(travel * Math.PI), 0, 0);
      source.material.emissiveIntensity = state === 'searching' ? .14 + .25 * pulse(clamp((p - .38) / .18)) : 0;
    });
    sourceScanner.visible = phase === 1 && p >= .39 && p <= .56;
    sourceScanner.position.y = 2.96 - 1.3 * ease((p - .39) / .17);
  }
  stage.station('assistant', 'Azure OpenAI · asistente', .05, 2.1, { width: 4.6, depth: 3.45 });
  const assistantDesk = stage.table(.05, 2.1, 3.3, 1.65);
  const robot = stage.robot(-.75, .69, 1.1, { brand: 'azure-openai' });
  // The robot stands behind the back edge (z=1.275), facing its work surface.
  // Its body and chest plate stay clear of the desk; only the working arm reaches in.
  stage.station('review', 'Equipo técnico', 6.3, 1.8, { width: 4.7, depth: 3.5 });
  const reviewer = stage.asset('review', 6.3, 1.45, .98);
  reviewer.object.userData.model.userData.human.userData.document.visible = false;
  stage.floorLabel('La misma consulta conserva su respuesta y sus fuentes', .35, -4.25, 12.6);
  const caseSheet = stage.paper('Caso C-001 · consulta y respuesta', 0xe0bd83, { citation: true });
  caseSheet.object.userData.documentId = 'C-001';
  caseSheet.object.userData.kind = 'case';
  const reference = stage.paper('Ficha reutilizable · copia validada del caso C-001', 0x93b79b, { citation: true });
  reference.object.scale.set(.58, 1, .58);
  reference.object.userData.documentId = 'KNOWLEDGE-C-001';
  reference.object.userData.kind = 'validated-reference';
  const referenceLabel = stage.label('Ficha validada', [0, .065, 0], { width: .71, height: .3, color: '#335c46', background: '#d5e7da' });
  referenceLabel.rotation.x = -Math.PI / 2;
  reference.object.add(referenceLabel);
  const points = {
    client: [-7.8, 1.04, 2.1],
    search: [-.95, 1.068, -.5],
    desk: [-.13, 1.04, 1.86],
    review: [5.15, 1.245, 1.11],
    archive: [-6.1, 1.12, -1.1],
  };
  const routes = {
    question: stage.route([points.client, [-5, 1.14, 2.4], [-3.25, 1.2, .3], points.search], { color: 0xd1b88e }),
    compose: stage.route([points.search, [.8, 1.25, -.1], [.65, 1.2, 1.27], points.desk]),
    review: stage.route([points.desk, [2.8, 1.2, 2.65], [4.25, 1.3, 2.0], points.review]),
    deliver: stage.route([points.review, [7.75, 1.25, 3.65], [2.0, 1.15, 4.65], [-4.9, 1.12, 4.5], points.client], { color: 0x82a28e }),
    reuse: stage.route([[-7.8, 1.3, 2.1], [-8.75, 1.35, .7], [-8.85, 1.25, -1.0], points.archive], { color: 0x82a28e, dashed: true }),
  };
  const delivery = stage.label('RESPUESTA RECIBIDA', [-7.8, .012, 4.47], { width: 3.9, height: .42, color: '#426b53', background: null });
  delivery.rotation.x = -Math.PI / 2;
  const stored = stage.label('Nueva ficha validada', [-6.1, .012, -4.12], { width: 4.1, height: .4, color: '#426b53', background: null });
  stored.rotation.x = -Math.PI / 2;
  let sampled = { clientAnswered: false, knowledgeStored: false, responseValidated: false };
  function placeCase(curve, progress) {
    caseSheet.object.position.copy(curve.getPoint(ease(progress)));
    // Its orientation stays constant across adjoining routes and pauses.
    caseSheet.object.rotation.set(0, 0, 0);
  }
  function update({ phaseIndex: phase, progress, time }) {
    const clientAnswered = phase >= 6 || (phase === 5 && progress >= .8 - 1e-9);
    const knowledgeStored = phase === 6 && progress >= .86;
    const responseValidated = phase >= 5 || (phase === 4 && progress >= .55);
    sampled = { clientAnswered, knowledgeStored, responseValidated };
    stage.activate([['question'], ['sources', 'search'], ['assistant', 'search'], ['assistant', 'review'], ['review'], ['question', 'review'], ['sources', 'question']][phase] || []);
    archive.update(time, { open: phase === 1 || phase === 6 ? .7 : 0 });
    client.update(time, { walking: false, identified: true, document: false });
    robot.update(time, {
      working: phase === 2,
      progress,
      workTarget: [1.378 / 1.1, .67],
      contact: ease((progress - .35) / .15),
    });
    updateSourceDocuments(phase, progress);
    caseSheet.object.visible = true;
    caseSheet.object.scale.setScalar(1);
    caseSheet.citations.visible = phase >= 3 || (phase === 2 && progress >= .55);
    caseSheet.material.color.setHex(responseValidated ? 0xb9d0be : phase >= 2 ? 0xfffaf0 : 0xe0bd83);
    if (phase === 0) placeCase(routes.question, progress);
    if (phase === 1) { caseSheet.object.position.fromArray(points.search); caseSheet.object.rotation.set(0, 0, 0); }
    if (phase === 2) placeCase(routes.compose, clamp(progress / .35));
    if (phase === 3) placeCase(routes.review, progress);
    if (phase === 4) { caseSheet.object.position.fromArray(points.review); caseSheet.object.rotation.set(0, 0, 0); }
    if (phase === 5) placeCase(routes.deliver, clamp(progress / .8));
    if (phase === 6) { caseSheet.object.position.fromArray(points.client); caseSheet.object.rotation.set(0, 0, 0); }
    // A distinctly smaller green index card appears only after the client has
    // received the response. It has an explicit meaning, not a duplicate token.
    reference.object.visible = phase === 6 && progress > .10;
    reference.object.position.copy(routes.reuse.getPoint(ease(clamp((progress - .1) / .76))));
    reference.object.rotation.set(0, 0, 0);
    reference.object.scale.set(.58, 1, .58);
    delivery.visible = clientAnswered;
    stored.visible = knowledgeStored;
    clientScreen.userData.setText(clientAnswered ? 'Respuesta + fuentes' : 'Mi consulta');
  }
  function detail() {
    const robotState = robot.inspect();
    const bodyBounds = new THREE.Box3(new THREE.Vector3().fromArray(robotState.bodyBounds.min), new THREE.Vector3().fromArray(robotState.bodyBounds.max));
    const deskBounds = new THREE.Box3().setFromObject(assistantDesk);
    const tip = new THREE.Vector3().fromArray(robotState.stylusTip);
    const sheetPosition = caseSheet.object.getWorldPosition(new THREE.Vector3());
    return {
      humanValidation: true,
      sourcesRequired: true,
      sourceRetrieval: {
        total: sourceDocuments.length,
        archived: sourceDocuments.filter(source => source.state === 'archived').length,
        inTransit: sourceDocuments.filter(source => source.state === 'retrieving' || source.state === 'returning').length,
        atSearch: sourceDocuments.filter(source => source.state === 'searching').length,
        copiesAlwaysVisible: sourceDocuments.every(source => source.object.visible),
        uniqueDocumentCount: new Set(sourceDocuments.map(source => source.object.uuid)).size,
        originalsRemainStored: originalFolios.visible,
        scannerVisible: sourceScanner.visible,
        allReturned: sourceDocuments.every(source => source.object.position.distanceTo(source.home) < 1e-8),
        documents: sourceDocuments.map(source => ({id:source.id,uuid:source.object.uuid,type:source.type,kind:'source-reading-copy',state:source.state,progress:source.travel,position:source.object.position.toArray(),home:source.home.toArray(),search:source.search.toArray(),visible:source.object.visible})),
      },
      ...sampled,
      addedToKnowledge: sampled.knowledgeStored,
      mainDocumentId: caseSheet.object.userData.documentId,
      mainDocumentUUID: caseSheet.object.uuid,
      mainDocumentCount: 1,
      knowledgeReferenceVisible: reference.object.visible,
      robotBehindDesk: bodyBounds.max.z < deskBounds.min.z,
      robotBodyIntersectsDesk: bodyBounds.intersectsBox(deskBounds),
      robotBodyDeskClearance: deskBounds.min.z - bodyBounds.max.z,
      robotBodyBounds: robotState.bodyBounds,
      deskBounds: { min: deskBounds.min.toArray(), max: deskBounds.max.toArray() },
      stylusPaperHeightDistance: Math.abs(tip.y - (sheetPosition.y + .03)),
      stylusOverPaper: Math.abs(tip.x - sheetPosition.x) < .41 && Math.abs(tip.z - sheetPosition.z) < .54,
      brandMarks: marks.inspect(), brandStatus: { ...brandStatus },
    };
  }
  return { ...stage, update, detail, dispose() { marks.dispose(); stage.dispose(); } };
}

function shield(stage, x, z) {
  const outline = [[0, 1.25], [.88, .9], [.77, -.17], [.49, -.67], [0, -1.03], [-.49, -.67], [-.77, -.17], [-.88, .9], [0, 1.25]];
  const object = new THREE.Group(); object.position.set(x, 1.6, z); stage.workshop.root.add(object);
  const shape = new THREE.Shape(); outline.forEach(([a, b], index) => index ? shape.lineTo(a, b) : shape.moveTo(a, b));
  const material = new THREE.MeshStandardMaterial({ color: 0xd2ad70, emissive: 0xc69a53, emissiveIntensity: .05, transparent: true, opacity: .14, side: THREE.DoubleSide, depthWrite: false, roughness: .42 });
  const membrane = new THREE.Mesh(new THREE.ShapeGeometry(shape), material); object.add(membrane);
  for (let i = 0; i < outline.length - 1; i++) object.add(stage.rod([...outline[i], .02], [...outline[i + 1], .02], .045, stage.p.amber));
  const minus = object.add(stage.box(.56, .07, .045, stage.p.amber, [0, .07, .04], .015));
  function update(amount) { material.opacity = .10 + .15 * amount; material.emissiveIntensity = .04 + .25 * amount; object.scale.setScalar(1 + .06 * amount); }
  return { object, update, material, minus };
}

function makePentest() {
  const stage = makeStage('PENTEST EXTERNO · COMPORTAMIENTO QUE DEBERÁ VERIFICARSE', 'explore');
  const { p, box, cylinder } = stage;
  stage.station('tester', 'Empresa externa', -7.6, 1.25, { width: 3.8, depth: 3.3 });
  stage.table(-7.6, .78, 2.35); stage.screen(-7.6, .48, { text: 'Prueba autorizada', width: 1.85 });
  const human = stage.asset('human', -7.6, 2, 1.1, { bodyColor: 0xeee9db, tool: 'clipboard' });
  human.object.rotation.y = Math.PI;
  // A white hat identifies the external testing role without treating it as an attacker in production.
  const hat = new THREE.Group(); hat.position.set(-7.6, 1.67, 2); stage.workshop.root.add(hat);
  hat.add(cylinder(.23, .045, p.white)); hat.add(cylinder(.16, .14, p.white, [0, .08, 0]));
  stage.station('perimeter', 'Entrada protegida', -2.35, .7, { width: 3.3, depth: 3.1 });
  const gate = stage.asset('identity', -2.35, .65, 1.04);
  const barrier = shield(stage, -2.35, 1.31);
  stage.station('backend', 'Cuenta y permisos', 2.65, .7, { width: 3.7, depth: 3.1 });
  const backend = stage.asset('processor', 2.65, .65, .6);
  const accountShield = shield(stage, 2.65, 1.75); accountShield.object.scale.setScalar(.85);
  stage.station('data', 'Datos de otra cuenta', 7.65, -2.35, { width: 3.5, depth: 3.2 });
  const data = stage.asset('database', 7.65, -2.4, .53);
  stage.station('report', 'Evidencia y revisión', 7.05, 2.35, { width: 4.1, depth: 2.75 });
  stage.table(7.05, 2.1, 2.8); stage.screen(7.05, 1.8, { text: 'Hallazgos', width: 1.8 });
  const permit = stage.paper('Alcance autorizado', 0xe2c799);
  const probe = stage.paper('Solicitud de prueba', 0xddaa76);
  const report = stage.paper('Evidencia para corregir y volver a comprobar', 0xfffaf0, { citation: true });
  const routes = {
    perimeter: stage.route([[-7.6, 1.15, 1.05], [-5.6, 1.18, 2.2], [-3.6, 1.2, 2.05], [-2.35, 1.3, 1.72]], { color: 0xc5a56e }),
    account: stage.route([[-7.6, 1.15, 1.05], [-5.9, 1.2, 3.3], [-.4, 1.2, 3.3], [2.65, 1.35, 2.1]], { color: 0xc5a56e }),
    data: stage.route([[2.65, .09, -.7], [4.35, .09, -2.6], [7.65, .09, -2.6]], { color: 0xd4c6b4, dashed: true }),
    report: stage.route([[2.65, 1.18, 1.7], [4.5, 1.22, 3.05], [7.05, 1.1, 2.4]], { color: 0xa8a398 }),
    review: stage.route([[7.05, 1.1, 2.4], [4.65, 1.2, 4.4], [-5.3, 1.2, 4.4], [-7.6, 1.15, 1.05]], { color: 0xa8a398, dashed: true }),
  };
  const accountLabel = stage.floorLabel('Cuenta A ≠ cuenta B', 2.7, -2.36, 4.5, '#926c36');
  const response = stage.label('ACCESO DENEGADO', [-2.35, 3.22, 1.31], { width: 3.3, height: .43, color: '#966631', background: '#fff6e7' });
  function update({ phaseIndex: phase, progress, time }) {
    stage.activate([['tester'], ['tester', 'perimeter'], ['tester', 'backend'], ['report'], ['tester', 'report']][phase] || []);
    human.update(time, { walking: false, identified: true, document: false });
    gate.update(time, { authorized: false, open: 0 });
    data.update(time, { open: 0 });
    backend.update(0, { processing: false });
    const rejected = (phase === 1 || phase === 2) && progress > .52;
    barrier.update(phase === 1 ? pulse(progress) : 0);
    accountShield.update(phase === 2 ? pulse(progress) : 0);
    accountShield.object.scale.multiplyScalar(.85);
    permit.object.visible = phase === 0;
    permit.object.position.set(-7.6, 1.095, 1.02); permit.object.rotation.y = -.15;
    probe.object.visible = phase === 1 || phase === 2;
    report.object.visible = phase >= 3;
    response.visible = rejected;
    response.position.x = phase === 2 ? 2.65 : -2.35;
    response.position.z = phase === 2 ? 1.75 : 1.31;
    if (phase === 1 || phase === 2) {
      const travel = progress < .58 ? progress / .58 : 1 - .55 * ease((progress - .58) / .42);
      stage.move(probe, phase === 1 ? routes.perimeter : routes.account, travel);
    }
    if (phase === 3) stage.move(report, routes.report, progress);
    if (phase === 4) stage.move(report, routes.review, progress);
    accountLabel.material.opacity = phase === 2 ? 1 : .65;
  }
  return { ...stage, update, detail: () => ({ illustrativeOnly: true, pentestExecuted: false, dataDoorOpen: data.object.userData.state?.open || 0, automaticDefenseAI: false }) };
}

function makeAgents() {
  const stage = makeStage('HUMANOS + AGENTES · IDEA PARA DEBATIR', 'explore');
  const { p, box, cylinder } = stage;
  stage.station('client', 'Agente del cliente', -7.2, 1.65, { width: 4, depth: 3.5 });
  stage.table(-7.2, .85, 2.5); stage.screen(-7.2, .55, { text: 'Cliente / filial', width: 1.9 });
  const robot = stage.robot(-7.2, 2.0, 1.12); robot.object.rotation.y = Math.PI;
  stage.station('permissions', 'Permisos concedidos', -2.0, -1.8, { width: 4.4, depth: 3.7 });
  const permissionLabels = ['Leer', 'Crear', 'Gestionar'];
  const permissionCards = [];
  for (let i = 0; i < 3; i++) {
    const x = -3.35 + i * 1.35;
    box(1.12, 1.48, .22, p.ivory, [x, .82, -1.8], .075);
    const chipMaterial = new THREE.MeshStandardMaterial({ color: i === 0 ? 0x739b83 : 0xd9b87a, roughness: .6, emissive: 0xd9b87a, emissiveIntensity: 0 });
    box(.87, .07, .27, chipMaterial, [x, 1.58, -1.8], .015);
    stage.label(permissionLabels[i], [x, .59, -1.674], { width: .97, height: .24, color: '#69504a', background: null });
    const lock = box(.4, .31, .055, p.steel, [x, 1.05, -1.65], .05);
    const arch = new THREE.Mesh(new THREE.TorusGeometry(.12, .034, 8, 20, Math.PI), p.steel);
    arch.position.set(x, 1.23, -1.65); stage.workshop.root.add(arch);
    permissionCards.push({ material: chipMaterial, lock });
  }
  stage.station('backend', 'API + backend Portal', 3.0, -1.15, { width: 3.9, depth: 3.5 });
  stage.asset('api', 3.0, -1.15, .64);
  stage.station('review', 'La persona confirma', 6.6, 2.0, { width: 4.7, depth: 3.6 });
  stage.asset('review', 6.6, 1.65, .95);
  const scope = stage.floorLabel('Identidad · cuenta · límites', 2.6, -3.7, 5.4);
  const discussion = stage.label('PROPUESTA PARA CONVERSAR', [-.4, .04, 4.75], { width: 9.8, height: .45, color: '#956e34', background: null });
  discussion.rotation.x = -Math.PI / 2;
  const request = stage.paper('Solicitud del agente', 0xe2c18b);
  const draft = stage.paper('Borrador propuesto, pendiente de acción humana', 0xfffaf0, { citation: true });
  const credential = stage.paper('Permisos limitados de la cuenta', 0xe2c18b);
  const routes = {
    permissions: stage.route([[-7.2, 1.11, 1.15], [-5.5, 1.15, .55], [-4.2, 1.2, -1.0], [-2.0, 1.23, -1.35]], { color: 0xc6ab79 }),
    backend: stage.route([[-2, 1.2, -1.35], [.4, 1.2, -.1], [3, 1.2, -.8]], { color: 0xc6ab79 }),
    review: stage.route([[3, 1.2, -.8], [4.35, 1.3, .25], [6.6, 1.3, 1.6]], { color: 0xbeada2 }),
  };
  function update({ phaseIndex: phase, progress, time }) {
    stage.activate([['client'], ['permissions'], ['backend', 'permissions'], ['review'], ['client', 'review']][phase] || []);
    robot.update(time, { working: phase === 0 || phase === 2, progress });
    request.object.visible = phase === 0;
    credential.object.visible = phase === 1 || phase === 2;
    draft.object.visible = phase === 3 || phase === 4;
    request.object.position.set(-7.2, 1.11, 1.13);
    request.object.rotation.y = -.1 + .2 * pulse(progress);
    if (phase === 1) stage.move(credential, routes.permissions, progress);
    if (phase === 2) stage.move(credential, routes.backend, progress);
    if (phase === 3) stage.move(draft, routes.review, Math.min(1, progress * 1.6));
    if (phase === 4) { draft.object.position.set(6.6, 1.32, 1.6); draft.object.rotation.y = 0; }
    for (let i = 0; i < permissionCards.length; i++) permissionCards[i].material.emissiveIntensity = phase === 1 ? .1 + .16 * pulse(clamp(progress * 3 - i)) : 0;
    scope.userData.setText(phase === 2 ? 'Mismas comprobaciones para cada solicitud' : 'Identidad · cuenta · límites');
    discussion.material.opacity = phase === 4 ? 1 : .72;
  }
  return { ...stage, update, detail: () => ({ exploratory: true, liveIntegration: false, externalAgent: true, permissionTiers: ['leer', 'crear', 'gestionar'], humanConfirmation: true, automaticOrderSubmission: false }) };
}

export function createExtensionDemo() {
  const object = new THREE.Group(); object.name = 'Portal · IA, validación de seguridad y evolución';
  const bounds = new THREE.Box3(new THREE.Vector3(-10.1, -.31, -6.1), new THREE.Vector3(10.1, 4.05, 6.1));
  const scenes = new Map();
  const factories = { knowledge: makeKnowledge, pentest: makePentest, agents: makeAgents };
  const counts = { knowledge: 7, pentest: 5, agents: 5 };
  let state = { id: 'knowledge', phaseIndex: 0, progress: 0, time: 0 }, disposed = false;
  function update(value = {}) {
    if (disposed) throw new Error('La demostración de extensiones ya está liberada.');
    const id = Object.hasOwn(factories, value.id) ? value.id : 'knowledge';
    state = { id, phaseIndex: Math.max(0, Math.min(counts[id] - 1, Math.floor(Number.isFinite(value.phaseIndex) ? value.phaseIndex : 0))), progress: clamp(value.progress), time: Number.isFinite(value.time) ? value.time : 0 };
    if (!scenes.has(id)) { const scene = factories[id](); scenes.set(id, scene); object.add(scene.object); }
    for (const [key, scene] of scenes) scene.object.visible = key === id;
    scenes.get(id).update(state);
    object.updateMatrixWorld(true);
    return inspect();
  }
  function inspect() {
    const scene = scenes.get(state.id);
    return { ...state, ...scene?.detail(), stations: scene?.stations.map(value => ({ ...value, position: [...value.position] })) || [], documents: scene?.papers.map(value => ({ name: value.name, id: value.object.userData.documentId || null, uuid: value.object.uuid, kind: value.object.userData.kind || 'document', position: value.object.position.toArray(), visible: value.object.visible })) || [], robots: scene?.robots.map(value => value.inspect()) || [], builtScenarios: [...scenes.keys()] };
  }
  function dispose() { if (disposed) return; disposed = true; for (const scene of scenes.values()) scene.dispose(); scenes.clear(); object.removeFromParent(); object.clear(); }
  update(state);
  return { object, bounds, update, inspect, dispose };
}
