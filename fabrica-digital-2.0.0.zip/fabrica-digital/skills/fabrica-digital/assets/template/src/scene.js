import { PROJECT, MACHINE_THEME } from './project.js';
import * as THREE from 'three';
import {createAsset} from '../kit/index.js';
import {createConveyorPath} from '../kit/conveyor-path.js';
import {makeWorkshop} from '../shared/primitives.js';
import {createViewer} from '../shared/viewer.js';
import {NODES,EDGES,SERVICE_ICONS} from './architecture.js';
import {SCENARIOS,getPhases,sampleScenario} from './story.js';
import {createCapacityDemo} from './capacity-scene.js';
import {createExtensionDemo,createAIRobot} from './extension-scene.js';
import {createFactoryOverlay} from './factory-overlay.js';
import {createBrandMarks,brandMachine} from '../shared/brand-marks.js';

const V=p=>new THREE.Vector3().fromArray(p);
const clamp=x=>Math.max(0,Math.min(1,Number(x)||0));
const smooth=x=>{const p=clamp(x);return p*p*(3-2*p);};
const COLORS={request:0x4b9fad,order:0xd8aa59,result:0x63a387,receipt:0x8375b1,reference:0x8375b1,file:0x5d98c0,unknown:0xdb9e43};
const FACTORY_THEME=MACHINE_THEME;

export function createScene(stage,{onSelect=()=>{}}={}){
  const object=new THREE.Group();object.name=`${PROJECT.title} · ${PROJECT.status}`;
  const decor=makeWorkshop();object.add(decor.root);
  const palette=decor.palette,assets=new Map(),nodes=new Map(),edges=new Map();
  const geometries=new Set(),materials=new Set(),belts=[],brandAssets={};
  let snapshot=null,mode='guided',selected=null,focusKey='',disposed=false,pointerStart=null;
  stage.style.position='relative';
  const viewer=createViewer(stage,{padding:1.22,onManual:()=>{mode='manual';}});
  const brandMarks=createBrandMarks({anisotropy:Math.min(8,viewer.renderer.capabilities.getMaxAnisotropy()),status:brandAssets});
  const labels=document.createElement('div');labels.className='factory-machine-labels';
  labels.style.cssText='position:absolute;inset:0;pointer-events:none;overflow:hidden;z-index:2';
  const leaders=document.createElementNS('http://www.w3.org/2000/svg','svg');
  leaders.setAttribute('aria-hidden','true');leaders.style.cssText='position:absolute;inset:0;width:100%;height:100%;pointer-events:none';labels.append(leaders);stage.append(labels);
  function material(color,extras={}){const mat=new THREE.MeshStandardMaterial({color,roughness:.6,metalness:.1,...extras});materials.add(mat);return mat;}
  function tile(x,z,width,depth,color){const slab=decor.box(width,.15,depth,material(color),[x,-.1,z],.06);slab.receiveShadow=true;return slab;}
  tile(1.6,-3.3,28.5,17.6,0xeae5e0);tile(-15,-7,5.2,5.8,0xeae5e0);tile(-15,.1,5,5,0xe1e8ec);
  tile(-20,5,5.7,6.7,0xeae4d9);tile(20,.3,5.4,5.6,0xe8e0d2);tile(.5,10,12.3,7,0xe8e0d2);
  tile(13.1,9.3,9.5,6,0xeae5e0);
  // Plinths express ownership and role, not network borders or subnets.
  function floorLabel(text,pos,width,color='#587466'){const label=decor.label(text,pos,{width,height:.62,color,background:null});label.rotation.x=-Math.PI/2;return label;}
  floorLabel('MICROSOFT AZURE · ENTORNO CORPORATIVO',[-2.9,.004,-11.1],8.4,'#6f6461');
  floorLabel('ENTRADA PROTEGIDA',[-15,.004,2.35],4.15,'#526a7b');
  floorLabel('SISTEMAS CORPORATIVOS',[.5,.004,13.12],9,'#78694f');floorLabel(NODES.find(node=>node.id==='orders')?.label||'Pedidos',[20,.004,-2.18],3.5,'#78694f');
  if(PROJECT.customer.logo){
    brandMarks.stamp(object,PROJECT.customer.logo,[13.1,.016,9.1],[8.5,3],{rotation:[-Math.PI/2,0,0],resolution:4096,surface:'suelo del entorno del cliente'});
  }else{
    floorLabel(PROJECT.customer.name||PROJECT.title,[13.1,.016,9.1],8.5,PROJECT.palette.accent);
  }
  floorLabel('MICROSOFT AZURE',[10.4,.018,11.25],3.4,'#766866');
  function localPoint(id,point){return assets.get(id).object.localToWorld(V(point));}
  function dockFor(spec){
    if(spec.id==='queue')return localPoint(spec.id,[0,1.21,0]);
    if(spec.id==='sql')return localPoint(spec.id,[0,1.91,2.65]);
    if(spec.id==='entry')return localPoint(spec.id,[0,1.05,1.66]);
    const z={client:2.7,entry:1.56,frontend:1.84,apim:1.84,backend:2.5,worker:2.5,blob:3.12,orders:2.15,erp:2.15,pricing:2.15}[spec.id]??2;
    return localPoint(spec.id,[0,1.38,z]);
  }
  for(const spec of NODES){
    const asset=createAsset(spec.asset,{theme:spec.scope==='core'?'amber':FACTORY_THEME});
    asset.object.position.fromArray(spec.position);asset.object.rotation.y=Number(spec.rotation)||0;asset.object.scale.setScalar(Number(spec.scale)||1);
    asset.object.userData.nodeId=spec.id;object.add(asset.object);assets.set(spec.id,asset);
    asset.update(0,{processing:false,count:0,running:false,open:0,authorized:false,walking:false});
    const model=asset.object.userData.model;if(spec.id==='entry')model.scale.x=1.18;if(model.userData.document)model.userData.document.visible=false;if(model.userData.copies)model.userData.copies.visible=false;
    brandMachine(brandMarks,asset,spec.id,{label:spec.label,icon:spec.icon===undefined?SERVICE_ICONS[spec.id]??null:spec.icon,serviceLabel:spec.mark?.label??spec.service?.split(' · ')[0]});
    asset.object.updateMatrixWorld(true);
    const bounds=new THREE.Box3().setFromObject(asset.object),dock=dockFor(spec),statusMat=material(0x7b938c,{emissive:0x000000});
    const status=decor.cylinder(.13,.045,statusMat,[spec.position[0],.035,spec.position[2]+1.7]);
    const ring=decor.cylinder(Math.max(1.5,(bounds.max.x-bounds.min.x)*.57),.025,material(0x57a896,{transparent:true,opacity:0,depthWrite:false}),[spec.position[0],-.005,spec.position[2]]);
    const button=document.createElement('button');button.type='button';button.dataset.nodeId=spec.id;button.className='factory-machine-label';button.textContent=spec.label;
    button.setAttribute('aria-label',`${spec.label}. Ver qué recibe, qué hace y qué entrega.`);
    button.style.cssText='position:absolute;pointer-events:auto;max-width:170px;min-height:32px;padding:7px 10px;border:1px solid rgba(100,123,112,.28);border-radius:7px;background:rgba(252,252,245,.96);color:#314940;font:600 13px/1.3 "DM Sans",sans-serif;box-shadow:0 2px 8px #293e3510;white-space:normal;text-align:center;cursor:pointer;transition:background .15s,border-color .15s,opacity .15s';
    button.addEventListener('click',()=>{select(spec.id);onSelect(spec.id);});labels.append(button);
    const leader=document.createElementNS('http://www.w3.org/2000/svg','line');leader.setAttribute('stroke','#7d9488');leader.setAttribute('stroke-width','.8');leaders.append(leader);
    const top=new THREE.Vector3(spec.position[0],bounds.max.y+1.05,spec.position[2]);nodes.set(spec.id,{spec,asset,bounds,dock,button,leader,top,ring,status,statusMat});
    if(spec.id!=='queue'){
      const tray=decor.box(1.24,.06,.86,palette.steel,dock.clone().add(new THREE.Vector3(0,-.055,0)).toArray(),.035);tray.userData.nodeId=spec.id;
      for(const dx of [-.59,.59])decor.box(.035,.13,.86,palette.teal,dock.clone().add(new THREE.Vector3(dx,-.014,0)).toArray(),.009);
      for(const dx of [-.37,.37])decor.box(.075,Math.max(.2,dock.y-.085),.075,palette.steel,[dock.x+dx,(dock.y-.085)/2,dock.z],.009);
    }
  }
  object.updateMatrixWorld(true);
  const routePoints={
    'client-entry':[[-18,1.38,7.7],[-18,1.38,3.8],[-15,1.38,3.8]],
    'entry-frontend':[[-12.2,1.12,-1.45],[-12.2,1.38,-3.6],[-15,1.38,-3.6]],
    'entry-apim':[[-12.2,1.12,-1.45],[-12.2,1.38,3.6],[-9,1.38,3.6]],
    'apim-backend':[[-9,1.38,3.65],[-2,1.38,3.65]],
    'backend-sql':[[-5.5,1.48,3.8],[-5.5,1.7,-4.1],[-2,1.91,-4.1]],
    'backend-blob':[[.65,1.38,3.5],[.65,1.38,-3.7],[6,1.38,-3.7]],
    'backend-queue':[[-2,1.38,4.8],[1,1.3,4.8],[1,1.1,0]],
    'queue-worker':[[8.8,1.14,0],[9.6,1.3,2.5]],
    'worker-orders':[[12,1.38,4.4],[20,1.38,4.4]],
    'worker-sql':[[12,1.55,5.7],[-6.4,1.65,5.7],[-6.4,1.83,-4.1],[-2,1.91,-4.1]],
    'backend-erp':[[-7.2,1.38,6.3],[-7.2,1.38,14.2],[-3,1.38,14.2]],
    'backend-pricing':[[.8,1.38,6.7],[7.8,1.38,6.7],[7.8,1.38,14.2],[4,1.38,14.2]],
  };
  for(const spec of EDGES){
    if(!nodes.has(spec.from)||!nodes.has(spec.to))continue;
    const key=`${spec.from}-${spec.to}`,start=spec.from==='entry'?localPoint('entry',[0,1.05,-1.4]):nodes.get(spec.from).dock,end=nodes.get(spec.to).dock,waypoints=(routePoints[key]||[]).map(V);
    if(spec.to==='queue')waypoints.push(localPoint('queue',[0,1.21,-3]));
    if(spec.from==='queue')waypoints.unshift(localPoint('queue',[0,1.21,3]));
    const curve=new THREE.CatmullRomCurve3([start.clone(),...waypoints,end.clone()],false,'centripetal');curve.arcLengthDivisions=320;curve.updateArcLengths();
    const geom=new THREE.TubeGeometry(curve,Math.max(32,Math.ceil(curve.getLength()*5)),.067,5,false);geometries.add(geom);
    const mat=material(0x91a89f,{transparent:true,opacity:.45}),mesh=new THREE.Mesh(geom,mat);mesh.position.y=-.092;mesh.castShadow=true;object.add(mesh);
    const supports=[];
    for(let d=1.8;d<curve.getLength()-1;d+=3.2){const point=curve.getPointAt(d/curve.getLength());if(point.y>.6)supports.push(decor.box(.035,point.y-.12,.035,palette.steel,[point.x,(point.y-.12)/2,point.z],0));}
    edges.set(key,{spec,key,curve,mesh,mat,supports,length:curve.getLength()});
  }
  // A real conveyor continues the queue before the worker's intake tray.
  const queueNode=nodes.get('queue');
  if(Math.abs(Math.abs(queueNode.asset.object.rotation.y)-Math.PI/2)<.01){
    const out=localPoint('queue',[0,1.21,3]);
    if(out.x>5&&out.x<8.5){const belt=createConveyorPath([{type:'line',from:[out.x,out.z],to:[8.45,out.z]}],{height:out.y-.026,width:1.08});object.add(belt.object);belts.push(belt);}
  }
  function makeTicket(id,color){
    const item=new THREE.Group();decor.root.add(item);const mat=material(color,{roughness:.45});
    const body=decor.box(1.06,.05,.75,mat,[0,0,0],.025);item.add(body);
    const face=decor.label(id,[0,.029,0],{width:.88,height:.48,color:'#173f35',background:'#fff7e6'});face.rotation.x=-Math.PI/2;item.add(face);
    const stripe=decor.box(.09,.006,.66,palette.teal,[-.46,.028,0],.002);item.add(stripe);item.userData.body=body;item.userData.label=face;return {object:item,material:mat,label:face,stripe};
  }
  const ticket=makeTicket('P-042',COLORS.order),savedRecord=makeTicket('P-042 · GUARDADO',COLORS.order);
  const receiptTicket=makeTicket('Acuse',COLORS.receipt),sqlReceipt=makeTicket('Vínculo guardado',COLORS.receipt),readCopy=makeTicket('Copia · ADJ-042',COLORS.file);
  receiptTicket.object.scale.setScalar(.66);sqlReceipt.object.scale.setScalar(.62);
  savedRecord.object.visible=false;receiptTicket.object.visible=false;sqlReceipt.object.visible=false;readCopy.object.visible=false;
  const attachmentSkins=new Map();
  function attachmentSkin(item,type){
    const skin=new THREE.Group();skin.name=`ADJ-042 · ${type}`;item.object.add(skin);skin.visible=false;
    const reference=type==='reference'||type==='acknowledgement',copy=type==='copy';
    const ink=reference?'#644b96':'#255d88',paper=material(reference?0xeee6fb:0xf7fbff,{roughness:.82,metalness:0});
    skin.add(decor.box(.95,.004,.64,paper,[0,.029,0],.013));
    const title=decor.label(reference?(type==='reference'?'REF':'OK'):copy?'PDF · COPIA':'PDF',[0,.033,-.095],{width:.83,height:.31,color:ink,background:null});title.rotation.x=-Math.PI/2;skin.add(title);
    const identifier=decor.label('ADJ-042',[0,.033,.205],{width:.81,height:.16,color:ink,background:null});identifier.rotation.x=-Math.PI/2;skin.add(identifier);
    if(copy){
      const border=material(0x377ca8,{roughness:.8,metalness:0});
      for(const x of [-.443,.443])skin.add(decor.box(.015,.003,.582,border,[x,.033,0],0));
      for(const z of [-.291,.291])skin.add(decor.box(.894,.003,.015,border,[0,.033,z],0));
    }
    attachmentSkins.set(item,{skin,type});
  }
  attachmentSkin(ticket,'original');attachmentSkin(readCopy,'copy');attachmentSkin(receiptTicket,'reference');attachmentSkin(sqlReceipt,'acknowledgement');
  const sqlInside=localPoint('sql',[0,1.91,.35]),metadataInside=localPoint('sql',[0,1.98,.35]);
  const sqlAckOrigin=localPoint('sql',[0,2.055,.35]);
  const blobShelf=localPoint('blob',[0,1.7,.98]),blobAckOrigin=blobShelf.clone().add(new THREE.Vector3(0,.065,0));
  savedRecord.object.position.copy(sqlInside);savedRecord.object.scale.setScalar(.78);
  decor.box(1.28,.06,1.4,palette.steel,localPoint('sql',[0,1.855,.25]).toArray(),.025);
  decor.box(.09,1.56,.09,palette.steel,localPoint('sql',[0,1.03,.25]).toArray(),.01);
  decor.box(1.08,.06,3.2,palette.steel,localPoint('entry',[0,.995,.13]).toArray(),.022);
  const storageBadge=decor.label('ORIGINAL · ADJ-042',localPoint('blob',[0,1.63,1.68]).toArray(),{width:1.8,height:.28,color:'#255d88',background:'#e7edf0'});storageBadge.visible=false;
  const savedBadge=decor.label('BORRADOR GUARDADO',localPoint('sql',[0,.33,2.9]).toArray(),{width:2.6,height:.35,color:'#386849',background:'#e3eddf'});savedBadge.rotation.x=-Math.PI/2;savedBadge.visible=false;
  const unknownRing=decor.cylinder(.73,.025,material(COLORS.unknown,{transparent:true,opacity:.3,emissive:COLORS.unknown,emissiveIntensity:.2}),[0,0,0]);unknownRing.visible=false;
  const scan=decor.box(.94,.014,.045,material(0x73ddc0,{emissive:0x3bd5b0,emissiveIntensity:.7}),[0,0,0],.005);scan.visible=false;
  const workPaths=new Map();
  for(const id of ['backend','worker']){
    const n=nodes.get(id),work=localPoint(id,id==='backend'?[0,1.005,.12]:[0,1.313,.16]);
    workPaths.set(id,new THREE.CatmullRomCurve3([n.dock.clone(),localPoint(id,[0,1.38,1.58]),localPoint(id,[0,work.y-n.asset.object.position.y,.65]),work],false,'centripetal'));
  }
  let activeTicket=ticket,actualRecord=savedRecord,gateOpen=0,sqlOpen=0,beltTravel=0;
  let ticketPose={visible:false,id:null,kind:null,node:null,route:null,progress:0,position:[0,0,0]};
  const capacityDemo=createCapacityDemo();capacityDemo.object.visible=false;viewer.scene.add(capacityDemo.object);
  const extensionDemo=createExtensionDemo();extensionDemo.object.visible=false;viewer.scene.add(extensionDemo.object);
  const factoryOverlay=createFactoryOverlay({nodes,edges});object.add(factoryOverlay.object);factoryOverlay.object.visible=false;
  // Face the fixed camera and work beside the order, outside its transport lane.
  const assistant=createAIRobot({brand:'azure-openai'});assistant.object.position.set(-3.8,-.02,2);assistant.object.rotation.y=.2;assistant.object.scale.setScalar(1.1);object.add(assistant.object);assistant.object.visible=false;
  assistant.object.updateMatrixWorld(true);
  const suggestionRest=assistant.object.localToWorld(new THREE.Vector3(.56,1.04,.73));
  const assistantBase=new THREE.Group();decor.root.add(assistantBase);assistantBase.visible=false;
  const suggestionTray=decor.box(.9,.055,.67,palette.steel,suggestionRest.clone().add(new THREE.Vector3(0,-.044,0)).toArray(),.025);suggestionTray.rotation.y=.2;assistantBase.add(suggestionTray);
  assistantBase.add(decor.box(.07,suggestionRest.y-.09,.07,palette.steel,[suggestionRest.x,(suggestionRest.y-.09)/2,suggestionRest.z],.012));
  const suggestion=makeTicket('Accesorio opcional',0xd7c5e4);suggestion.object.scale.setScalar(.66);suggestion.object.rotation.y=.2;suggestion.object.visible=false;
  function segmentTravel(points,amount){
    const lengths=points.slice(1).map((p,i)=>p.distanceTo(points[i])),total=lengths.reduce((a,b)=>a+b,0);let remaining=clamp(amount)*total;
    for(let i=0;i<lengths.length;i++){if(remaining<=lengths[i]||i===lengths.length-1)return points[i].clone().lerp(points[i+1],lengths[i]?clamp(remaining/lengths[i]):1);remaining-=lengths[i];}return points[0].clone();
  }
  function blobTravel(amount,inside=blobShelf){const dock=nodes.get('blob').dock;return segmentTravel([dock,dock.clone().setY(inside.y),inside.clone().setZ(-6.25),inside],amount);}
  function opening(progress){return smooth(progress/.18)*(1-smooth((progress-.83)/.17));}
  function chooseRoute(pair){const direct=edges.get(`${pair[0]}-${pair[1]}`);if(direct)return {edge:direct,reverse:false};const reverse=edges.get(`${pair[1]}-${pair[0]}`);return reverse?{edge:reverse,reverse:true}:null;}
  function boxFor(ids){
    const box=new THREE.Box3();for(const id of ids||[]){const node=nodes.get(id);if(node){box.union(node.bounds);box.expandByPoint(node.dock);}}
    // Some return routes go around the factory. Fit the entire conveyor, not
    // only its two machines, so the document stays in frame on wide screens.
    const selectedIds=new Set(ids||[]);
    for(const edge of edges.values())if(selectedIds.has(edge.spec.from)&&selectedIds.has(edge.spec.to))for(const p of edge.curve.getPoints(80))box.expandByPoint(p);
    if(box.isEmpty())for(const node of nodes.values())box.union(node.bounds);
    box.min.x-=1.5;box.max.x+=1.5;box.min.z-=1;box.max.z+=2.4;box.max.y+=1.8;return box;
  }
  function follow(ids,immediate=false){const key=[...(ids||[])].sort().join('|');if(key===focusKey&&!immediate)return;focusKey=key;viewer.focus(boxFor(ids),{immediate});}
  // Camera shots group related actions, rather than changing zoom at each
  // hand-off. Their full transport paths are included by boxFor().
  const cameraShots=new Map();
  const shots={entry:['client','entry','apim','backend'],commercial:['backend','erp','pricing'],draft:['backend','sql'],dispatch:['backend','queue','worker'],orders:['worker','orders'],record:['worker','sql','backend'],storage:['backend','sql','blob'],response:['backend','apim','entry','client']};
  for(const scenario of SCENARIOS.filter(s=>!['capacity','knowledge','pentest','agents'].includes(s.id))){
    let shot='entry';
    cameraShots.set(scenario.id,getPhases(scenario.id).map(phase=>{
      const state=sampleScenario(scenario.id,phase.at+.001),route=state.token.route;
      if(state.token.node==='backend'&&shot==='entry')shot=({preparation:'draft',submission:'dispatch',ambiguous:'dispatch',attachments:'storage'})[scenario.id]||'entry';
      if(scenario.id==='consultation'&&route?.[1]==='erp')shot='commercial';
      if(route?.[0]==='worker'&&route[1]==='orders')shot='orders';
      if(route?.[0]==='worker'&&route[1]==='sql')shot='record';
      if(route?.[0]==='backend'&&route[1]==='apim')shot='response';
      return {name:shot,ids:shots[shot]};
    }));
  }
  function guidedFocus(state,fallback){
    return cameraShots.get(state?.scenario)?.[state?.phaseIndex]?.ids||fallback||state?.focus||state?.active;
  }
  function extensionBounds(overview=false){
    if(overview||!snapshot?.extension)return extensionDemo.bounds.clone();
    const selections={
      knowledge:[['question','sources','search','assistant'],['question','sources','search','assistant'],['question','sources','search','assistant'],['assistant','review'],['assistant','review'],['question','sources','review'],['question','sources','review']],
      pentest:[['tester'],['tester','perimeter'],['backend','data'],['backend','report'],['tester','report']],
      agents:[['client'],['permissions'],['permissions','backend'],['backend','review'],['client','review']],
    };
    const ids=selections[snapshot.scenario]?.[snapshot.extension.phaseIndex]||[];
    const box=new THREE.Box3();
    for(const station of extensionDemo.inspect().stations.filter(s=>ids.includes(s.id))){
      const [x,,z]=station.position;
      box.union(new THREE.Box3(new THREE.Vector3(x-2.35,-.1,z-2.3),new THREE.Vector3(x+2.35,2.9,z+2.7)));
    }
    return box.isEmpty()?extensionDemo.bounds.clone():box;
  }
  function factoryOverlayBounds(overview=false){
    const all=overview||(snapshot?.scenario==='pentest'&&snapshot?.phaseIndex===4)||(snapshot?.scenario==='agents'&&snapshot?.phaseIndex===4);
    const ids=all?[...nodes.keys()]:(factoryOverlay.getFocusIds?.()||['client','entry','backend']);
    const box=boxFor(ids);
    const extra=all?(factoryOverlay.boundsByScenario?.[snapshot?.scenario]||factoryOverlay.bounds):factoryOverlay.getPhaseBounds?.(snapshot?.extension);
    if(extra?.isBox3)box.union(extra);
    return box;
  }
  function update(state){
    if(disposed)return inspect();
    const wasCapacity=snapshot?.scenario==='capacity',wasExtension=Boolean(snapshot?.extension),previousScenario=snapshot?.scenario;snapshot=state;
    const fullFactory=['pentest','agents'].includes(state.scenario);
    if(['pentest','agents'].includes(previousScenario)&&!fullFactory)factoryOverlay.reset();
    factoryOverlay.object.visible=fullFactory;
    if(state.extension&&!fullFactory){
      object.visible=false;labels.hidden=true;capacityDemo.object.visible=false;extensionDemo.object.visible=true;
      extensionDemo.update(state.extension);
      if(previousScenario!==state.scenario){selected=null;mode='guided';focusKey='';}
      const key=`${state.scenario}:${state.scenario==='knowledge'?(state.phaseIndex<3?'retrieve':state.phaseIndex<5?'review':'reply'):state.phaseIndex}`;
      if(mode==='guided'&&focusKey!==key){focusKey=key;viewer.focus(extensionBounds(),{padding:1.12});}
      return inspect();
    }
    extensionDemo.object.visible=false;
    if(state.scenario==='capacity'){
      object.visible=false;labels.hidden=true;capacityDemo.object.visible=true;
      capacityDemo.update(state.capacity);
      if(!wasCapacity){selected=null;mode='guided';focusKey='capacity';viewer.focus(capacityDemo.bounds.clone().expandByScalar(1.1));}
      return inspect();
    }
    object.visible=true;labels.hidden=false;capacityDemo.object.visible=false;
    if(wasCapacity||(wasExtension&&previousScenario!==state.scenario)){mode='guided';focusKey='';}
    assistant.object.visible=state.scenario==='preparation';assistantBase.visible=assistant.object.visible;
    const a=state.assistant;
    assistant.update(state.time,{working:a?.mode==='suggest',progress:a?.progress||0,workTarget:[1.335,.62],contact:smooth(clamp((a?.progress||0)/.35))});
    suggestion.object.visible=Boolean(a);
    suggestion.object.position.copy(suggestionRest);
    if(a)suggestion.object.position.y+=.12*(1-smooth(clamp(a.progress/.35)));
    const work=new Set(state.work||[]),active=new Set(state.active||[]),token=state.token||{visible:false};
    const localTime=Math.max(0,Math.min(3,Number(state.workTime)||0)),progress=clamp(token.progress);
    const persistence=state.persistence||(token.node==='sql'&&state.scenario==='submission'?{mode:'status',progress:clamp((state.workTime||0)/3.3)}:null);
    const databaseProgress=clamp(persistence?.progress),storage=state.storage,storageProgress=clamp(storage?.progress);
    const isPreparation=state.scenario==='preparation',isAttachment=state.scenario==='attachments';
    for(const [item,{skin}] of attachmentSkins){skin.visible=isAttachment;item.label.visible=!isAttachment;item.stripe.visible=!isAttachment;}
    const draftDeposited=isPreparation&&Boolean(state.saved),fileDeposited=isAttachment&&Boolean(state.attachmentSaved),metadataDeposited=isAttachment&&Boolean(state.attachmentLinked);
    const copying=storage?.mode==='reading'&&storageProgress>=.44;
    const returningCopy=fileDeposited&&((!storage&&token.kind==='file')||copying);
    activeTicket=returningCopy?readCopy:metadataDeposited?sqlReceipt:fileDeposited||draftDeposited?receiptTicket:ticket;
    gateOpen=state.gate?.mode==='pass'?opening(clamp(state.gate.progress)):0;
    sqlOpen=persistence?opening(databaseProgress):0;
    for(const [id,n] of nodes){
      const at=token.node===id&&token.visible!==false,working=work.has(id)&&at;
      n.asset.update(working?localTime:0,{processing:working,count:0,running:false,open:id==='sql'?sqlOpen:id==='entry'?gateOpen:0,authorized:id==='entry'&&gateOpen>.01,walking:false});
      const model=n.asset.object.userData.model;
      if(model.userData.document)model.userData.document.visible=false;
      if(model.userData.copies)model.userData.copies.visible=false;
      n.ring.material.opacity=selected===id?.2:active.has(id)?.095:0;
      n.statusMat.color.set(state.uncertain&&(id==='sql'||id==='orders')?COLORS.unknown:working?0xd6aa55:active.has(id)?0x4fa486:0x82958d);
      n.statusMat.emissive.set(working?0x4c3510:0);n.statusMat.emissiveIntensity=.14;
      n.button.style.background=selected===id?'#f2e5e0':active.has(id)?'#fffdf4':'rgba(248,246,240,.93)';
      n.button.style.borderColor=selected===id?PROJECT.palette.accent:active.has(id)?PROJECT.palette.soft:'rgba(130,111,105,.23)';
      n.button.setAttribute('aria-pressed',String(selected===id));n.button.dataset.active=String(active.has(id));
    }
    for(const edge of edges.values()){
      const moving=token.route&&((token.route[0]===edge.spec.from&&token.route[1]===edge.spec.to)||(token.route[1]===edge.spec.from&&token.route[0]===edge.spec.to));
      edge.mat.color.set(moving?(COLORS[token.kind]||COLORS.request):0x9d938e);edge.mat.opacity=moving?.98:.25;
    }
    // Persistent originals and derivative receipts have separate identities.
    for(const item of [ticket,receiptTicket,sqlReceipt,readCopy])item.object.visible=false;
    if(draftDeposited){ticket.object.visible=true;ticket.object.position.copy(sqlInside);ticket.object.rotation.y=0;ticket.material.color.set(COLORS.order);ticket.label.userData.setText('P-042 · BORRADOR');}
    if(fileDeposited){ticket.object.visible=true;ticket.object.position.copy(blobShelf);ticket.object.rotation.y=0;ticket.material.color.set(COLORS.file);ticket.label.userData.setText('ADJ-042 · ARCHIVO');}
    if(metadataDeposited){receiptTicket.object.visible=true;receiptTicket.object.position.copy(metadataInside);receiptTicket.object.rotation.y=0;receiptTicket.material.color.set(COLORS.reference);receiptTicket.label.userData.setText('Ficha · ADJ-042');}
    activeTicket.object.visible=token.visible!==false&&Boolean(token.node||token.route);scan.visible=false;
    const pose=new THREE.Vector3();let tangent=new THREE.Vector3(0,0,1);
    if(token.route){
      const route=chooseRoute(token.route);
      if(route){const u=route.reverse?1-progress:progress;pose.copy(route.edge.curve.getPointAt(u));tangent.copy(route.edge.curve.getTangentAt(u)).multiplyScalar(route.reverse?-1:1);}
      else{activeTicket.object.visible=false;console.warn(`Conexión Portal no definida: ${token.route.join(' → ')}`);}
    }else if(token.node&&nodes.has(token.node)){
      pose.copy(nodes.get(token.node).dock);
      if(work.has(token.node)&&workPaths.has(token.node)){
        const amount=smooth(localTime/.68)*(1-smooth((localTime-2.57)/.43));pose.copy(workPaths.get(token.node).getPointAt(amount));
        scan.visible=localTime>=1.35&&localTime<=2.03;scan.position.copy(pose).add(new THREE.Vector3(0,.04,.28-.56*clamp((localTime-1.35)/.68)));
      }
      if(token.node==='entry'&&state.gate?.mode==='pass'){
        const inward=state.gate.direction!=='out',front=nodes.get('entry').dock,back=localPoint('entry',[0,1.05,-1.4]);
        pose.copy(inward?front:back).lerp(inward?back:front,smooth((clamp(state.gate.progress)-.22)/.56));
      }
      if(token.node==='sql'&&persistence){
        const dock=nodes.get('sql').dock;
        if(persistence.mode==='storing'||persistence.mode==='linking'){
          pose.copy(dock).lerp(persistence.mode==='linking'?metadataInside:sqlInside,smooth((databaseProgress-.22)/.46));
        }else if(persistence.mode==='receipt'){
          pose.copy(sqlAckOrigin).lerp(dock,smooth((databaseProgress-.22)/.46));
        }else if(persistence.mode==='status'){
          const amount=smooth((databaseProgress-.2)/.25)*(1-smooth((databaseProgress-.56)/.23));pose.copy(dock).lerp(sqlAckOrigin,amount);
        }
      }
      if(token.node==='blob'&&storage){
        if(storage.mode==='storing')pose.copy(blobTravel(smooth((storageProgress-.12)/.65)));
        if(storage.mode==='receipt')pose.copy(blobTravel(1-smooth((storageProgress-.12)/.62),blobAckOrigin));
        if(storage.mode==='reading'){
          if(storageProgress<.44)pose.copy(blobTravel(smooth(storageProgress/.34),blobAckOrigin));
          else pose.copy(blobTravel(1-smooth((storageProgress-.5)/.42),blobAckOrigin));
        }
      }
    }
    activeTicket.object.position.copy(pose);
    const turn=token.route?smooth(progress/.13)*(1-smooth((progress-.87)/.13)):0;
    activeTicket.object.rotation.y=turn*Math.atan2(tangent.x,tangent.z);
    const kind=returningCopy?'file':token.kind;
    activeTicket.material.color.set(state.uncertain?COLORS.unknown:(COLORS[kind]||COLORS.request));
    const text=returningCopy?'Copia · ADJ-042':String(token.label||token.id||'P-042');activeTicket.label.userData.setText(text);
    unknownRing.visible=Boolean(state.uncertain)&&activeTicket.object.visible;unknownRing.position.copy(pose).add(new THREE.Vector3(0,-.052,0));
    savedRecord.object.visible=Boolean(state.saved)&&!isPreparation&&!isAttachment;
    savedRecord.material.color.set(state.uncertain?COLORS.unknown:COLORS.order);
    actualRecord=isPreparation?ticket:isAttachment?receiptTicket:savedRecord;
    savedBadge.visible=Boolean(isAttachment?state.attachmentLinked:state.saved);
    savedBadge.userData.setText(isAttachment?'FICHA DEL ADJUNTO':state.uncertain?'CONFIRMACIÓN PENDIENTE':'BORRADOR GUARDADO');
    storageBadge.visible=fileDeposited;
    const onQueueApproach=token.route?.[0]==='backend'&&token.route?.[1]==='queue',onQueueTransfer=token.route?.[0]==='queue'&&token.route?.[1]==='worker';
    const afterQueue=['En proceso','Confirmación pendiente','Recibido por el sistema de pedidos'].includes(state.ledger?.submission),approachLength=edges.get('backend-queue').length,transferLength=edges.get('queue-worker').length;
    beltTravel=onQueueApproach?progress*approachLength:onQueueTransfer?approachLength+progress*transferLength:token.node==='queue'?approachLength:afterQueue?approachLength+transferLength:0;
    belts.forEach(belt=>belt.update(beltTravel));nodes.get('queue').asset.object.userData.model.userData.rollers.forEach(roller=>{roller.rotation.x=beltTravel/(.085*nodes.get('queue').asset.object.scale.x);});
    ticketPose={visible:activeTicket.object.visible,id:token.id||null,kind:kind||null,node:token.node||null,route:token.route?[...token.route]:null,progress,position:pose.toArray(),color:activeTicket.material.color.getHexString(),label:text};
    if(fullFactory){
      factoryOverlay.update(state.extension);
      const key=`factory:${state.scenario}:${state.phaseIndex}:${factoryOverlay.inspect().stage||''}`;
      if(mode==='guided'&&focusKey!==key){focusKey=key;viewer.focus(factoryOverlayBounds(),{padding:1.12});}
    }else if(mode==='guided')follow(guidedFocus(state));
    return inspect();
  }
  function projectPoint(point){
    const p=point.clone().project(viewer.camera);
    return {x:(p.x*.5+.5)*stage.clientWidth,y:(-p.y*.5+.5)*stage.clientHeight,depth:p.z};
  }
  function screenBounds(bounds){
    const points=[];
    for(const x of [bounds.min.x,bounds.max.x])for(const y of [bounds.min.y,bounds.max.y])for(const z of [bounds.min.z,bounds.max.z])points.push(projectPoint(new THREE.Vector3(x,y,z)));
    const x=Math.min(...points.map(p=>p.x)),y=Math.min(...points.map(p=>p.y));
    return {x,y,w:Math.max(...points.map(p=>p.x))-x,h:Math.max(...points.map(p=>p.y))-y};
  }
  function layoutLabels(){
    const width=stage.clientWidth,height=stage.clientHeight,occupied=[];
    const active=new Set(snapshot?.active||[]);
    const relevant=new Set(snapshot?.token?.route||[snapshot?.token?.node]);
    if(snapshot?.extension)for(const id of factoryOverlay.getFocusIds?.()||[])relevant.add(id);
    if(snapshot?.scenario==='attachments')for(const id of ['backend','sql','blob'])relevant.add(id);
    const ordered=[...nodes.values()].sort((a,b)=>(b.spec.id===selected?10:active.has(b.spec.id)?5:relevant.has(b.spec.id)?3:0)-(a.spec.id===selected?10:active.has(a.spec.id)?5:relevant.has(a.spec.id)?3:0));
    viewer.camera.updateMatrixWorld(true);
    const machines=[...nodes.values()].map(n=>screenBounds(n.bounds));
    const obstacles=machines.filter(r=>r.x+r.w>0&&r.x<width&&r.y+r.h>0&&r.y<height);
    if(factoryOverlay.object.visible){
      const overlay=factoryOverlay.inspect();
      const actors=snapshot.scenario==='pentest'?[overlay.tester]:[overlay.human,overlay.robot];
      for(const actor of actors)if(actor?.position){const p=V(actor.position);obstacles.push(screenBounds(new THREE.Box3(p.clone().add(new THREE.Vector3(-.75,0,-.65)),p.clone().add(new THREE.Vector3(.75,2.45,.65)))));}
      if(snapshot.scenario==='pentest'&&overlay.tester?.desk){const p=V(overlay.tester.desk).add(new THREE.Vector3(1.39,0,0));obstacles.push(screenBounds(new THREE.Box3(p.clone().add(new THREE.Vector3(-.8,0,-.65)),p.clone().add(new THREE.Vector3(.8,2,.65)))));}
    }
    if(ticketPose.visible&&!snapshot?.extension){const p=projectPoint(V(ticketPose.position));obstacles.push({x:p.x-20,y:p.y-14,w:40,h:28});}
    const overlapArea=(a,b)=>Math.max(0,Math.min(a.x+a.w,b.x+b.w)-Math.max(a.x,b.x))*Math.max(0,Math.min(a.y+a.h,b.y+b.h)-Math.max(a.y,b.y));
    for(const n of ordered){
      const p=projectPoint(n.top),q=projectPoint(new THREE.Vector3(n.spec.position[0],Math.min(1.7,n.bounds.max.y),n.spec.position[2]));
      const allowed=selected?n.spec.id===selected:mode==='overview'||relevant.has(n.spec.id)||(!snapshot?.extension&&active.has(n.spec.id));
      const visible=allowed&&p.depth>-1&&p.depth<1&&p.x>-40&&p.x<width+40&&q.y>0&&q.y<height;
      n.button.hidden=!visible;n.leader.style.display=visible?'':'none';if(!visible)continue;
      n.button.style.maxWidth=width<600?'150px':'180px';
      const w=n.button.offsetWidth||150,h=n.button.offsetHeight||34,rect=screenBounds(n.bounds);
      const candidates=[];
      const add=(x,y)=>candidates.push({x:Math.max(10,Math.min(width-w-10,x)),y:Math.max(12,Math.min(height-h-40,y)),w,h});
      add(p.x-w/2,rect.y-h-12);
      add(rect.x+rect.w+14,rect.y-4);
      add(rect.x-w-14,rect.y-4);
      add(p.x-w/2,rect.y+rect.h+12);
      for(const y of [14,height-h-44])for(const dx of [0,-w-12,w+12,-2*w-24,2*w+24])add(p.x-w/2+dx,y);
      for(const candidate of candidates){
        candidate.cost=occupied.reduce((sum,r)=>sum+overlapArea(candidate,{x:r.x-7,y:r.y-7,w:r.w+14,h:r.h+14})*100,0)+obstacles.reduce((sum,r)=>sum+overlapArea(candidate,{x:r.x-5,y:r.y-5,w:r.w+10,h:r.h+10})*10,0)+Math.hypot(candidate.x+w/2-p.x,candidate.y+h/2-p.y);
      }
      candidates.sort((a,b)=>a.cost-b.cost);const best=candidates[0];
      if(occupied.some(r=>overlapArea(best,{x:r.x-5,y:r.y-5,w:r.w+10,h:r.h+10})>0)&&n.spec.id!==selected){n.button.hidden=true;n.leader.style.display='none';continue;}
      const {x,y}=best;n.button.style.left=`${x}px`;n.button.style.top=`${y}px`;n.button.style.opacity='1';occupied.push(best);
      const anchorX=Math.max(x+8,Math.min(x+w-8,q.x)),anchorY=q.y>y+h?y+h:q.y<y?y:Math.max(y+6,Math.min(y+h-6,q.y));
      n.leader.setAttribute('x1',String(anchorX));n.leader.setAttribute('y1',String(anchorY));n.leader.setAttribute('x2',String(q.x));n.leader.setAttribute('y2',String(q.y));n.leader.setAttribute('opacity','.32');
    }
  }
  function render(){if(disposed)return;viewer.render();layoutLabels();}
  function reset(ids){selected=null;mode='guided';focusKey='';if(['pentest','agents'].includes(snapshot?.scenario))viewer.focus(factoryOverlayBounds(),{padding:1.12});else if(snapshot?.extension)viewer.focus(extensionBounds(),{padding:1.12});else if(snapshot?.scenario==='capacity')viewer.focus(capacityDemo.bounds.clone().expandByScalar(1.1));else follow(guidedFocus(snapshot,ids)||[...nodes.keys()]);render();}
  function overview(){selected=null;mode='overview';focusKey='';viewer.focus(['pentest','agents'].includes(snapshot?.scenario)?factoryOverlayBounds(true):snapshot?.extension?extensionBounds(true):snapshot?.scenario==='capacity'?capacityDemo.bounds.clone().expandByScalar(1.1):boxFor([...nodes.keys()]),{padding:snapshot?.extension?1.05:1.22});render();}
  function select(id){if(snapshot?.scenario==='knowledge'){selected=id;render();return;}if(snapshot?.scenario==='capacity'){selected=id==='backend'?'backend':null;mode='selected';viewer.focus(capacityDemo.bounds.clone().expandByScalar(1.1));render();return;}if(!nodes.has(id)){if(selected)reset();return;}selected=id;mode='selected';focusKey='';viewer.focus(boxFor([id]));render();}
  function inspect(){
    const attachment=snapshot?.scenario==='attachments',recordVisible=attachment?Boolean(snapshot?.attachmentLinked):Boolean(snapshot?.saved);
    return {
      mode,selected,scenario:snapshot?.scenario||null,time:snapshot?.time||0,cameraShot:cameraShots.get(snapshot?.scenario)?.[snapshot?.phaseIndex]?.name||focusKey,
      gateOpen,sqlOpen,gateDirection:snapshot?.gate?.direction||null,
      token:{...ticketPose,visible:snapshot?.scenario==='capacity'||snapshot?.extension?false:ticketPose.visible,uuid:activeTicket.object.uuid,position:[...ticketPose.position],screen:projectPoint(V(ticketPose.position))},
      savedRecord:{visible:recordVisible,objectVisible:actualRecord.object.visible,uuid:actualRecord.object.uuid,color:actualRecord.material.color.getHexString(),position:actualRecord.object.position.toArray()},
      storagePiece:{visible:attachment&&Boolean(snapshot?.attachmentSaved),storing:attachment&&snapshot?.storage?.mode==='storing',uuid:ticket.object.uuid,position:ticket.object.position.toArray(),shelf:blobShelf.toArray(),liftVisible:false,readingCopyVisible:readCopy.object.visible,readingCopyUuid:readCopy.object.uuid,originalStyle:'Hoja PDF azul',referenceStyle:'Ficha púrpura',copyStyle:'PDF · COPIA con doble borde'},
      queueTransport:{travel:beltTravel,rollerAngle:nodes.get('queue').asset.object.userData.model.userData.rollers[0]?.rotation.x||0},
      gatePassage:{front:nodes.get('entry').dock.toArray(),back:localPoint('entry',[0,1.05,-1.4]).toArray(),clearWidth:1.04*1.18},
      persistence:{mode:snapshot?.persistence?.mode||null,progress:clamp(snapshot?.persistence?.progress),inside:sqlInside.toArray(),metadataInside:metadataInside.toArray(),receiptOrigin:sqlAckOrigin.toArray()},
      mainVisible:object.visible,capacityVisible:capacityDemo.object.visible,capacity:snapshot?.scenario==='capacity'?capacityDemo.inspect():null,
      extensionVisible:extensionDemo.object.visible,extension:snapshot?.scenario==='knowledge'?extensionDemo.inspect():null,
      factoryOverlay:factoryOverlay.object.visible?factoryOverlay.inspect():null,
      clientOperator:{position:nodes.get('client').asset.object.userData.model.userData.human.position.toArray(),rotation:nodes.get('client').asset.object.userData.model.userData.human.rotation.toArray(),visible:nodes.get('client').asset.object.userData.model.userData.human.visible},
      assistant:{visible:assistant.object.visible&&object.visible,mode:snapshot?.assistant?.mode||null,suggestionVisible:suggestion.object.visible&&object.visible,orderModified:false,pose:assistant.inspect(),suggestionPosition:suggestion.object.position.toArray(),chestBrand:assistant.inspect().chestBrand,chestBrandRendering:assistant.inspect().chestBrandRendering},
      brandAssets:{...brandAssets},brandRendering:brandMarks.inspect(),
      nodes:[...nodes].map(([id,n])=>({id,asset:n.spec.asset,position:n.asset.object.position.toArray(),dock:n.dock.toArray(),working:Boolean(n.asset.object.userData.model.userData.stamping),internalDocumentVisible:Boolean(n.asset.object.userData.model.userData.document?.visible)})),
      edges:[...edges.values()].map(e=>({id:e.key,from:e.spec.from,to:e.spec.to,length:e.length})),viewer:viewer.inspect(),
    };
  }
  const raycaster=new THREE.Raycaster(),pointer=new THREE.Vector2();
  const down=e=>{pointerStart=e.button===0?{x:e.clientX,y:e.clientY}:null;};
  const upEvent=e=>{
    if(e.button!==0||!pointerStart||Math.hypot(e.clientX-pointerStart.x,e.clientY-pointerStart.y)>6){pointerStart=null;return;}pointerStart=null;
    const rect=viewer.renderer.domElement.getBoundingClientRect();pointer.set((e.clientX-rect.left)/rect.width*2-1,-(e.clientY-rect.top)/rect.height*2+1);raycaster.setFromCamera(pointer,viewer.camera);
    if(snapshot?.scenario==='knowledge')return;
    if(snapshot?.scenario==='capacity'){
      if(raycaster.intersectObject(capacityDemo.object,true).length){select('backend');onSelect('backend');}return;
    }
    const intersections=raycaster.intersectObjects([...assets.values()].map(a=>a.object),true);
    for(const hit of intersections){let node=hit.object;while(node&&!node.userData.nodeId)node=node.parent;if(node?.userData.nodeId){select(node.userData.nodeId);onSelect(node.userData.nodeId);break;}}
  };
  viewer.renderer.domElement.addEventListener('pointerdown',down);viewer.renderer.domElement.addEventListener('pointerup',upEvent);
  viewer.mount({object});viewer.focus(boxFor([...nodes.keys()]),{immediate:true});
  const observer=new ResizeObserver(()=>layoutLabels());observer.observe(stage);
  function dispose(){
    if(disposed)return;disposed=true;observer.disconnect();viewer.renderer.domElement.removeEventListener('pointerdown',down);viewer.renderer.domElement.removeEventListener('pointerup',upEvent);
    factoryOverlay.dispose();assistant.dispose();extensionDemo.dispose();capacityDemo.dispose();brandMarks.dispose();for(const asset of assets.values())asset.dispose();belts.forEach(b=>b.dispose());decor.dispose();for(const geometry of geometries)geometry.dispose();for(const mat of materials)mat.dispose();labels.remove();object.removeFromParent();object.clear();viewer.dispose();
  }
  render();return {update,render,reset,overview,select,inspect,dispose,setClock:viewer.setClock};
}
