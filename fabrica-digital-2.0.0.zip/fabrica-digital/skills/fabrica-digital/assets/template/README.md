# Tu fábrica digital

Esta es una base editable, sin marca de cliente. Incluye un portal ficticio como ejemplo de relato. Cambia las responsabilidades, las conexiones y los recorridos para representar la arquitectura que quieres explicar.

## Abrir

Necesitas Node.js 22+ y pnpm. Desde este directorio:

```sh
node scripts/factory.mjs dev
```

Abre la URL que imprime. El comando prepara una copia de ejecución fuera del proyecto, de modo que puedes conservar estas fuentes en una carpeta sincronizada. Reinícialo después de editar. No modifiques la copia temporal.

## Adaptar

1. Recoge el contexto con `docs/new-project-brief.md` y prepara un guion breve.
2. Edita `src/project.js`: título, empresa, logo opcional, paleta y recorridos visibles.
3. Adapta `src/architecture.js` para las responsabilidades y conexiones. Revisa el guion de `src/story.js` y las escenas que lo representan.
4. Consulta `docs/reuse-guide.md` para reutilizar cámara, pasos, marcas, personajes y animaciones sin reconstruirlos.
5. Comprueba el resultado, incluida una pantalla panorámica, antes de enseñarlo.

El logo de empresa, si existe, se guarda en `public/brand/` y se referencia desde la configuración. Mantén fuera de `public/` los documentos de contexto y las notas privadas.

`catalog.html` muestra las 17 piezas del kit. `connections.html` permite observar recorridos curvos y conexiones. `custom-asset.html` demuestra cómo añadir una pieza articulada.

## Comprobar y entregar

```sh
node scripts/factory.mjs check
node scripts/factory.mjs build
node scripts/factory.mjs preview
node scripts/factory.mjs render consultation
node scripts/factory.mjs render consultation 4k
```

Las rutas de salida se imprimen en cada comando. `FACTORY_CACHE_DIR` permite elegir una caché local y `FACTORY_PORT` otro puerto. El vídeo requiere FFmpeg. Las fuentes, las dependencias y la web compilada son entregables distintos. Para insertar la fábrica en una web existente, consulta `docs/embedding.md`.

La simulación no aprovisiona infraestructura ni prueba que los controles representados estén implantados. Conserva los avisos de terceros de `public/licenses/` y `docs/asset-sources.md`.
