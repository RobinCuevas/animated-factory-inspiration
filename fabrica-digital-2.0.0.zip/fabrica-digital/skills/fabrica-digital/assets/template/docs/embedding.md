# Insertar la fábrica en una web

Construye con `node scripts/factory.mjs build` y sirve la carpeta estática bajo una ruta de la web, por ejemplo `/fabrica/`. La compilación usa rutas relativas. El iframe puede cargar `/fabrica/?embed=1`.

Hay un ejemplo funcional en `examples/embed/index.html`. Mantiene una sección "Plataforma" y coloca la fábrica donde iría el diagrama. Se incluye en la compilación.

`shared/embed-host.js` resuelve el lado de la web que contiene el iframe. Coloca el iframe como hijo directo del contenedor y deja el botón dentro del mismo contenedor. Después importa el helper en el código de la web:

```js
import { mountFactoryFrame } from './shared/embed-host.js';

const factory = mountFactoryFrame({
  iframe: document.querySelector('#factory-content'),
  expandButton: document.querySelector('#expand-factory'),
  container: document.querySelector('#factory-frame'),
});

// Al desmontar esta parte de una aplicación:
// factory.dispose();
```

El helper aplica alturas entre 120 y 12000 píxeles, comprueba el origen y la ventana emisora, comunica la visibilidad y pausa la fábrica al ocultar la pestaña o sacarla de pantalla. La ampliación usa CSS fijo, conserva el iframe y su paso, admite Escape y devuelve el foco al botón. También ofrece `expand()`, `collapse()` e `isExpanded()`.

Ese modo conserva el recorrido y elimina la cabecera de la fábrica para aprovechar la identidad de la web que la contiene. Los servicios relacionados se recogen en un desplegable. La altura de la escena depende de su ancho, no de la altura del iframe, para evitar un bucle de redimensionado.

El protocolo de `src/embed.js` utiliza mensajes del mismo origen:

| Mensaje | Sentido | Uso |
| --- | --- | --- |
| `factory:resize` con `height` | Fábrica → web | Actualizar la altura del iframe sin barras internas innecesarias. |
| `factory:visibility` con `visible` | Web → fábrica | Pausar al salir de pantalla y evitar renderizado que no se ve. |
| `factory:exit-expanded` | Fábrica → web | Salir de una ampliación al pulsar Escape. |

El helper comprueba `event.origin === location.origin` y `event.source === iframe.contentWindow`. La fábrica hace la comprobación equivalente. Este contrato no admite un iframe de otro origen ni abrir los archivos directamente con `file://`.

Si adaptas la ampliación, conserva el iframe en su lugar. Evita ancestros con `transform` o recorte que impidan al contenedor fijo ocupar la ventana. Conserva la sección original de la web y sustituye su diagrama cuando esa sea la intención, en lugar de duplicar contenidos.

El despliegue necesita la autorización y el destino del encargo. Una compilación local no demuestra que la web se haya publicado ni que sus permisos sean correctos.
