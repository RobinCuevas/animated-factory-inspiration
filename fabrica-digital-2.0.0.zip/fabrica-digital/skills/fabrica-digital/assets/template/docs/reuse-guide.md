# Reutilizar la fábrica sin repetir el trabajo

## Dos puntos de partida

`src/project.js` configura identidad y presentación. `PROJECT.recipe = 'commerce'` utiliza el portal ficticio completo, con una coreografía preparada para sus papeles (cliente, entrada, API, backend, almacenes y sistemas externos). Es útil para adaptar un caso parecido. Sus identificadores participan en movimientos y planos: no basta con eliminarlos o renombrarlos en un único archivo.

`PROJECT.recipe = 'custom'` utiliza `examples/custom-architecture/model.js` para una arquitectura con identificadores propios. Edita sus nodos, conexiones y pasos. Conserva la interfaz, el reproductor y la cámara. Esta receta representa el flujo básico de documentos entre piezas. Las operaciones físicas particulares de una máquina se añaden cuando el relato las necesita, no se deducen automáticamente de su nombre.

La receta custom exporta `CUSTOM` con `nodes`, `edges` y `scenarios`. Cada paso declara `duration` (segundos del guion), `title`, `copy`, `from` y `to`. Usa el mismo nodo en `from` y `to` para trabajo local. El `to` de un paso debe coincidir con el `from` del siguiente. `work` puede señalar máquinas activas e `insight` aporta pares de etiqueta y valor al panel. `focusEntry` es el índice del primer paso útil al encadenar secciones. Los nodos tienen un identificador, una pieza `asset`, posición, ámbito, servicio y ficha. Consulta el archivo del ejemplo para los campos completos y sus conexiones.

`PROJECT.sections` selecciona y ordena los recorridos del ejemplo commerce. En custom, `PROJECT.customSections` puede seleccionar y ordenar sus identificadores. Si se omite, se muestran todos los recorridos del modelo.

En ambos casos el guion manda sobre la biblioteca. Un backend modular puede ser una máquina. No hace falta una máquina por función ni todos los servicios del ejemplo.

## Marca y servicios

La configuración agrupa título, subtítulo, cliente, paleta, estado del diseño, recorridos y preferencias de reproducción. `customer.logo` admite una ruta local de la web, por ejemplo `./brand/empresa.svg`. `null` deja la escena sin logo de cliente. Los colores de fábrica se ajustan en `palette`. Los colores de logos de terceros se conservan.

`shared/brand-marks.js` coloca marcas sobre techos, carcasas y otras superficies. Define un rectángulo disponible: el helper calcula el tamaño manteniendo la proporción. Usa SVG cuando exista una fuente válida. El navegador lo decodifica a una textura de alta resolución (habitualmente 2048 px para máquinas, mayor para un logo grande de suelo). El uso de SVG por sí solo no elimina los límites de resolución del canvas.

Evita cambiar el tamaño del padre de un logo de forma distinta en cada eje. Comprueba la marca de cerca y en la vista general. Si solo conoces las siglas de un sistema, imprime las siglas. No inventes un proveedor por semejanza visual.

## Cámara, pantallas y rótulos

`shared/viewer.js` mantiene un ángulo fijo. Los botones izquierdo, central o derecho desplazan la escena. La rueda acerca y aleja. El movimiento automático agrupa pasos relacionados en planos, en lugar de saltar de máquina con cada frase.

El cambio de plano dura alrededor de 1,1 segundos reales, con entrada y salida suaves. Esta duración es independiente del relato a 2×. Al calcular el plano incluye la curva completa por la que viaja el objeto, no solo las posiciones de las máquinas. Comprueba especialmente los tramos largos de retorno con la ventana panorámica.

Los rótulos necesitan posiciones deliberadas, líneas de asociación y prioridades. Reduce su presencia durante planos de detalle y reserva el espacio del objeto activo. La evitación de colisiones es una ayuda: confirma visualmente los planos clave, también con zoom manual. No conviertas todos los iconos en carteles flotantes.

La resolución sigue `devicePixelRatio` y los cambios de zoom o pantalla, incluso cuando no se dispara un redimensionado. Usa el tamaño CSS real del canvas y un límite de unos 8,4 millones de píxeles (`rendering.maxPixels`) para evitar una asignación ilimitada. No fuerces siempre DPR 1 ni una densidad fija menor que la de Chrome. Tampoco escales el canvas con una transformación CSS para encajarlo en la página.

## Pasos y ritmo

La reproducción normal usa 2×. El ejemplo de seguridad usa 1× para que se entiendan entrada, prueba y resultado. Son valores iniciales, no una obligación para todos los relatos. Ajusta primero lo que tarda cada acción antes de añadir controles de velocidad.

- Reproducir continúa el recorrido actual.
- Anterior y Siguiente reproducen el paso elegido desde su comienzo y pausan al terminar, dejando tiempo para leer.
- El clic directo en una sección comienza su recorrido completo.
- Siguiente desde el último paso entra en el punto útil de la próxima sección, evitando la introducción repetida cuando corresponde. Una breve transición desde blanco señala el cambio de momento.
- El contador del reproductor ayuda a orientarse. La explicación no necesita repetir un número y "en este paso" encima del título.

Un traslado sencillo suele requerir entre 0,6 y 1,5 segundos percibidos. Una transformación que se quiera observar puede necesitar de 1 a 2 segundos. La pausa para leer pertenece al modo por pasos, no a una cinta o puerta inmóvil durante varios segundos. Estos son puntos de partida: manda la legibilidad del gesto y del recorrido.

Cada estado debe poder calcularse a partir del tiempo del relato. Evita acumular cambios incrementales sin restablecerlos: al mover la barra hacia atrás no pueden quedar mesas, documentos o efectos del futuro.

## Documentos y almacenamiento

Mantén un único objeto durante el traslado de una operación. Si el modelo contiene una bandeja o documento de demostración, comprueba que no duplique al objeto animado. Haz que la mano o la máquina alcance el documento de verdad.

En un almacén distingue el archivo conservado, la ficha de base de datos y la copia de lectura. Para búsqueda puedes mostrar varios documentos recuperados y devueltos, con una identidad estable para cada copia. Cierra el recorrido devolviendo una respuesta al usuario.

En una cola basta con que se vea quién conserva el trabajo y quién lo recoge. No añadas una pausa larga si la espera no es el concepto que estás explicando. Si una operación tarda y se pierde la respuesta, el resultado puede ser desconocido: no representes un reenvío seguro sin una comprobación que lo justifique.

En capacidad empieza con el puesto que existe, deja que se acumule trabajo y después añade puestos y máquinas. Distribuye los documentos cuando los nuevos puestos están disponibles. Los datos no se duplican porque haya más cómputo.

## Personajes, IA y seguridad

El robot asistente pertenece al espacio físico: pies en el suelo, cuerpo fuera de la mesa y brazo en contacto con el papel. Puede llevar el icono del servicio que representa en el pecho. Un agente externo usa una identidad visual neutral. El relevo de la silla entre una persona y un robot hace visible el cambio de actor usando la misma fábrica.

La IA propone o redacta sobre fuentes con permisos. El relato debe dejar claro quién decide y qué respuesta recibe el cliente. Un ejemplo de futuro acceso de agentes puede conservarse como propuesta independiente, sin presentar envíos autónomos como acordados.

El evaluador de sombrero blanco llega con un paseo breve y después trabaja. Coloca el escudo orientado hacia los impactos y calcula los puntos de contacto en su superficie. Los paquetes desaparecen o se desintegran al tocarla. Un ataque masivo puede ser intenso y corto, con instancias reutilizadas y un presupuesto acotado de efectos. No lo alargues para que parezca más potente.

Los personajes se importan desde `shared/characters.js`:

```js
import { createAIRobot, createWhiteHatTester } from '../shared/characters.js';

const assistant = createAIRobot({ brand: 'azure-openai' });
const visitor = createAIRobot(); // Robot neutral, sin marca de proveedor.
const tester = createWhiteHatTester({ scale: 1.48 });
```

Ambos helpers devuelven `{ object, update, inspect, dispose }`. Añade `object` a la escena y sitúalo sobre el suelo. El robot mira hacia su eje local +Z. `createAIRobot({ brand, palette })` acepta `null`, `azure-openai` o una ruta de imagen autorizada como marca. Su firma de animación es `update(time, { working, progress, workTarget, contact })`. `progress` y `contact` van de 0 a 1. `workTarget`, si se usa, expresa `[y, z]` en el espacio local del robot para que el puntero alcance la mesa.

`createWhiteHatTester({ scale, palette })` devuelve el personaje con sombrero. `update(time, { walking })` calcula la pose. La escena decide su posición y el trayecto, lo que permite una llegada breve y reproducible. No clones un `object` articulado: crea otra instancia. Al retirar una escena llama a `dispose()` para liberar sus recursos.

Las escenas y overlays de `src/` muestran cómo conectarlos al relato, incluido el escudo y el relevo de la silla. Una ilustración de pruebas externas y de permisos desde dentro no certifica seguridad ni ausencia de vulnerabilidades.

## Paneles y lectura

La explicación principal va a la derecha en escritorio. El detalle técnico es secundario y, al abrirse, usa un área acotada para no crear un gran hueco debajo de la escena. Los servicios relacionados viven debajo de esta. En pantallas pequeñas, la disposición cambia manteniendo la lectura.

Los logos dentro del texto se alinean con la línea y permanecen unidos a la primera palabra del servicio. El resto del nombre puede saltar de línea. Evita un bloque de ancho fijo dentro de un párrafo. Los iconos de las fichas y del mapa necesitan espacio propio y texto legible.

El mapa lógico tiene desplazamiento, zoom y ajuste general. El plano de red explica otras cosas: no confundas una conexión lógica entre servicios con una red privada ya desplegada.

## Revisar y entregar

Comprueba los momentos de contacto, almacenamiento y retorno. Reproduce y recorre hacia atrás. Abre al menos una vista panorámica y una estrecha. Verifica un cambio de zoom o densidad de pantalla si se ha tocado el renderizador. Revisa los pasos completos y el salto entre secciones.

El texto público debe explicar la solución. El guion interno puede registrar fuentes, alternativas y dudas de preparación. No copies esas deliberaciones al panel principal. Mantén documentos privados fuera de `public/` y entrega únicamente la compilación y los recursos autorizados.
