# Contexto para una nueva fábrica

Recoge lo disponible, sin bloquear una primera versión por decisiones de representación reversibles. Mantén las respuestas y las fuentes privadas fuera de `public/`.

| Dato | Qué hace falta |
| --- | --- |
| Audiencia y objetivo | Quién la verá y qué debe poder explicar al terminar. |
| Empresa y marca | Nombre visible, logo autorizado (preferiblemente SVG), colores y posibles límites de uso. Si faltan, empieza neutral. |
| Fuentes | Documentos de arquitectura, propuesta o diagrama. Indica su fecha y qué está aprobado, planteado o pendiente. |
| Responsabilidades | Qué servicio hace cada trabajo y qué sistemas están fuera del producto. |
| Datos | Qué entra, qué se transforma, dónde se conserva y quién puede verlo. |
| Recorridos | Dos o tres acciones de negocio, más una demora o fallo si ayuda. |
| Esperas y errores | Qué significa pendiente, recibido, confirmado o desconocido. Qué se puede reintentar y con qué garantías. |
| Entrega | Web independiente, inserción en otra web, vídeo o fuentes editables. Pantallas y resolución de presentación. |

Antes de modelar, resume cada recorrido en una línea:

> Desencadenante → servicio que trabaja → dato o estado que cambia → siguiente responsable → respuesta al usuario.

Prepara una tabla privada de componentes: nombre, servicio real si se conoce, recibe, hace, entrega, guarda, evidencia y decisión pendiente. No conviertas la referencia del proveedor en una lista de nuevas instancias que haya que contratar.

Usa el ejemplo del portal para aprender la estructura. Para otro dominio, conserva las piezas visuales y los controles, y cambia el relato y las conexiones. No fuerces un portal de pedidos si el caso es un flujo documental, de soporte o de producción.
