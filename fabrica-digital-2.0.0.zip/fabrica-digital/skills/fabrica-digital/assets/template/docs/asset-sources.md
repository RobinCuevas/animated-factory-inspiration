# Recursos y marcas

La geometría de máquinas y personajes es procedural y editable en el proyecto. Este paquete no le asigna una licencia pública nueva. Conserva los permisos que correspondan a su distribución y a cualquier recurso que añadas.

Los iconos de Azure y Microsoft Entra se incluyen para identificar servicios. Sus fuentes oficiales y condiciones de uso son:

- [Iconos de arquitectura Azure](https://learn.microsoft.com/en-us/azure/architecture/icons/).
- [Iconos de arquitectura Microsoft Entra](https://learn.microsoft.com/en-us/entra/architecture/architecture-icons).

Conserva sus proporciones, nombres y colores. Una representación no implica patrocinio, aprobación ni provisión de los servicios. Consulta también `public/licenses/service-icons.md`.

La biblioteca Three.js y la fuente DM Sans conservan sus avisos en `public/licenses/Three-LICENSE.txt` y `public/licenses/DM-Sans-OFL.txt`.

Los recursos de cliente son opcionales y se añaden a la copia de ese proyecto cuando esté autorizado su uso. Prefiere la web oficial o un archivo proporcionado por la empresa. Conserva su procedencia en la documentación privada del proyecto. No copies informes internos completos al directorio público para obtener un logo.
