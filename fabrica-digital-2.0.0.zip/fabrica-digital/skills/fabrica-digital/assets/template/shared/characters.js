import * as THREE from 'three';
import { createAsset } from '../kit/index.js';
import { makeWorkshop } from './primitives.js';
import { createBrandMarks } from './brand-marks.js';
import { PROJECT } from '../src/project.js';

const clamp = value => THREE.MathUtils.clamp(Number.isFinite(value) ? value : 0, 0, 1);
const pulse = value => Math.sin(clamp(value) * Math.PI);

/** A small assistant. Its face and working hand point towards local +Z.
 * The motion is sampled, never accumulated, so scrubbing is reversible. */
export function createAIRobot({ brand = null, palette = PROJECT.palette } = {}) {
  const workshop = makeWorkshop({ palette });
  const object = new THREE.Group();
  object.name = 'Asistente IA · propone, la persona decide';
  object.add(workshop.root);
  const { palette: p, box, cylinder, rod, label } = workshop;
  const chestBrand = brand || null;
  const chestIcon = brand === 'azure-openai' ? './brand/azure-openai.svg' : brand;
  const chestBrandStatus = {};
  const chestMarks = chestBrand ? createBrandMarks({ status: chestBrandStatus }) : null;
  let disposed = false, sampled = { time: 0, working: false, progress: 0 };
  const add = (parent, item) => { parent.add(item); return item; };
  for (const x of [-.23, .23]) {
    box(.27, .15, .45, p.dark, [x, .1, .045], .055);
    cylinder(.085, .26, p.steel, [x, .29, 0]);
    box(.23, .3, .23, p.ivory, [x, .41, 0], .05);
  }
  const torso = box(.75, .72, .44, p.ivory, [0, .85, 0], .12);
  box(.57, chestBrand ? .53 : .43, .045, chestBrand ? p.white : p.teal, [0, .88, .235], .065);
  const badge = label('IA', [0, .91, .264], { width: .38, height: .23, color: '#fffaf0', background: null });
  badge.renderOrder = 2;
  badge.visible = !chestBrand;
  if (chestMarks) chestMarks.stamp(workshop.root, chestIcon, [0, .88, .264], [.46, .46], {
    nodeId: chestBrand, surface: 'pecho del robot', resolution: 2048,
  });
  cylinder(.11, .17, p.steel, [0, 1.26, 0]);
  const head = new THREE.Group(); head.position.set(0, 1.52, 0); workshop.root.add(head);
  add(head, box(.79, .48, .56, p.ivory, [0, 0, 0], .12));
  add(head, box(.65, .26, .042, p.dark, [0, .015, .288], .075));
  const eyes = [];
  for (const x of [-.16, .16]) eyes.push(add(head, box(.075, .105, .018, p.white, [x, .036, .314], .025)));
  add(head, rod([0, .25, 0], [0, .42, 0], .021, p.steel));
  add(head, cylinder(.067, .072, p.amber, [0, .435, 0]));
  for (const x of [-.435, .435]) {
    const ear = add(head, cylinder(.125, .09, p.teal, [x, 0, 0]));
    ear.rotation.z = Math.PI / 2;
  }
  const left = new THREE.Group(); left.position.set(-.49, 1.06, 0); workshop.root.add(left);
  add(left, box(.19, .39, .21, p.teal, [0, -.17, 0], .065));
  add(left, cylinder(.1, .18, p.steel, [0, -.39, .035]));
  add(left, box(.18, .2, .2, p.ivory, [0, -.52, .045], .04));
  const shoulder = new THREE.Group(); shoulder.position.set(.49, 1.06, 0); workshop.root.add(shoulder);
  const joint = add(shoulder, cylinder(.13, .19, p.steel)); joint.rotation.z = Math.PI / 2;
  add(shoulder, box(.2, .39, .2, p.teal, [0, -.19, 0], .06));
  const elbow = new THREE.Group(); elbow.position.set(0, -.37, 0); shoulder.add(elbow);
  const elbowJoint = add(elbow, cylinder(.115, .2, p.steel)); elbowJoint.rotation.z = Math.PI / 2;
  add(elbow, box(.17, .35, .17, p.ivory, [0, -.16, 0], .045));
  const hand = new THREE.Group(); hand.position.set(0, -.36, 0); elbow.add(hand);
  add(hand, box(.23, .11, .19, p.steel, [0, 0, 0], .025));
  for (const x of [-.085, .085]) add(hand, box(.047, .12, .15, p.dark, [x, -.085, .035], .015));
  const stylus = add(hand, rod([.07, -.04, .03], [.07, -.28, .03], .024, p.amber));
  stylus.name = 'Puntero de sugerencias';
  function update(time, { working = false, progress = 0, workTarget = null, contact = 1 } = {}) {
    if (disposed) return;
    sampled = { time: Number.isFinite(time) ? time : 0, working: Boolean(working), progress: clamp(progress) };
    const reach = sampled.working ? .66 + .34 * pulse(sampled.progress) : .08;
    shoulder.rotation.x = -1.02 * reach;
    shoulder.rotation.z = -.1 - .12 * reach;
    elbow.rotation.x = -1.06 * reach;
    hand.rotation.x = 0;
    // Optional tabletop pose. The default gesture remains unchanged elsewhere.
    // Keep the pointer vertical, so its tip meets a real surface rather than
    // waving through the desk or paper. Target coordinates are local Y and Z.
    if (workTarget && sampled.working) {
      const dy = workTarget[0] - shoulder.position.y, dz = workTarget[1];
      const upper = .37, lower = .36;
      const distance = Math.min(upper + lower - .0001, Math.hypot(dy, dz));
      const bend = Math.acos(THREE.MathUtils.clamp((distance * distance - upper * upper - lower * lower) / (2 * upper * lower), -1, 1));
      const angle = Math.atan2(-dz, -dy) + Math.atan2(lower * Math.sin(bend), upper + lower * Math.cos(bend));
      const amount = clamp(contact);
      shoulder.rotation.x = THREE.MathUtils.lerp(shoulder.rotation.x, angle, amount);
      shoulder.rotation.z *= 1 - amount;
      elbow.rotation.x = THREE.MathUtils.lerp(elbow.rotation.x, -bend, amount);
      hand.rotation.x = -(shoulder.rotation.x + elbow.rotation.x) * amount;
    }
    head.rotation.x = .14 * reach;
    head.rotation.y = sampled.working ? .055 * Math.sin(sampled.time * 2.3) : -.05;
    left.rotation.x = -.1; left.rotation.z = -.11;
    const blink = Math.cos(sampled.time * .82) > .994 ? .2 : 1;
    eyes.forEach(eye => { eye.scale.y = blink; });
    object.userData.working = sampled.working;
    object.updateMatrixWorld(true);
  }
  function inspect() {
    object.updateMatrixWorld(true);
    const bodyBounds = new THREE.Box3().setFromObject(torso);
    return { ...sampled, chestBrand, chestLabel: chestBrand ? null : 'IA', chestBrandStatus: { ...chestBrandStatus }, chestBrandRendering: chestMarks?.inspect() || null, bodyBounds: { min: bodyBounds.min.toArray(), max: bodyBounds.max.toArray() }, position: object.getWorldPosition(new THREE.Vector3()).toArray(), hand: hand.getWorldPosition(new THREE.Vector3()).toArray(), stylusTip: hand.localToWorld(new THREE.Vector3(.07, -.28, .03)).toArray(), shoulder: shoulder.rotation.x, elbow: elbow.rotation.x };
  }
  function dispose() { if (disposed) return; disposed = true; chestMarks?.dispose(); workshop.dispose(); object.removeFromParent(); object.clear(); }
  update(0);
  return { object, update, inspect, dispose };
}

/** White-hat tester with an owned hat, deterministic walking and disposal.
 * Position the returned object on the floor. update(time,{walking}) samples
 * the pose; the caller owns the route and whether the test is authorised. */
export function createWhiteHatTester({ scale = 1.48, palette = PROJECT.palette } = {}) {
  if (!Number.isFinite(scale) || scale <= 0) throw new RangeError('La escala del personaje debe ser positiva.');
  const actor = createAsset('human', { theme: { accent: 0xc4b89e, soft: 0xeee6d6, frame: 0x82745d }, bodyColor: 0xf0eadc, tool: 'clipboard' });
  const workshop = makeWorkshop({ palette });
  actor.object.name = 'Especialista en pruebas de seguridad';
  actor.object.scale.setScalar(scale);
  const hat = workshop.root;
  actor.object.add(hat); hat.position.set(0, 1.446, 0); hat.scale.setScalar(1 / scale);
  workshop.cylinder(.33, .045, workshop.palette.white);
  workshop.cylinder(.215, .2, workshop.palette.white, [0, .11, 0]);
  workshop.cylinder(.22, .055, workshop.palette.steel, [0, .04, 0]);
  let disposed = false, sampled = { time: 0, walking: false };
  return {
    object: actor.object,
    update(time, state = {}) { sampled = { time, walking: Boolean(state.walking) }; actor.update(time, { document: false, identified: true, ...state }); },
    inspect: () => ({ ...sampled, role: 'white-hat', illustrative: true, position: actor.object.getWorldPosition(new THREE.Vector3()).toArray() }),
    dispose() { if (disposed) return; disposed = true; workshop.dispose(); actor.dispose(); },
  };
}
