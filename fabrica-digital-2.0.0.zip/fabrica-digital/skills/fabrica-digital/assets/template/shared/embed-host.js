/** Host a same-origin factory without recreating its iframe or losing a step.
 * The child uses src/embed.js when opened with ?embed=1.
 * Returns { expand, collapse, isExpanded, dispose }. */
export function mountFactoryFrame({ iframe, expandButton, container }) {
  if (!iframe || iframe.tagName !== 'IFRAME' || !expandButton || !container) {
    throw new TypeError('Indica el iframe, su botón de ampliar y el contenedor.');
  }
  if (!container.contains(iframe) || !container.contains(expandButton)) {
    throw new TypeError('El iframe y el botón deben pertenecer al contenedor.');
  }
  const document = container.ownerDocument, window = document.defaultView;
  const origin = window.location.origin;
  if (origin === 'null' || new URL(iframe.src, document.baseURI).origin !== origin) {
    throw new Error('La fábrica y su web deben servirse desde el mismo origen.');
  }
  const saved = {
    height: iframe.style.height, button: expandButton.textContent,
    expanded: expandButton.getAttribute('aria-expanded'),
    role: container.getAttribute('role'), modal: container.getAttribute('aria-modal'),
    label: container.getAttribute('aria-label'),
    containerClass: container.classList.contains('factory-frame-host'),
    iframeClass: iframe.classList.contains('factory-frame-content'),
  };
  const style = document.createElement('style');
  style.textContent = `
    .factory-frame-host[data-factory-expanded="true"] {
      position: fixed !important; inset: 0 !important; z-index: 10000 !important;
      display: flex !important; flex-direction: column !important;
      width: 100vw !important; height: 100dvh !important; max-width: none !important;
      max-height: none !important; margin: 0 !important; border-radius: 0 !important;
      background: #f4f5f2; overflow: hidden !important;
    }
    .factory-frame-host[data-factory-expanded="true"] > .factory-frame-content {
      display: block; flex: 1 1 0 !important; width: 100% !important;
      height: 0 !important; min-height: 0 !important; border: 0;
    }
    .factory-frame-host[data-factory-expanded="true"] > :not(.factory-frame-content) {
      flex-shrink: 0;
    }
  `;
  document.head.append(style);
  container.classList.add('factory-frame-host');
  iframe.classList.add('factory-frame-content');
  expandButton.setAttribute('aria-expanded', 'false');
  let expanded = false, disposed = false, intersecting = false, lastVisible = null;
  let bodyOverflow = '', inertElements = [];

  function postVisible(force = false) {
    if (disposed) return;
    const visible = document.visibilityState !== 'hidden' && (expanded || intersecting);
    if (!force && visible === lastVisible) return;
    lastVisible = visible;
    iframe.contentWindow?.postMessage({ type: 'factory:visibility', visible }, origin);
  }
  function applyHeight(height) {
    if (typeof height !== 'number' || !Number.isFinite(height) || height < 120 || height > 12000) return;
    iframe.style.height = `${Math.ceil(height)}px`;
  }
  function measureVisibility() {
    const bounds = iframe.getBoundingClientRect();
    intersecting = bounds.width > 0 && bounds.height > 0 && bounds.bottom > 0 && bounds.right > 0
      && bounds.top < window.innerHeight && bounds.left < window.innerWidth;
    postVisible();
  }
  function onLoad() {
    // The child's first ResizeObserver message can precede this helper. Read
    // its existing layout once, without injecting code or resetting its state.
    try { applyHeight(iframe.contentDocument?.querySelector('main')?.getBoundingClientRect().height); } catch { /* A navigation may leave this origin. */ }
    measureVisibility(); postVisible(true);
  }
  function restoreAttribute(element, name, value) {
    if (value === null) element.removeAttribute(name); else element.setAttribute(name, value);
  }
  function expand() {
    if (disposed || expanded) return;
    expanded = true; bodyOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    container.dataset.factoryExpanded = 'true';
    container.setAttribute('role', 'dialog'); container.setAttribute('aria-modal', 'true');
    if (!container.hasAttribute('aria-label') && !container.hasAttribute('aria-labelledby')) container.setAttribute('aria-label', 'Fábrica digital ampliada');
    expandButton.textContent = 'Cerrar ampliación'; expandButton.setAttribute('aria-expanded', 'true');
    // Keep the existing iframe in place. Inert siblings prevent keyboard
    // focus from reaching the page behind the expanded presentation.
    for (let branch = container; branch && branch !== document.body; branch = branch.parentElement) {
      for (const sibling of branch.parentElement?.children || []) {
        if (sibling === branch || sibling.tagName === 'STYLE' || sibling.tagName === 'SCRIPT') continue;
        inertElements.push([sibling, sibling.inert]); sibling.inert = true;
      }
    }
    postVisible(true); expandButton.focus({ preventScroll: true });
  }
  function collapse({ focus = true } = {}) {
    if (!expanded) return;
    expanded = false; delete container.dataset.factoryExpanded;
    if (document.body.style.overflow === 'hidden') document.body.style.overflow = bodyOverflow;
    for (const [element, inert] of inertElements) element.inert = inert;
    inertElements = [];
    restoreAttribute(container, 'role', saved.role); restoreAttribute(container, 'aria-modal', saved.modal);
    restoreAttribute(container, 'aria-label', saved.label);
    expandButton.textContent = saved.button; expandButton.setAttribute('aria-expanded', 'false');
    measureVisibility();
    if (focus && expandButton.isConnected) expandButton.focus({ preventScroll: true });
  }
  function onMessage(event) {
    if (event.origin !== origin || event.source !== iframe.contentWindow) return;
    if (event.data?.type === 'factory:resize') applyHeight(event.data.height);
    if (event.data?.type === 'factory:exit-expanded') collapse();
  }
  const onToggle = () => expanded ? collapse() : expand();
  const onKey = event => { if (expanded && event.key === 'Escape') { event.preventDefault(); collapse(); } };
  const onPageHide = () => iframe.contentWindow?.postMessage({ type: 'factory:visibility', visible: false }, origin);
  const observer = typeof window.IntersectionObserver === 'function'
    ? new window.IntersectionObserver(entries => { intersecting = entries.some(entry => entry.isIntersecting); postVisible(); })
    : null;
  observer?.observe(iframe);
  window.addEventListener('message', onMessage);
  window.addEventListener('keydown', onKey);
  window.addEventListener('resize', measureVisibility);
  window.addEventListener('pagehide', onPageHide);
  window.addEventListener('pageshow', onLoad);
  if (!observer) window.addEventListener('scroll', measureVisibility, true);
  document.addEventListener('visibilitychange', measureVisibility);
  iframe.addEventListener('load', onLoad);
  expandButton.addEventListener('click', onToggle);
  onLoad();

  return {
    expand, collapse, isExpanded: () => expanded,
    dispose() {
      if (disposed) return;
      collapse({ focus: false }); onPageHide(); disposed = true;
      observer?.disconnect(); style.remove();
      window.removeEventListener('message', onMessage); window.removeEventListener('keydown', onKey);
      window.removeEventListener('resize', measureVisibility); window.removeEventListener('pagehide', onPageHide);
      window.removeEventListener('pageshow', onLoad); window.removeEventListener('scroll', measureVisibility, true);
      document.removeEventListener('visibilitychange', measureVisibility);
      iframe.removeEventListener('load', onLoad); expandButton.removeEventListener('click', onToggle);
      iframe.style.height = saved.height;
      restoreAttribute(expandButton, 'aria-expanded', saved.expanded);
      if (!saved.containerClass) container.classList.remove('factory-frame-host');
      if (!saved.iframeClass) iframe.classList.remove('factory-frame-content');
    },
  };
}
