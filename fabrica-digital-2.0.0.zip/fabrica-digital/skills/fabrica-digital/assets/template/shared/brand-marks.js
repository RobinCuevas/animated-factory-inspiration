import * as THREE from 'three';
import { PROJECT } from '../src/project.js';

const textureCache = new Map();
const TOP = [-Math.PI / 2, 0, 0];

function imageFrom(url) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error(`No se pudo cargar la marca ${url}`));
    image.src = url;
  });
}

async function sourceTexture(url, resolution, anisotropy) {
  let image, objectUrl, sourceWidth, sourceHeight;
  const vector = /\.svg(?:[?#]|$)/i.test(url);
  try {
    if (vector) {
      const response = await fetch(url);
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const svg = new DOMParser().parseFromString(await response.text(), 'image/svg+xml');
      if (svg.querySelector('parsererror')) throw new Error('SVG no válido');
      const root = svg.documentElement;
      const viewBox = root.getAttribute('viewBox')?.trim().split(/[\s,]+/).map(Number);
      const width = viewBox?.[2] || parseFloat(root.getAttribute('width')) || 1;
      const height = viewBox?.[3] || parseFloat(root.getAttribute('height')) || width;
      sourceWidth = width; sourceHeight = height;
      if (!viewBox) root.setAttribute('viewBox', `0 0 ${width} ${height}`);
      // Only the raster viewport changes. Original paths, gradients, CSS,
      // clipping and brand colours are decoded unchanged by the browser.
      const scale = resolution / Math.max(width, height);
      root.setAttribute('width', String(Math.round(width * scale)));
      root.setAttribute('height', String(Math.round(height * scale)));
      objectUrl = URL.createObjectURL(new Blob([new XMLSerializer().serializeToString(svg)], { type: 'image/svg+xml' }));
      image = await imageFrom(objectUrl);
    } else {
      image = await imageFrom(url);
      sourceWidth = image.naturalWidth; sourceHeight = image.naturalHeight;
    }
    const texture = new THREE.Texture(image);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.anisotropy = anisotropy;
    texture.minFilter = THREE.LinearMipmapLinearFilter;
    texture.magFilter = THREE.LinearFilter;
    texture.generateMipmaps = true;
    texture.needsUpdate = true;
    return { texture, sourceWidth, sourceHeight, width: image.naturalWidth, height: image.naturalHeight, mode: vector ? 'SVG rasterizado por el navegador' : 'Imagen original' };
  } finally {
    if (objectUrl) URL.revokeObjectURL(objectUrl);
  }
}

/** The caller supplies an available rectangle, never a replacement aspect ratio. */
export function containBrandSize(sourceWidth, sourceHeight, maxSize) {
  if (![sourceWidth, sourceHeight, ...maxSize].every(value => Number.isFinite(value) && value > 0)) throw new RangeError('Dimensiones de marca no válidas');
  const factor = Math.min(maxSize[0] / sourceWidth, maxSize[1] / sourceHeight);
  return [sourceWidth * factor, sourceHeight * factor];
}

function acquire(url, resolution, anisotropy) {
  const key = `${url}|${resolution}|${anisotropy}`;
  let entry = textureCache.get(key);
  if (!entry) {
    entry = { key, refs: 0, value: null, promise: null };
    entry.promise = sourceTexture(url, resolution, anisotropy).then(value => {
      entry.value = value;
      if (!entry.refs) { value.texture.dispose(); if (textureCache.get(key) === entry) textureCache.delete(key); }
      return value;
    });
    textureCache.set(key, entry);
  }
  entry.refs++;
  return entry;
}

/** Surface paint belongs to its machine and shares high resolution source art. */
export function createBrandMarks({ anisotropy = 8, status = {} } = {}) {
  const objects = new Set(), geometries = new Set(), materials = new Set(), ownTextures = new Set();
  const entries = new Map(), sources = new Map(), marks = [];
  let disposed = false;
  const own = (parent, geometry, material, position, rotation = [0, 0, 0]) => {
    geometries.add(geometry); materials.add(material);
    const mesh = new THREE.Mesh(geometry, material);
    mesh.position.fromArray(position); mesh.rotation.fromArray(rotation); parent.add(mesh); objects.add(mesh);
    return mesh;
  };
  const paint = () => new THREE.MeshBasicMaterial({
    transparent: true, depthWrite: false, side: THREE.FrontSide, toneMapped: false,
    polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1,
  });
  function stamp(parent, url, position, size, { rotation = [0, 0, 0], resolution = 2048, nodeId = null, surface = 'carcasa' } = {}) {
    const material = paint();
    const mesh = own(parent, new THREE.PlaneGeometry(1, 1), material, position, rotation);
    mesh.scale.set(size[0], size[1], 1);
    mesh.name = `Marca serigrafiada · ${nodeId || url}`;
    mesh.userData.serviceMark = url; mesh.userData.nodeId = nodeId; mesh.visible = false;
    const mark = { nodeId, url, surface, position: [...position], maxSize: [...size], size: [...size], sourceWidth: null, sourceHeight: null, mesh };
    marks.push(mark);
    if (typeof document === 'undefined') { status[url] = 'headless'; return mesh; }
    const key = `${url}|${resolution}`;
    let entry = entries.get(key);
    if (!entry) { entry = acquire(url, resolution, anisotropy); entries.set(key, entry); }
    status[url] = 'loading';
    entry.promise.then(value => {
      if (disposed) return;
      mark.sourceWidth = value.sourceWidth; mark.sourceHeight = value.sourceHeight;
      mark.size = containBrandSize(value.sourceWidth, value.sourceHeight, size);
      mesh.scale.set(mark.size[0], mark.size[1], 1);
      material.map = value.texture; material.needsUpdate = true; mesh.visible = true;
      status[url] = 'loaded';
      sources.set(url, { mode: value.mode, width: value.width, height: value.height, sourceWidth: value.sourceWidth, sourceHeight: value.sourceHeight, aspectRatio: value.sourceWidth / value.sourceHeight, anisotropy });
    }, () => { if (!disposed) status[url] = 'unavailable'; });
    return mesh;
  }
  function text(parent, value, position, size, { rotation = [0, 0, 0], color = '#584945', background = null, nodeId = null, surface = 'carcasa' } = {}) {
    const material = paint();
    const mesh = own(parent, new THREE.PlaneGeometry(...size), material, position, rotation);
    mesh.name = `Rótulo impreso · ${value}`; mesh.userData.nodeId = nodeId;
    marks.push({ nodeId, text: value, surface, position: [...position], size: [...size] });
    if (typeof document === 'undefined') { mesh.visible = false; return mesh; }
    const canvas = document.createElement('canvas');
    canvas.width = 2048; canvas.height = Math.max(128, Math.round(2048 * size[1] / size[0]));
    const context = canvas.getContext('2d');
    if (background) { context.fillStyle = background; context.fillRect(0, 0, canvas.width, canvas.height); }
    context.fillStyle = color; context.textAlign = 'center'; context.textBaseline = 'middle';
    let fontSize = canvas.height * .7;
    do { context.font = `600 ${fontSize}px Arial, sans-serif`; fontSize *= .95; } while (context.measureText(value).width > canvas.width * .96);
    context.fillText(value, canvas.width / 2, canvas.height / 2);
    const texture = new THREE.CanvasTexture(canvas); texture.colorSpace = THREE.SRGBColorSpace; texture.anisotropy = anisotropy;
    ownTextures.add(texture); material.map = texture; material.needsUpdate = true;
    return mesh;
  }
  function casing(parent, size, position, { color = 0xece7dc, name = 'Cubierta de la máquina' } = {}) {
    const mesh = own(parent, new THREE.BoxGeometry(...size), new THREE.MeshStandardMaterial({ color, roughness: .7, metalness: .18 }), position);
    mesh.name = name; mesh.castShadow = true; mesh.receiveShadow = true; return mesh;
  }
  function inspect() {
    return {
      mode: 'Marcas adheridas a superficies', fit: 'contain', sources: Object.fromEntries(sources),
      marks: marks.map(({ mesh, ...mark }) => {
        if (!mesh || !mark.sourceWidth) return { ...mark };
        mesh.updateWorldMatrix(true, false);
        const worldSize = [new THREE.Vector3().setFromMatrixColumn(mesh.matrixWorld, 0).length(), new THREE.Vector3().setFromMatrixColumn(mesh.matrixWorld, 1).length()];
        const sourceRatio = mark.sourceWidth / mark.sourceHeight, renderedRatio = mark.size[0] / mark.size[1], worldRatio = worldSize[0] / worldSize[1];
        return { ...mark, renderedSize: [...mark.size], worldSize, sourceRatio, renderedRatio, worldRatio, aspectError: Math.abs(worldRatio / sourceRatio - 1), preservesAspect: Math.abs(worldRatio / sourceRatio - 1) < 1e-6 };
      }),
    };
  }
  function dispose() {
    if (disposed) return; disposed = true;
    for (const mesh of objects) mesh.removeFromParent();
    for (const material of materials) material.dispose();
    for (const geometry of geometries) geometry.dispose();
    for (const texture of ownTextures) texture.dispose();
    for (const entry of entries.values()) {
      entry.refs--;
      if (!entry.refs) { entry.value?.texture.dispose(); if (textureCache.get(entry.key) === entry) textureCache.delete(entry.key); }
    }
  }
  return { stamp, text, casing, inspect, dispose };
}

/** Covers meet existing frames and leave the working chambers and docks open. */
export function brandMachine(marks, asset, id, { label = null, icon: iconUrl = null, serviceLabel = null, customer = PROJECT.customer } = {}) {
  const parent = asset.object, model = parent.userData.model;
  // Identity comes from the architecture specification, never the machine ID.
  // Geometry and provider choice remain independent when adapting a project.
  const icon = (position, size, options = {}) => iconUrl ? marks.stamp(parent, iconUrl, position, [size, size], { nodeId: id, ...options }) : null;
  const name = (value, position, size, options = {}) => marks.text(parent, value, position, size, { nodeId: id, ...options });
  if (id === 'backend') {
    // Rear hood rests on the gantry. Its front half remains open for the press.
    marks.casing(parent, [2.56, .08, 1.58], [0, 3.44, -.42], { name: 'Cubierta trasera del backend' });
    icon([0, 3.486, -.42], 1.29, { rotation: TOP, surface: 'techo trasero' });
    name(label || serviceLabel || 'Procesamiento', [0, 3.27, 1.326], [2.19, .18], { surface: 'travesaño frontal' });
  } else if (id === 'frontend' || id === 'apim') {
    icon([0, 2.992, -.04], 1.65, { rotation: TOP, surface: 'techo' });
    name(serviceLabel || label || 'Servicio web', [0, 2.59, .813], [1.89, .22], { color: '#f3ece5', surface: 'frente del rack' });
  } else if (id === 'worker') {
    icon([0, 3.496, -.05], 1.82, { rotation: TOP, surface: 'techo' });
    name(serviceLabel || label || 'Proceso en segundo plano', [0, 3.28, 1.237], [2.55, .25], { surface: 'dintel frontal' });
  } else if (id === 'sql') {
    icon([0, 4.457, 0], 1.31, { rotation: TOP, surface: 'tapa de la bóveda' });
  } else if (id === 'entry') {
    marks.casing(parent, [3.43, .075, 1.58], [0, 3.03, -.3], { name: 'Cubierta de la entrada' });
    icon([0, 3.074, -.3], 1.32, { rotation: TOP, surface: 'techo de la entrada' });
    name(serviceLabel || label || 'Entrada protegida', [0, 2.73, -.013], [2.45, .32], { surface: 'travesaño de entrada' });
  } else if (id === 'blob') {
    // A canopy on the right bay keeps the central file lift and shelf exposed.
    marks.casing(parent, [2.43, .08, 3.42], [2.53, 3.8, 0], { name: 'Cubierta lateral del almacén' });
    icon([2.53, 3.846, -.13], 2.01, { rotation: TOP, surface: 'techo del módulo lateral' });
    name(serviceLabel || label || 'Almacén de objetos', [2.53, 3.847, 1.25], [2.05, .32], { rotation: TOP, surface: 'techo del módulo lateral' });
  } else if (id === 'queue') {
    // A drive casing fixed outside the belt, with no object in the token lane.
    marks.casing(parent, [.9, .82, 1.83], [1.52, .59, -1.22], { name: 'Carcasa del accionamiento de la cinta' });
    icon([1.52, 1.007, -1.4], .76, { rotation: TOP, surface: 'carcasa del motor lateral' });
    name(serviceLabel || label || 'Mensajería', [1.978, .6, -1.22], [1.57, .27], { rotation: [0, Math.PI / 2, 0], surface: 'carcasa del motor lateral' });
  } else if (['erp', 'orders', 'pricing'].includes(id)) {
    if (iconUrl) marks.stamp(model.userData.screen, iconUrl, [0, .01, .089], [1.18, .68], { nodeId: id, surface: 'pantalla' });
    else marks.text(model.userData.screen, serviceLabel || label || id.toUpperCase(), [0, .01, .089], [1.2, .68], { color: '#ffffff', nodeId: id, surface: 'pantalla' });
    model.userData.symbol.visible = false;
  } else if (id === 'client') {
    for (const screen of [model.userData.originalScreen, model.userData.reviewScreen]) {
      // Replacing the small generic screen UI does not add an extra display.
      for (const child of screen.children.slice(2)) child.visible = false;
    }
    if (customer.logo) marks.stamp(model.userData.originalScreen, customer.logo, [0, .017, .085], [1.1, .65], { nodeId: id, surface: 'pantalla izquierda' });
    else marks.text(model.userData.originalScreen, customer.name || 'Cliente', [0, .017, .085], [1.1, .6], { color: PROJECT.palette.dark, nodeId: id, surface: 'pantalla izquierda' });
    marks.text(model.userData.reviewScreen, 'Portal', [0, .017, .085], [1.1, .6], { color: PROJECT.palette.accent, nodeId: id, surface: 'pantalla derecha' });
  }
}
