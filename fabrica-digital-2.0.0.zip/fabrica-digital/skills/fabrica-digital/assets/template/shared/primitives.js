import * as THREE from 'three';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
import { PROJECT, applyProjectPalette } from '../src/project.js';

// Every workshop owns its materials and geometry. No global kit state changes.
export function makeWorkshop({ palette: colours = PROJECT.palette } = {}) {
  const root = new THREE.Group();
  const palette = Object.fromEntries(Object.entries({
    ivory:0xeee9db,teal:0x246964,steel:0x83928e,dark:0x253c39,
    amber:0xd6a24b,green:0x6da574,red:0xbe5749,purple:0x8870ab,white:0xfffaf0,
  }).map(([key,color])=>[key,new THREE.MeshStandardMaterial({
    color,roughness:key==='steel'?.32:.48,metalness:key==='steel'?.65:.15,
  })]));
  applyProjectPalette(palette, colours);
  const geometries=new Set(),materials=new Set(Object.values(palette)),textures=new Set();
  function mesh(geometry,material,pos=[0,0,0]) {
    geometries.add(geometry);materials.add(material);
    const item=new THREE.Mesh(geometry,material);
    item.position.fromArray(pos);item.castShadow=true;item.receiveShadow=true;
    root.add(item);return item;
  }
  function box(w,h,d,material=palette.ivory,pos=[0,0,0],radius=.05) {
    const r=Math.min(radius,w/3,h/3,d/3);
    return mesh(r>0?new RoundedBoxGeometry(w,h,d,2,r):new THREE.BoxGeometry(w,h,d),material,pos);
  }
  function cylinder(radius,height,material=palette.steel,pos=[0,0,0]) {
    return mesh(new THREE.CylinderGeometry(radius,radius,height,20),material,pos);
  }
  function rod(a,b,radius=.04,material=palette.steel) {
    const start=new THREE.Vector3().fromArray(a),end=new THREE.Vector3().fromArray(b);
    const direction=end.clone().sub(start);
    const item=cylinder(radius,direction.length(),material,start.clone().add(end).multiplyScalar(.5).toArray());
    item.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),direction.normalize());return item;
  }
  function label(text,pos=[0,0,0],{width=2,height=.35,color='#253d39',background='#f1eee6'}={}) {
    let canvas,context,texture;
    if(typeof document!=='undefined') {
      canvas=document.createElement('canvas');canvas.width=Math.max(128,Math.round(width*220));canvas.height=Math.max(64,Math.round(height*220));
      context=canvas.getContext('2d');texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;textures.add(texture);
    }
    const material=new THREE.MeshBasicMaterial({map:texture||null,color:texture?0xffffff:0xf1eee6,side:THREE.DoubleSide,transparent:true,depthWrite:false,toneMapped:false});
    const item=mesh(new THREE.PlaneGeometry(width,height),material,pos);
    item.castShadow=false;item.receiveShadow=false;item.name=String(text);
    let last;
    item.userData.setText=(value)=>{
      const next=String(value);if(next===last)return;last=next;item.name=next;
      if(!context)return;
      context.clearRect(0,0,canvas.width,canvas.height);
      if(background){context.fillStyle=background;context.fillRect(0,0,canvas.width,canvas.height)}
      context.fillStyle=color;context.textAlign='center';context.textBaseline='middle';
      let size=Math.round(canvas.height*.61);context.font=`600 ${size}px "DM Sans", Arial`;
      while(context.measureText(next).width>canvas.width*.92&&size>8){size--;context.font=`600 ${size}px "DM Sans", Arial`}
      context.fillText(next,canvas.width/2,canvas.height*.51);texture.needsUpdate=true;
    };
    item.userData.setText(text);return item;
  }
  function belt(x,z,length,width=1.2) {
    const group=new THREE.Group();root.add(group);group.position.set(x,0,z);
    const put=item=>{root.remove(item);group.add(item);return item};
    for(const edge of [-1,1])put(box(length,.2,.12,palette.teal,[0,.7,edge*(width/2+.03)]));
    const rollers=[];
    for(let rx=-length/2+.12;rx<length/2;rx+=.28){const roll=put(cylinder(.1,width,palette.steel,[rx,.75,0]));roll.rotation.x=Math.PI/2;rollers.push(roll)}
    for(const rx of [-length/2+.3,length/2-.3])for(const rz of [-width/2+.1,width/2-.1]){
      put(box(.12,.65,.12,palette.steel,[rx,.34,rz]));put(box(.28,.07,.26,palette.dark,[rx,.04,rz]));
    }
    group.userData.rollers=rollers;return group;
  }
  function parcel(text,pos=[0,1,0],{color=0xe5b85e,width=.65}={}) {
    const group=new THREE.Group();root.add(group);group.position.fromArray(pos);group.name=`Pieza ${text}`;
    const material=new THREE.MeshStandardMaterial({color,roughness:.54,metalness:.05});materials.add(material);
    const body=box(width,.22,.48,material,[0,0,0],.03);root.remove(body);group.add(body);
    const tag=label(text,[0,.116,0],{width:width*.85,height:.32,background:null});
    root.remove(tag);group.add(tag);tag.rotation.x=-Math.PI/2;
    group.userData.setText=tag.userData.setText;group.userData.body=body;return group;
  }
  function dispose() {
    root.traverse(item=>{
      if(item.geometry)geometries.add(item.geometry);
      for(const material of item.material?(Array.isArray(item.material)?item.material:[item.material]):[])materials.add(material);
    });
    for(const material of materials){if(material.map)textures.add(material.map);material.dispose()}
    for(const geometry of geometries)geometry.dispose();for(const texture of textures)texture.dispose();
    root.removeFromParent();root.clear();
  }
  return {root,palette,box,cylinder,rod,label,belt,parcel,dispose};
}
