import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import {RoomEnvironment} from 'three/addons/environments/RoomEnvironment.js';
import {PROJECT} from '../src/project.js';

// Fixed-angle presentation camera. Pixel density follows browser zoom and
// display changes, while a bounded pixel budget protects large screens.
export function createViewer(element,{padding=1.18,onManual=()=>{},cameraSeconds=PROJECT.playback.cameraSeconds,maxRenderPixels=PROJECT.rendering.maxPixels,clock=()=>performance.now()}={}){
  const renderer=new THREE.WebGLRenderer({antialias:true,alpha:true,preserveDrawingBuffer:true});
  renderer.setClearColor(0xf5f5ed,0);
  const gl=renderer.getContext(),maxBufferDimension=Math.min(renderer.capabilities.maxTextureSize,gl.getParameter(gl.MAX_RENDERBUFFER_SIZE));
  // Match browser zoom and Retina density without allocating an unbounded
  // multisampled framebuffer on large displays. The budget is roughly 4K.
  renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=.94;
  renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
  const canvas=renderer.domElement;canvas.style.cssText='display:block;width:100%;height:100%;touch-action:none;outline-offset:-4px';canvas.tabIndex=0;
  canvas.setAttribute('aria-label','Fábrica digital en 3D. Pulsa una máquina para conocer su función. Arrastra para desplazarte y usa la rueda para ampliar.');element.prepend(canvas);
  const scene=new THREE.Scene(),camera=new THREE.OrthographicCamera(-28,28,20,-20,.1,700),controls=new OrbitControls(camera,canvas);
  Object.assign(controls,{enableDamping:true,dampingFactor:.11,enablePan:true,enableRotate:false,screenSpacePanning:true,panSpeed:.8,minZoom:.55,maxZoom:5,zoomSpeed:.65});
  controls.mouseButtons={LEFT:THREE.MOUSE.PAN,MIDDLE:THREE.MOUSE.PAN,RIGHT:THREE.MOUSE.PAN};
  controls.touches={ONE:THREE.TOUCH.PAN,TWO:THREE.TOUCH.DOLLY_PAN};
  const env=new RoomEnvironment(),pmrem=new THREE.PMREMGenerator(renderer),environmentTarget=pmrem.fromScene(env,.035);
  scene.environment=environmentTarget.texture;scene.environmentIntensity=.52;env.dispose();pmrem.dispose();
  const sun=new THREE.DirectionalLight(0xfff9ed,3.1);sun.position.set(-28,48,26);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);
  Object.assign(sun.shadow.camera,{left:-38,right:38,top:32,bottom:-32,near:1,far:130});sun.shadow.bias=-.0002;sun.shadow.normalBias=.055;scene.add(sun,sun.target,new THREE.AmbientLight(0xffffff,.7));
  const fg=new THREE.PlaneGeometry(250,250),fm=new THREE.ShadowMaterial({color:0x33473f,opacity:.15,depthWrite:false}),floor=new THREE.Mesh(fg,fm);
  floor.rotation.x=-Math.PI/2;floor.position.y=-.24;floor.receiveShadow=true;scene.add(floor);
  const direction=new THREE.Vector3(.37,.95,1.5).normalize(),right=new THREE.Vector3().crossVectors(new THREE.Vector3(0,1,0),direction).normalize(),up=new THREE.Vector3().crossVectors(direction,right).normalize();
  let width=1,height=1,active=null,disposed=false,guided=true,first=true,lastClock=clock(),fitPadding=padding,transition=null;
  let wholeBounds=new THREE.Box3(new THREE.Vector3(-23,0,-11),new THREE.Vector3(23,6,15)),targetBounds=wholeBounds.clone(),targetHalf=22,currentHalf=22;
  const targetCenter=new THREE.Vector3(),currentCenter=new THREE.Vector3();
  function rasterRatio(){return Math.min(window.devicePixelRatio||1,Math.sqrt(maxRenderPixels/(width*height)),maxBufferDimension/width,maxBufferDimension/height);}
  function syncRaster(force=false){const ratio=rasterRatio();if(force||Math.abs(renderer.getPixelRatio()-ratio)>.000001)renderer.setDrawingBufferSize(width,height,ratio);}
  function measure(bounds){
    bounds.getCenter(targetCenter);let minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity;
    for(const x of [bounds.min.x,bounds.max.x])for(const y of [bounds.min.y,bounds.max.y])for(const z of [bounds.min.z,bounds.max.z]){
      const p=new THREE.Vector3(x,y,z).sub(targetCenter),px=p.dot(right),py=p.dot(up);minX=Math.min(minX,px);maxX=Math.max(maxX,px);minY=Math.min(minY,py);maxY=Math.max(maxY,py);
    }
    targetHalf=Math.max(5,(maxY-minY)/2,(maxX-minX)/(2*width/height))*fitPadding;
  }
  function projection(){const aspect=width/height;camera.left=-currentHalf*aspect;camera.right=currentHalf*aspect;camera.top=currentHalf;camera.bottom=-currentHalf;camera.updateProjectionMatrix();}
  function applyCamera(){if(!guided)return;controls.target.copy(currentCenter);camera.position.copy(currentCenter).addScaledVector(direction,110);camera.lookAt(currentCenter);projection();controls.update();camera.updateMatrixWorld(true);}
  function focus(bounds,{immediate=false,padding:requestedPadding=padding}={}){
    if(!bounds||bounds.isEmpty())return;
    if(!guided){currentCenter.copy(controls.target);currentHalf/=camera.zoom;}
    fitPadding=requestedPadding;targetBounds.copy(bounds);measure(targetBounds);guided=true;camera.zoom=1;
    const instant=immediate||first||matchMedia('(prefers-reduced-motion: reduce)').matches;
    transition=instant?null:{center:currentCenter.clone(),half:currentHalf,elapsed:0,duration:Math.max(.01,cameraSeconds)};
    if(instant){currentCenter.copy(targetCenter);currentHalf=targetHalf;first=false;}
    applyCamera();
  }
  function mount(instance){if(active)scene.remove(active);active=instance.object;scene.add(active);active.updateMatrixWorld(true);wholeBounds=new THREE.Box3().setFromObject(active);focus(wholeBounds,{immediate:true});}
  function reset(){focus(wholeBounds);}
  // An offline renderer can supply milliseconds per captured frame. Setting
  // this once resets the time origin; repeated render() calls at one timestamp
  // have zero delta and never advance a camera transition twice.
  function setClock(next){if(typeof next!=='function')throw new TypeError('El reloj debe ser una función.');clock=next;lastClock=clock();}
  function render(){
    if(disposed)return;
    syncRaster();
    const now=clock(),dt=Math.min(.1,Math.max(0,(now-lastClock)/1000));lastClock=now;
    if(guided&&transition){
      transition.elapsed+=dt;
      const t=Math.min(1,transition.elapsed/transition.duration),e=t*t*t*(t*(t*6-15)+10);
      currentCenter.copy(transition.center).lerp(targetCenter,e);currentHalf=THREE.MathUtils.lerp(transition.half,targetHalf,e);
      if(t===1)transition=null;
    }
    applyCamera();controls.update();renderer.render(scene,camera);
  }
  function resize(){const rect=element.getBoundingClientRect();width=Math.max(1,rect.width);height=Math.max(1,rect.height);syncRaster(true);measure(targetBounds);if(guided){transition=null;currentCenter.copy(targetCenter);currentHalf=targetHalf;applyCamera();}else projection();render();}
  const manual=()=>{guided=false;transition=null;onManual();};controls.addEventListener('start',manual);
  const keydown=event=>{
    if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','+','=','-','0'].includes(event.key))return;event.preventDefault();if(event.key==='0'){focus(targetBounds);return;}manual();
    if(['+','=','-'].includes(event.key))camera.zoom=THREE.MathUtils.clamp(camera.zoom*(event.key==='-'?.9:1.1),controls.minZoom,controls.maxZoom);
    else{const step=currentHalf*.1/camera.zoom,shift=new THREE.Vector3();if(event.key==='ArrowLeft')shift.addScaledVector(right,-step);if(event.key==='ArrowRight')shift.addScaledVector(right,step);if(event.key==='ArrowUp')shift.addScaledVector(up,step);if(event.key==='ArrowDown')shift.addScaledVector(up,-step);controls.target.add(shift);camera.position.add(shift);}camera.updateProjectionMatrix();render();
  };
  canvas.addEventListener('keydown',keydown);const observer=new ResizeObserver(resize);observer.observe(element);resize();
  return {scene,camera,controls,renderer,mount,focus,render,reset,setClock,inspect:()=>({width,height,guided,zoom:camera.zoom,pixelRatio:renderer.getPixelRatio(),devicePixelRatio:window.devicePixelRatio,drawingBuffer:[canvas.width,canvas.height],transition:transition?{progress:Math.min(1,transition.elapsed/transition.duration),duration:transition.duration}:null,canPan:controls.enablePan,canRotate:controls.enableRotate,camera:camera.position.toArray(),target:controls.target.toArray(),bounds:{min:wholeBounds.min.toArray(),max:wholeBounds.max.toArray()},drawCalls:renderer.info.render.calls}),dispose(){if(disposed)return;disposed=true;observer.disconnect();controls.removeEventListener('start',manual);controls.dispose();canvas.removeEventListener('keydown',keydown);fg.dispose();fm.dispose();environmentTarget.dispose();renderer.dispose();canvas.remove();}};
}
