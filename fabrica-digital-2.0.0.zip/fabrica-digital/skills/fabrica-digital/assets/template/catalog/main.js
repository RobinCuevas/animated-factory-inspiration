import { ASSETS, THEMES, createAsset } from '../kit/index.js';
import { createViewer } from './viewer.js';

const $ = selector => document.querySelector(selector);
const params = new URLSearchParams(location.search);
const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
const groups = [
  { title: 'Origen y llegada', ids: ['document', 'archive', 'delivery-van', 'delivery-truck'] },
  { title: 'Entrada y recorrido', ids: ['connector', 'ingester', 'object-store', 'queue', 'dead-letter'] },
  { title: 'Trabajo y datos', ids: ['processor', 'processor-pool', 'database'] },
  { title: 'Personas y acceso', ids: ['identity', 'human', 'review', 'api'] },
  { title: 'El entorno', ids: ['factory'] },
];
const shortTitles = {
  document: 'Documentos y referencias', archive: 'Archivo de originales',
  'delivery-van': 'Furgoneta documental', 'delivery-truck': 'Camión documental',
  connector: 'Conector de consulta', ingester: 'Máquina de ingesta',
  'object-store': 'Almacén de objetos', queue: 'Cola de trabajo',
  'dead-letter': 'Cola de incidencias', processor: 'Máquina de procesamiento',
  'processor-pool': 'Capacidad elástica', database: 'Base de datos',
  identity: 'Acceso e identidad', human: 'Persona', review: 'Revisión humana',
  api: 'Servicio de acceso', factory: 'Nube del cliente',
};
const stateNames = {
  kind: '5 tipos de documento', open: 'Apertura', loaded: 'Carga', moving: 'Desplazamiento',
  processing: 'Procesamiento', running: 'Movimiento', count: 'Trabajo pendiente',
  active: 'Incidencia', capacity: '0 a 6 instancias', authorized: 'Autorización',
  walking: 'Caminar', identified: 'Credencial', document: 'Documento en mano',
};
const kinds = { original: 'Original', copy: 'Copia', job: 'Referencia', data: 'Dato', error: 'Incidencia' };
const definitions = new Map(ASSETS.map(asset => [asset.id, asset]));
let selected = null, theme = THEMES[params.get('theme')] ? params.get('theme') : 'neutral';
let instance = null, viewer = null, time = 0, manualState = {}, snapshot = {};
let playing = !reducedMotion && !params.has('t'), lastFrame = performance.now();
let snapshotSignature = '', buttons = new Map();

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function buildLibrary() {
  let number = 0;
  for (const group of groups) {
    const section = element('div', 'asset-section');
    section.append(element('h3', 'asset-section-title', group.title));
    const options = element('optgroup');
    options.label = group.title;
    for (const id of group.ids) {
      if (!definitions.has(id)) continue;
      number++;
      const button = element('button', 'asset-option');
      button.type = 'button';
      button.dataset.asset = id;
      button.setAttribute('aria-current', 'false');
      const num = element('span', 'asset-number', String(number).padStart(2, '0'));
      num.setAttribute('aria-hidden', 'true');
      button.append(num, element('span', '', shortTitles[id]));
      button.addEventListener('click', () => select(id));
      section.append(button);
      buttons.set(id, button);
      const option = element('option', '', shortTitles[id]);
      option.value = id;
      options.append(option);
    }
    $('#asset-list').append(section);
    $('#asset-select').append(options);
  }
  $('#library-count').textContent = `${ASSETS.length} piezas · 4 paletas`;
  $('#asset-select').addEventListener('change', event => select(event.target.value));
}

function renderControls(definition) {
  const controls = $('#asset-controls');
  controls.replaceChildren();
  const states = definition.states || [];
  if (!states.length) {
    controls.append(element('p', 'controls-note', 'Gira la pieza para explorar su volumen. Puedes situarla, orientarla y combinarla en tu escena.'));
    return;
  }

  function choices(key, options, label) {
    const wrapper = element('div', 'choice-control');
    wrapper.role = 'group';
    wrapper.setAttribute('aria-label', label);
    for (const [value, title] of options) {
      const button = element('button', '', title);
      button.type = 'button';
      button.dataset.stateKey = key;
      button.dataset.stateValue = String(value);
      button.setAttribute('aria-pressed', 'false');
      button.addEventListener('click', () => setState({ [key]: value }));
      wrapper.append(button);
    }
    controls.append(wrapper);
  }

  function range(key, label, max, step = .01) {
    const row = element('div', 'control-row');
    const labelNode = element('label', '', label);
    labelNode.htmlFor = `control-${key}`;
    const input = element('input');
    input.id = `control-${key}`;
    input.type = 'range';
    input.min = '0';
    input.max = String(max);
    input.step = String(step);
    input.dataset.control = key;
    input.addEventListener('input', () => setState({ [key]: Number(input.value) }));
    const output = element('output');
    output.htmlFor = input.id;
    output.dataset.output = key;
    row.append(labelNode, input, output);
    controls.append(row);
  }

  if (states.includes('capacity')) {
    const capacity = element('div', 'capacity-control');
    capacity.role = 'group';
    capacity.setAttribute('aria-label', 'Número de instancias de procesamiento');
    for (let n = 0; n <= 6; n++) {
      const button = element('button', '', String(n));
      button.type = 'button';
      button.dataset.stateKey = 'capacity';
      button.dataset.stateValue = String(n);
      button.setAttribute('aria-label', `${n} ${n === 1 ? 'instancia' : 'instancias'}`);
      button.setAttribute('aria-pressed', 'false');
      button.addEventListener('click', () => setState({ capacity: n }));
      capacity.append(button);
    }
    const note = element('div', 'capacity-note');
    note.append(element('span', '', 'Sin demanda'), element('span', '', 'Pico de trabajo'));
    controls.append(capacity, note);
  }
  if (states.includes('authorized')) choices('authorized', [[false, 'Acceso cerrado'], [true, 'Identidad verificada']], 'Estado del acceso');
  if (states.includes('walking')) choices('walking', [[true, 'Caminar'], [false, 'En reposo']], 'Movimiento de la persona');
  if (states.includes('active')) choices('active', [[true, 'Con incidencia'], [false, 'Sin incidencia']], 'Estado de la cola de incidencias');
  if (states.includes('open')) range('open', 'Apertura', 1);
  if (states.includes('count')) range('count', 'Referencias', 4, 1);
  if (states.includes('kind')) {
    const row = element('div', 'control-row');
    const label = element('label', '', 'Representa');
    label.htmlFor = 'control-kind';
    const select = element('select');
    select.id = 'control-kind';
    select.dataset.control = 'kind';
    for (const [value, title] of Object.entries(kinds)) {
      const option = element('option', '', title);
      option.value = value;
      select.append(option);
    }
    select.addEventListener('change', () => setState({ kind: select.value }));
    row.append(label, select);
    controls.append(row);
  }
  for (const [key, label] of [['loaded', 'Documentos a bordo'], ['processing', 'Procesar'], ['running', 'Cinta en marcha'], ['identified', 'Mostrar credencial'], ['document', 'Documento en mano']]) {
    if (!states.includes(key)) continue;
    const row = element('div', 'control-row');
    const labelNode = element('label', '', label);
    labelNode.htmlFor = `control-${key}`;
    const input = element('input');
    input.type = 'checkbox';
    input.id = `control-${key}`;
    input.dataset.control = key;
    input.addEventListener('change', () => setState({ [key]: input.checked }));
    row.append(labelNode, input);
    controls.append(row);
  }
}

function updateControls() {
  const current = { ...snapshot, ...manualState };
  if (selected === 'processor-pool') current.processing = manualState.processing ?? true;
  for (const control of document.querySelectorAll('[data-control]')) {
    const value = current[control.dataset.control];
    if (value === undefined) continue;
    if (control.type === 'checkbox') control.checked = Boolean(value);
    else control.value = value;
    if (control.type === 'range') control.setAttribute('aria-valuetext', control.dataset.control === 'open' ? `${Math.round(Number(value) * 100)} por ciento` : String(Math.round(value)));
  }
  for (const output of document.querySelectorAll('[data-output]')) {
    const value = current[output.dataset.output] ?? 0;
    output.textContent = output.dataset.output === 'open' ? `${Math.round(value * 100)} %` : String(Math.round(value));
  }
  for (const button of document.querySelectorAll('[data-state-key]')) {
    const value = current[button.dataset.stateKey];
    const active = button.dataset.stateKey === 'capacity'
      ? Math.abs(Number(value) - Number(button.dataset.stateValue)) < .05
      : String(value) === button.dataset.stateValue;
    button.setAttribute('aria-pressed', String(active));
  }
  const isManual = Object.keys(manualState).length > 0;
  $('#auto-mode').hidden = !isManual;
  $('#controls-panel').classList.toggle('manual', isManual);
}

function updateCode() {
  if (!selected) return;
  const definition = definitions.get(selected);
  const values = Object.entries(manualState).map(([key, value]) => `${key}: ${JSON.stringify(value)}`).join(', ');
  const state = values ? `, { ${values} }` : '';
  $('#usage-code').textContent = `import { createAsset } from './kit/index.js';\n\nconst pieza = createAsset('${selected}', { theme: '${theme}' });\nscene.add(pieza.object);\npieza.object.position.set(0, 0, 0);\n\n// ${definition.states.length ? 'Dentro del bucle de animación' : 'Establece su estado inicial'}\npieza.update(timeSeconds${state});\n\n// Al retirar la pieza de la escena\n// pieza.dispose();`;
}

function formatTime(value) {
  return `${Math.floor(value / 60)}:${String(Math.floor(value % 60)).padStart(2, '0')}`;
}

function render() {
  if (!instance || !viewer) return;
  snapshot = instance.update(time, manualState);
  viewer.render();
  const duration = definitions.get(selected).duration;
  $('#timeline').value = time;
  $('#timeline').setAttribute('aria-valuetext', `${time.toFixed(1)} de ${duration} segundos`);
  $('#time-label').value = `${formatTime(time)} / ${formatTime(duration)}`;
  document.body.classList.toggle('paused', !playing);
  $('#play-label').textContent = playing ? 'Pausar' : 'Reproducir';
  $('#play').setAttribute('aria-label', playing ? 'Pausar animación' : 'Reproducir animación');
  const signature = JSON.stringify(snapshot, (key, value) => key === 'time' ? undefined : typeof value === 'number' ? Math.round(value * 100) / 100 : value);
  if (signature !== snapshotSignature) {
    snapshotSignature = signature;
    updateControls();
  }
}

function select(id, options = {}) {
  if (!definitions.has(id)) throw new RangeError(`Pieza desconocida: ${id}`);
  const definition = definitions.get(id);
  selected = id;
  time = options.keepTime ? time : 0;
  manualState = options.keepState ? manualState : {};
  snapshotSignature = '';
  if (instance) instance.dispose();
  instance = createAsset(id, { theme });
  for (const [assetId, button] of buttons) button.setAttribute('aria-current', String(assetId === id));
  $('#asset-select').value = id;
  $('#asset-group').textContent = groups.find(group => group.ids.includes(id))?.title || '';
  $('#asset-title').textContent = definition.title;
  $('#asset-description').textContent = definition.description;
  $('#asset-meaning').textContent = definition.meaning;
  $('#state-badges').replaceChildren(...definition.states.slice(0, 3).map(state => element('span', '', stateNames[state] || state)));
  $('#timeline').max = definition.duration;
  renderControls(definition);
  viewer.mount(instance, definition, time, manualState);
  updateCode();
  updateControls();
  lastFrame = performance.now();
  render();
  const next = new URL(location.href);
  next.searchParams.set('asset', id);
  next.searchParams.set('theme', theme);
  history.replaceState(null, '', `${next.pathname}${next.search}${next.hash}`);
  return inspect();
}

function seek(value) {
  if (!selected) return null;
  time = Math.max(0, Math.min(definitions.get(selected).duration, Number(value) || 0));
  playing = false;
  lastFrame = performance.now();
  render();
  return inspect();
}

function setState(state = {}) {
  if (!selected) return null;
  const next = { ...state };
  // The interactive catalogue never demonstrates an open unauthorized gate.
  // Authors can still represent their architecture's own states via the kit.
  if (selected === 'identity') {
    if (next.authorized === false) next.open = 0;
    else if (next.authorized === true && next.open === undefined) next.open = 1;
    else if (Number(next.open) > 0) next.authorized = true;
  }
  manualState = { ...manualState, ...next };
  playing = false;
  snapshotSignature = '';
  updateCode();
  render();
  updateControls();
  return inspect();
}

function setTheme(value) {
  if (!THEMES[value]) throw new RangeError(`Paleta desconocida: ${value}`);
  theme = value;
  for (const button of document.querySelectorAll('[data-theme]')) button.setAttribute('aria-pressed', String(button.dataset.theme === theme));
  if (selected) select(selected, { keepTime: true, keepState: true });
  return inspect();
}

function inspect() {
  return { selected, theme, time, playing, manualState: { ...manualState }, snapshot: { ...snapshot }, viewer: viewer?.inspect(), assetCount: ASSETS.length };
}

function clearManual() {
  manualState = {};
  snapshotSignature = '';
  playing = !reducedMotion;
  lastFrame = performance.now();
  updateCode();
  render();
  updateControls();
}

async function init() {
  await document.fonts.ready;
  buildLibrary();
  try {
    viewer = createViewer($('#stage'));
    $('#stage-message').hidden = true;
  } catch (error) {
    $('#stage-message').textContent = 'Este navegador no ha podido abrir el visor 3D. Abre la biblioteca en un navegador con WebGL disponible.';
    $('#stage-message').dataset.error = error.message;
    for (const control of document.querySelectorAll('.workbench button,.workbench input,.asset-option,#asset-select')) control.disabled = true;
    return;
  }
  const initial = definitions.has(params.get('asset')) ? params.get('asset') : 'processor-pool';
  select(initial);
  setTheme(theme);
  if (params.has('t')) seek(params.get('t'));
  $('#play').addEventListener('click', () => {
    playing = !playing;
    if (playing && time >= definitions.get(selected).duration) time = 0;
    lastFrame = performance.now();
    render();
  });
  $('#replay').addEventListener('click', () => {
    time = 0;
    manualState = {};
    playing = true;
    lastFrame = performance.now();
    updateCode();
    snapshotSignature = '';
    render();
    updateControls();
  });
  $('#timeline').addEventListener('input', event => seek(event.target.value));
  $('#reset-view').addEventListener('click', () => viewer.reset());
  $('#auto-mode').addEventListener('click', clearManual);
  for (const button of document.querySelectorAll('[data-theme]')) button.addEventListener('click', () => setTheme(button.dataset.theme));
  $('#copy-code').addEventListener('click', async () => {
    const code = $('#usage-code').textContent;
    try {
      await navigator.clipboard.writeText(code);
      $('#copy-status').textContent = 'Ejemplo copiado.';
    } catch {
      const range = document.createRange();
      range.selectNodeContents($('#usage-code'));
      const selection = window.getSelection();
      selection.removeAllRanges();
      selection.addRange(range);
      $('#copy-status').textContent = 'Ejemplo seleccionado. Usa Copiar en tu navegador.';
    }
  });
  document.addEventListener('keydown', event => {
    if (event.code !== 'Space' || event.target.closest('button,a,input,select,summary,textarea,canvas')) return;
    event.preventDefault();
    $('#play').click();
  });
  document.addEventListener('visibilitychange', () => { lastFrame = performance.now(); });
  window.catalogAPI = { select, seek, inspect, setState, setTheme };
  function tick(now) {
    const delta = Math.min(Math.max((now - lastFrame) / 1000, 0), .1);
    lastFrame = now;
    if (playing && !document.hidden) time = (time + delta) % definitions.get(selected).duration;
    render();
    requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
}

init();
