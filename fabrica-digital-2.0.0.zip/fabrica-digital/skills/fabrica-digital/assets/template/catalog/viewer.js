import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

/** The viewer owns only lighting and framing. Every displayed part is a real
 * kit instance, with the same transforms and animation API used in a scene. */
export function createViewer(element, {padding = 1.22, fitToContent = false} = {}) {
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true });
  const gl=renderer.getContext();
  const maxDimension=Math.min(renderer.capabilities.maxTextureSize,gl.getParameter(gl.MAX_RENDERBUFFER_SIZE));
  const pixelBudget=8_388_608;
  renderer.setClearColor(0xfffef8, 0);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = .88;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.VSMShadowMap;
  renderer.domElement.tabIndex = 0;
  renderer.domElement.setAttribute('aria-label', 'Pieza en 3D. Arrastra para girar, usa la rueda para ampliar. Con el teclado: flechas para girar, más y menos para ampliar, cero para restablecer.');
  element.prepend(renderer.domElement);

  const scene = new THREE.Scene();
  const environment = new RoomEnvironment();
  const pmrem = new THREE.PMREMGenerator(renderer);
  const environmentTarget = pmrem.fromScene(environment, .025);
  scene.environment = environmentTarget.texture;
  scene.environmentIntensity = .5;
  environment.dispose();
  pmrem.dispose();

  const camera = new THREE.OrthographicCamera(-10, 10, 10, -10, .01, 1200);
  const controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = .09;
  controls.enablePan = false;
  controls.minPolarAngle = .12;
  controls.maxPolarAngle = Math.PI / 2 - .02;
  controls.minZoom = .6;
  controls.maxZoom = 3.5;
  controls.zoomSpeed = .7;
  controls.rotateSpeed = .6;

  const sun = new THREE.DirectionalLight(0xfffaf0, 3);
  sun.position.set(-16, 28, 18);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  sun.shadow.bias = -.00015;
  sun.shadow.normalBias = .025;
  sun.shadow.radius = 5;
  sun.shadow.blurSamples = 12;
  scene.add(sun, sun.target, new THREE.AmbientLight(0xffffff, .55));
  const floorGeometry = new THREE.PlaneGeometry(400, 400);
  const floorMaterial = new THREE.ShadowMaterial({ color: 0x61705c, opacity: .12, depthWrite: false });
  const floor = new THREE.Mesh(floorGeometry, floorMaterial);
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  scene.add(floor);

  let fittedBounds = new THREE.Box3(new THREE.Vector3(-5, 0, -5), new THREE.Vector3(5, 5, 5));
  let width = 1, height = 1, activeObject = null;
  let framingPoints = [];
  const center = new THREE.Vector3();
  const direction = new THREE.Vector3(1, .82, 1.42).normalize();

  function projectionSize() {
    camera.updateMatrixWorld(true);
    const projected = new THREE.Box3();
    if (fitToContent && framingPoints.length) {
      for (const point of framingPoints) projected.expandByPoint(point.clone().applyMatrix4(camera.matrixWorldInverse));
    } else for (const x of [fittedBounds.min.x, fittedBounds.max.x]) {
      for (const y of [fittedBounds.min.y, fittedBounds.max.y]) {
        for (const z of [fittedBounds.min.z, fittedBounds.max.z]) {
          projected.expandByPoint(new THREE.Vector3(x, y, z).applyMatrix4(camera.matrixWorldInverse));
        }
      }
    }
    const extent = projected.getSize(new THREE.Vector3());
    const aspect = width / height;
    const halfHeight = Math.max(extent.y / 2, extent.x / (2 * aspect), .12) * Math.max(1, padding);
    const offset = fitToContent ? projected.getCenter(new THREE.Vector3()) : new THREE.Vector3();
    camera.left = offset.x - halfHeight * aspect;
    camera.right = offset.x + halfHeight * aspect;
    camera.top = offset.y + halfHeight;
    camera.bottom = offset.y - halfHeight;
    camera.updateProjectionMatrix();
  }

  function reset() {
    fittedBounds.getCenter(center);
    const radius = fittedBounds.getSize(new THREE.Vector3()).length() / 2;
    camera.position.copy(center).addScaledVector(direction, Math.max(radius * 5, 8));
    camera.zoom = 1;
    controls.target.copy(center);
    camera.lookAt(center);
    controls.update();
    projectionSize();
    render();
  }

  function mount(instance, definition, time = 0, state = {}) {
    if (activeObject) scene.remove(activeObject);
    activeObject = instance.object;
    framingPoints = [];
    function collectFramingPoints() {
      if (!fitToContent) return;
      activeObject.traverse(node => {
        if (!node.geometry) return;
        node.geometry.computeBoundingBox();
        const bounds = node.geometry.boundingBox;
        for (const x of [bounds.min.x, bounds.max.x]) for (const y of [bounds.min.y, bounds.max.y]) for (const z of [bounds.min.z, bounds.max.z]) {
          framingPoints.push(new THREE.Vector3(x, y, z).applyMatrix4(node.matrixWorld));
        }
      });
    }
    scene.add(activeObject);
    // Delivery models face +Z. Show their loading doors on first inspection,
    // so changing aperture and cargo has an immediately visible effect.
    direction.set(1, .82, definition.id.startsWith('delivery-') ? -1.42 : 1.42).normalize();
    const full = new THREE.Box3();
    const duration = definition.duration || 12;
    // Sample travel, open doors and maximum capacity before fixing the frame.
    // In particular, a pool at zero must still reserve all six machine slots.
    for (const t of [0, duration * .2, duration * .4, duration * .55, duration * .75]) {
      instance.update(t);
      activeObject.updateMatrixWorld(true);
      full.union(new THREE.Box3().setFromObject(activeObject));
      collectFramingPoints();
    }
    instance.update(duration * .4, { ...state, open: 1, authorized: true, capacity: 6 });
    activeObject.updateMatrixWorld(true);
    full.union(new THREE.Box3().setFromObject(activeObject));
    collectFramingPoints();
    for (const sample of definition.framingSamples || []) {
      instance.update(sample.time, sample.state);
      activeObject.updateMatrixWorld(true);
      full.union(new THREE.Box3().setFromObject(activeObject));
      collectFramingPoints();
    }
    instance.update(time, state);
    if (!full.isEmpty()) fittedBounds = full;
    const boxSize = fittedBounds.getSize(new THREE.Vector3());
    const radius = Math.max(boxSize.length(), 4);
    floor.position.y = fittedBounds.min.y - .025;
    fittedBounds.getCenter(center);
    sun.target.position.copy(center);
    sun.position.copy(center).add(new THREE.Vector3(-.7, 1.5, .8).multiplyScalar(radius));
    const shadowCamera = sun.shadow.camera;
    Object.assign(shadowCamera, { left: -radius, right: radius, top: radius, bottom: -radius, near: .1, far: radius * 5 });
    shadowCamera.updateProjectionMatrix();
    reset();
  }

  function resize() {
    const rect=element.getBoundingClientRect();
    width=Math.max(1,rect.width);height=Math.max(1,rect.height);
    syncRaster(true);
    projectionSize();
    render();
  }

  function syncRaster(force=false){const dpr=Math.min(window.devicePixelRatio||1,Math.sqrt(pixelBudget/(width*height)),maxDimension/width,maxDimension/height);if(force||Math.abs(renderer.getPixelRatio()-dpr)>.000001)renderer.setDrawingBufferSize(width,height,dpr);}

  function render() {
    syncRaster();
    controls.update();
    renderer.render(scene, camera);
  }

  renderer.domElement.addEventListener('keydown', event => {
    if (!['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', '+', '=', '-', '0'].includes(event.key)) return;
    event.preventDefault();
    if (event.key === '0') return reset();
    if (['+', '=', '-'].includes(event.key)) {
      camera.zoom = THREE.MathUtils.clamp(camera.zoom * (event.key === '-' ? .9 : 1.1), controls.minZoom, controls.maxZoom);
      camera.updateProjectionMatrix();
    } else {
      const spherical = new THREE.Spherical().setFromVector3(camera.position.clone().sub(controls.target));
      if (event.key === 'ArrowLeft') spherical.theta -= .12;
      if (event.key === 'ArrowRight') spherical.theta += .12;
      if (event.key === 'ArrowUp') spherical.phi -= .1;
      if (event.key === 'ArrowDown') spherical.phi += .1;
      spherical.phi = THREE.MathUtils.clamp(spherical.phi, controls.minPolarAngle, controls.maxPolarAngle);
      camera.position.copy(controls.target).add(new THREE.Vector3().setFromSpherical(spherical));
    }
    render();
  });

  const observer = new ResizeObserver(resize);
  observer.observe(element);
  resize();
  return {
    mount, render, reset, renderer,
    inspect: () => ({
      width, height, zoom: camera.zoom,
      bounds: { min: fittedBounds.min.toArray(), max: fittedBounds.max.toArray() },
      camera: camera.position.toArray(), target: controls.target.toArray(),
    }),
    dispose() {
      observer.disconnect();
      controls.dispose();
      floorGeometry.dispose();
      floorMaterial.dispose();
      environmentTarget.dispose();
      renderer.dispose();
      renderer.domElement.remove();
    },
  };
}
