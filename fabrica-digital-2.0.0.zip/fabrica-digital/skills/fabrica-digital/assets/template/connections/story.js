import {createPathSampler} from '../kit/conveyor-path.js';

export const DURATION=24;
export const ROUTE=[
  {type:'line',from:[-7.2,-2],to:[1.5,-2]},
  {type:'arc',center:[1.5,0],radius:2,startAngle:-Math.PI/2,endAngle:0},
  {type:'line',from:[3.5,0],to:[3.5,6]},
];
const route=createPathSampler(ROUTE,{height:1.285});
export const STOPS=[4.2,8.7+Math.PI+2.3];
export const BEATS=[
  {at:0,label:'Entrada',title:'Una pieza entra en la línea.',copy:'Sigue el documento 07. Es el mismo durante todo el recorrido.'},
  {at:4.6,label:'Primera máquina',title:'Se detiene. La primera máquina lo lee.',copy:'El cabezal baja cuando el documento está centrado. La cinta espera a que termine.'},
  {at:11.5,label:'La curva',title:'Una conexión continua hasta el siguiente paso.',copy:'El documento sale con su primera marca, sigue la curva y llega alineado a la segunda máquina.'},
  {at:16.6,label:'Segunda máquina',title:'Otra parada. La revisión termina el trabajo.',copy:'La segunda máquina recibe la misma pieza y añade su marca al completar la revisión.'},
  {at:23.5,label:'Salida',title:'Dos pasos completados. Una sola pieza.',copy:'Las dos marcas viajan con el documento hasta la salida.'},
];
const ease=x=>{const p=Math.max(0,Math.min(1,x));return p*p*(3-2*p)};
export function sampleFlow(time){
  const t=Math.max(0,Math.min(DURATION,Number(time)||0));
  let distance,stage;
  if(t<4){distance=STOPS[0]*ease(t/4);stage=0}
  else if(t<7){distance=STOPS[0];stage=1}
  else if(t<16){distance=STOPS[0]+(STOPS[1]-STOPS[0])*ease((t-7)/9);stage=2}
  else if(t<19){distance=STOPS[1];stage=3}
  else{distance=STOPS[1]+(route.length-STOPS[1])*ease((t-19)/4.5);stage=4}
  const work=[t>=4&&t<7,t>=16&&t<19];
  return {time:t,distance,stage,position:route.at(distance).position,yaw:route.at(distance).yaw,
    work,localTime:[Math.max(0,Math.min(3,t-4)),Math.max(0,Math.min(3,t-16))],
    completed:[t>=7,t>=19],moving:(t>0&&t<4)||(t>7&&t<16)||(t>19&&t<23.5),
    pieceId:'07',...BEATS[stage]};
}
