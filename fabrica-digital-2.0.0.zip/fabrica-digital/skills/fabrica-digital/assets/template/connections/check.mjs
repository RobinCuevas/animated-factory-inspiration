import assert from 'node:assert/strict';
import * as THREE from 'three';
import { createFlow } from './scene.js';
import { DURATION, sampleFlow } from './story.js';

// Integration checks for this 24-second story. Path construction has its own test.
const CENTERS = [[-3, 1.285, -2], [3.5, 1.285, 2.3]];
const DONE_AT = [7, 19];
const DOCUMENT_KINDS = new Set(['original', 'copy', 'job', 'data', 'error']);
const EPS = 1e-8;
const STEP = 0.02;
const near = (a, b, context, tolerance = EPS) => {
  assert.ok(Math.abs(a - b) <= tolerance, `${context}: ${a} != ${b}`);
};
const nearVector = (actual, expected, context, tolerance = EPS) => {
  actual.forEach((value, index) => near(value, expected[index], `${context}[${index}]`, tolerance));
};
function finite(value, context) {
  if (typeof value === 'number') assert.ok(Number.isFinite(value), `${context} is not finite`);
  else if (Array.isArray(value)) value.forEach((entry, i) => finite(entry, `${context}[${i}]`));
  else if (value && typeof value === 'object') {
    for (const [key, entry] of Object.entries(value)) finite(entry, `${context}.${key}`);
  }
}
function effectivelyVisible(object) {
  for (let current = object; current; current = current.parent) if (!current.visible) return false;
  return true;
}
function materialsOf(node) {
  return node.material ? (Array.isArray(node.material) ? node.material : [node.material]) : [];
}
function snapshot(object) {
  const result = [];
  object.traverse(node => result.push({
    name: node.name,
    visible: node.visible,
    position: node.position.toArray(),
    quaternion: node.quaternion.toArray(),
    scale: node.scale.toArray(),
    materials: materialsOf(node).map(material => ({
      color: material.color?.toArray(),
      emissive: material.emissive?.toArray(),
      intensity: material.emissiveIntensity,
      opacity: material.opacity,
    })),
  }));
  return result;
}
function resources(object) {
  const found = new Set();
  object.traverse(node => {
    if (node.geometry) found.add(node.geometry);
    for (const material of materialsOf(node)) {
      found.add(material);
      if (material.map) found.add(material.map);
    }
  });
  return found;
}

assert.equal(DURATION, 24, 'This check describes the 24-second connection story');
const flow = createFlow();
const identity = flow.inspect().piece;
const initial = snapshot(flow.object);
// A point at the top of each internal roller must move toward local -Z,
// the same direction as the document through an ingester.
flow.update(1);
const contactPoints=flow.inspect().machines.map(machine=>machine.userData.model.userData.rollers.map(roller=>({
  roller,point:new THREE.Vector3(0,.103,0).applyQuaternion(roller.quaternion.clone().invert()),
})));
flow.update(1.001);
for(const row of contactPoints)for(const {roller,point} of row){
  assert.ok(point.applyQuaternion(roller.quaternion).z<0,'An internal roller runs against the document');
}
flow.update(0);
const headMoved = [false, false];
const scanned = [false, false];
const localFront = new THREE.Vector3(0, 0, -1);
let previousPosition;
let previousQuaternion;
let previousState;
let samples = 0;
let visibleDocument;

// Geometry is static, so inspect its numeric data once rather than each frame.
const checkedGeometries = new Set();
flow.object.traverse(node => {
  if (!node.geometry || checkedGeometries.has(node.geometry)) return;
  checkedGeometries.add(node.geometry);
  for (const [name, attribute] of Object.entries(node.geometry.attributes)) {
    for (const value of attribute.array) assert.ok(Number.isFinite(value), `Non-finite geometry ${name}`);
  }
});

for (let frame = 0; frame <= DURATION / STEP; frame += 1) {
  const t = frame * STEP;
  const state = flow.update(t);
  const { piece, machines, marks, scan } = flow.inspect();
  assert.equal(piece, identity, `The document instance changed at ${t}`);
  assert.equal(state.pieceId, '07', `The document identity changed at ${t}`);
  finite(state, `story ${t}`);
  nearVector(piece.position.toArray(), state.position, `Rendered document at ${t}`);
  assert.equal(marks.length, 2);
  assert.equal(machines.length, 2);

  // Count effective visibility, including ancestors. A hidden machine copy
  // must never be mistaken for a second document entering the same operation.
  const visibleKinds = [];
  flow.object.traverse(node => {
    finite(node.position.toArray(), `position ${node.name} at ${t}`);
    finite(node.quaternion.toArray(), `quaternion ${node.name} at ${t}`);
    finite(node.scale.toArray(), `scale ${node.name} at ${t}`);
    if (DOCUMENT_KINDS.has(node.userData.kind) && effectivelyVisible(node)) visibleKinds.push(node);
  });
  assert.equal(visibleKinds.length, 1, `Expected one visible document at ${t}`);
  assert.equal(visibleKinds[0].parent, identity, `The visible document left its owner at ${t}`);
  if (!visibleDocument) visibleDocument = visibleKinds[0];
  assert.equal(visibleKinds[0], visibleDocument, `The visible document variant changed at ${t}`);

  machines.forEach((machine, index) => {
    const model = machine.userData.model;
    assert.equal(effectivelyVisible(model.userData.document), false, `Internal copy visible in machine ${index} at ${t}`);
    const lowered = model.userData.head.position.y < model.userData.headRest.y - EPS;
    headMoved[index] ||= lowered;
    assert.equal(marks[index].parent, identity, 'Completion marks must travel with the document');
    assert.equal(marks[index].visible, t >= DONE_AT[index], `Early or missing mark ${index} at ${t}`);
    assert.equal(state.completed[index], t >= DONE_AT[index], `Incorrect completed state ${index} at ${t}`);
    if (state.work[index] || lowered || (scan.visible && state.work[index])) {
      nearVector(piece.position.toArray(), CENTERS[index], `Work away from machine ${index} at ${t}`);
      const inMachine = piece.position.clone().sub(machine.position)
        .applyQuaternion(machine.quaternion.clone().invert()).divide(machine.scale);
      nearVector(inMachine.toArray(), [0, 1.285, 0], `Document not under the actual machine ${index} at ${t}`);
      assert.ok(piece.quaternion.angleTo(machine.quaternion) <= 1e-7, `Document misaligned with machine ${index} at ${t}`);
      assert.equal(state.moving, false, `Machine ${index} works during transport at ${t}`);
      if (previousState?.work[index]) {
        nearVector(piece.position.toArray(), previousPosition.toArray(), `Document moved during work ${index} at ${t}`);
      }
    }
    if (lowered) assert.equal(state.work[index], true, `Head moves outside its work interval at ${t}`);
    if (!state.work[index]) near(model.userData.head.position.y, model.userData.headRest.y, `Head not parked at ${t}`);
    if (scan.visible && state.work[index]) scanned[index] = true;
  });
  if (scan.visible) {
    assert.equal(state.work.filter(Boolean).length, 1, `Scanner visible outside work at ${t}`);
    assert.equal(scan.parent, identity, 'Scanner must track the actual document');
  }
  assert.ok(state.work.filter(Boolean).length <= 1, `Both machines claim the document at ${t}`);

  if (previousPosition) {
    const displacement = piece.position.clone().sub(previousPosition);
    // The designed transport stays below 2 units/s, including the curve.
    assert.ok(displacement.length() <= 2 * STEP + EPS, `Position discontinuity at ${t}`);
    assert.ok(piece.quaternion.angleTo(previousQuaternion) <= 0.03, `Orientation discontinuity at ${t}`);
    if (displacement.length() > 0.0001) {
      const heading = localFront.clone().applyQuaternion(piece.quaternion);
      assert.ok(heading.angleTo(displacement.normalize()) <= 0.03, `Document faces across its travel at ${t}`);
    }
  }
  previousPosition = piece.position.clone();
  previousQuaternion = piece.quaternion.clone();
  previousState = state;
  samples += 1;
}
assert.deepEqual(headMoved, [true, true], 'Both machines must perform visible work');
assert.deepEqual(scanned, [true, true], 'Both completed operations must include a scan');
nearVector(identity.position.toArray(), [3.5, 1.285, 6], 'The document must reach the exit');

// Include exact state boundaries and physical contact poses when seeking back.
const poses = [0, 3.999, 4, 5.5, 6.999, 7, 11.5, 15.999, 16, 17.5, 18.999, 19, 23.5, 24];
const expected = poses.map(t => ({ state: flow.update(t), pose: snapshot(flow.object) }));
for (let index = poses.length - 1; index >= 0; index -= 1) {
  assert.deepEqual(flow.update(poses[index]), expected[index].state, `State seek failed at ${poses[index]}`);
  assert.deepEqual(snapshot(flow.object), expected[index].pose, `Rendered seek failed at ${poses[index]}`);
}
flow.update(0);
assert.deepEqual(snapshot(flow.object), initial, 'Returning to zero left stale scene state');
for (const t of [-1, NaN, Infinity, -Infinity]) {
  const state = flow.update(t);
  finite(state, `Input ${String(t)}`);
  finite(snapshot(flow.object), `Pose for ${String(t)}`);
}

// Scene placement belongs to the consumer, including rotations and nonuniform scales.
flow.object.position.set(8, -2, 6);
flow.object.rotation.set(0.17, -0.43, 0.09);
flow.object.scale.set(1.2, 0.9, 0.7);
const placement = { position: flow.object.position.toArray(), quaternion: flow.object.quaternion.toArray(), scale: flow.object.scale.toArray() };
for (const t of [17.5, 0, 24, 5.5]) {
  flow.update(t);
  assert.deepEqual({ position: flow.object.position.toArray(), quaternion: flow.object.quaternion.toArray(), scale: flow.object.scale.toArray() }, placement);
  flow.object.updateMatrixWorld(true);
  const expectedWorld = new THREE.Vector3().fromArray(sampleFlow(t).position).applyMatrix4(identity.parent.matrixWorld);
  nearVector(identity.getWorldPosition(new THREE.Vector3()).toArray(), expectedWorld.toArray(), `Placed scene at ${t}`);
}

// Disposing one scene must not invalidate an independently live one.
const survivor = createFlow();
const survivorPose = snapshot(survivor.object);
let foreignDisposals = 0;
for (const resource of resources(survivor.object)) resource.addEventListener('dispose', () => { foreignDisposals += 1; });
flow.dispose();
flow.dispose();
assert.equal(flow.object.children.length, 0, 'Disposed scene retained its children');
assert.equal(foreignDisposals, 0, 'Disposing one flow released a live flow resource');
survivor.update(24);
const finalPose = snapshot(survivor.object);
survivor.update(0);
assert.deepEqual(snapshot(survivor.object), survivorPose, 'The surviving scene changed after another was disposed');
const recreated = createFlow();
recreated.update(24);
assert.deepEqual(snapshot(recreated.object), finalPose, 'A recreated flow does not reproduce the same result');
recreated.dispose();
survivor.dispose();

console.log(JSON.stringify({
  ok: true,
  samples,
  seekPoses: poses.length,
  duration: DURATION,
  visibleDocuments: 1,
  workCenters: CENTERS,
  completedMarks: 2,
  placementPreserved: true,
  independentDisposal: true,
  limitation: 'Checks scene behavior, not visual presentation or audience understanding.',
}, null, 2));
