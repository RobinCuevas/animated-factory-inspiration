import * as THREE from 'three';
import {createAsset} from '../kit/index.js';
import {createConveyorPath} from '../kit/conveyor-path.js';
import {makeWorkshop} from '../shared/primitives.js';
import {sampleFlow,ROUTE} from './story.js';

export function createFlow(){
  const object=new THREE.Group(),layout=new THREE.Group();object.add(layout);
  layout.rotation.y=Math.PI-.17;
  const decor=makeWorkshop();layout.add(decor.root);
  const p=decor.palette;
  const machines=[createAsset('ingester'),createAsset('ingester')];
  machines[0].object.position.set(-3,0,-2);machines[0].object.rotation.y=-Math.PI/2;
  machines[1].object.position.set(3.5,0,2.3);machines[1].object.rotation.y=Math.PI;
  const lamps=[];
  machines.forEach((asset,index)=>{
    layout.add(asset.object);
    const sign=decor.label(index?'02 · REVISIÓN':'01 · LECTURA',[0,0,0],{width:2.05,height:.3,color:'#fffaf0',background:'#246964'});
    const holder=new THREE.Group();decor.root.add(holder);
    holder.position.copy(asset.object.position);holder.rotation.copy(asset.object.rotation);
    holder.add(sign);sign.position.set(0,3.31,1.407);
    const lamp=decor.cylinder(.065,.035,p.amber);holder.add(lamp);lamp.position.set(.86,3.02,1.397);lamp.rotation.x=Math.PI/2;
    // An instance-owned material makes status independent of the other machine.
    lamp.material=lamp.material.clone();lamps.push(lamp);
    // Short transfer plates bridge the last roller to the external conveyor.
    for(const z of [-1.39,1.39]){
      const plate=decor.box(1.59,.025,.22,p.steel);holder.add(plate);plate.position.set(0,1.2685,z);
    }
  });
  const belts=[
    createConveyorPath([{type:'line',from:[-7.8,-2],to:[-4.5,-2]}]),
    createConveyorPath([{type:'line',from:[-1.5,-2],to:[1.5,-2]},ROUTE[1],{type:'line',from:[3.5,0],to:[3.5,.8]}]),
    createConveyorPath([{type:'line',from:[3.5,3.8],to:[3.5,6.6]}]),
  ];
  belts.forEach(belt=>layout.add(belt.object));
  const document=createAsset('document',{kind:'copy'});document.object.scale.setScalar(.65);layout.add(document.object);
  const tag=decor.label('07',[0,0,0],{width:.34,height:.28,color:'#175350',background:'#f5efd8'});
  document.object.add(tag);tag.position.set(0,.069,.48);tag.rotation.x=-Math.PI/2;
  const marks=[0,1].map(i=>{
    const mark=decor.label('✓',[0,0,0],{width:.25,height:.25,color:'#ffffff',background:'#246964'});
    document.object.add(mark);mark.position.set(-.2+i*.4,.071,-.46);mark.rotation.x=-Math.PI/2;return mark;
  });
  const scan=decor.box(.91,.008,.033,p.green);document.object.add(scan);
  scan.material=scan.material.clone();scan.material.emissive.set(0x62d7b8);scan.material.emissiveIntensity=.7;
  scan.castShadow=false;
  const rollers=machines.map(asset=>asset.object.userData.model.userData.rollers.map(mesh=>({mesh,rest:mesh.quaternion.clone()})));
  const axis=new THREE.Vector3(0,1,0),spin=new THREE.Quaternion();
  let disposed=false;
  function update(time){
    const state=sampleFlow(time);
    machines.forEach((asset,index)=>{
      asset.update(state.localTime[index],{processing:state.work[index]});
      asset.object.userData.model.userData.document.visible=false;
      // Preserve cylinder orientation and rotate around its own axle.
      rollers[index].forEach(({mesh,rest})=>mesh.quaternion.copy(rest).multiply(spin.setFromAxisAngle(axis,state.distance/.103)));
      lamps[index].material.color.set(state.completed[index]?0x6da574:state.work[index]?0xe3aa45:0x84918a);
    });
    document.object.position.fromArray(state.position);
    // The front of the paper points along -Z, matching the machine input.
    document.object.rotation.y=state.yaw+Math.PI;
    marks.forEach((mark,index)=>{mark.visible=state.completed[index]});
    const active=state.work.findIndex(Boolean),local=state.localTime[active];
    scan.visible=active>=0&&local>=1.35&&local<=2.05;
    scan.position.set(0,.077,.54-1.08*Math.max(0,Math.min(1,(local-1.35)/.7)));
    if(active<0)scan.position.set(0,.077,.54);
    belts.forEach(belt=>belt.update(state.distance));
    return state;
  }
  function dispose(){
    if(disposed)return;disposed=true;
    for(const mark of [tag,...marks,scan])mark.removeFromParent();
    scan.material.dispose();decor.dispose();belts.forEach(belt=>belt.dispose());
    machines.forEach(asset=>asset.dispose());document.dispose();object.removeFromParent();object.clear();
  }
  update(0);
  return {object,update,dispose,inspect:()=>({piece:document.object,machines:machines.map(a=>a.object),marks,scan})};
}
