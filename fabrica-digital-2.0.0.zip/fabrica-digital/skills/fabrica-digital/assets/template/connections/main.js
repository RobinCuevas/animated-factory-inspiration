import {createViewer} from '../catalog/viewer.js';
import {createFlow} from './scene.js';
import {BEATS,DURATION} from './story.js';

const $=id=>document.getElementById(id);
let viewer,instance,time=0,playing=false,snapshot,lastClock=performance.now();
const format=t=>`0:${String(Math.floor(t)).padStart(2,'0')}`;
function render(){
  snapshot=instance.update(time);viewer.render();
  $('phase-title').textContent=snapshot.title;$('phase-copy').textContent=snapshot.copy;
  $('piece-state').textContent=`DOCUMENTO 07 · ${snapshot.completed.filter(Boolean).length}/2`;
  $('flow-timeline').value=String(time);$('flow-timeline').setAttribute('aria-valuetext',`${format(time)}. ${snapshot.title}`);
  $('flow-time').textContent=`${format(time)} / ${format(DURATION)}`;
  $('flow-play').textContent=playing?'Pausar':time>=DURATION?'Volver a ver':'Reproducir recorrido';
  [...$('flow-beats').children].forEach((node,index)=>{if(index===snapshot.stage)node.setAttribute('aria-current','step');else node.removeAttribute('aria-current')});
}
function inspect(){return {time,playing,snapshot,viewer:viewer.inspect()}}
function seek(value){time=Math.max(0,Math.min(DURATION,Number(value)||0));playing=false;lastClock=performance.now();render();return inspect()}
try{
  await document.fonts.ready;
  instance=createFlow();viewer=createViewer($('flow-stage'),{padding:1.12,fitToContent:true});
  viewer.mount(instance,{id:'connections',duration:DURATION,framingSamples:[{time:DURATION}]});
  $('flow-beats').replaceChildren(...BEATS.map(beat=>{const node=document.createElement('button');node.type='button';node.textContent=beat.label;node.addEventListener('click',()=>seek(beat.at));return node}));
  seek(new URLSearchParams(location.search).get('t')||0);$('stage-message').hidden=true;
  $('flow-play').addEventListener('click',()=>{if(time>=DURATION)time=0;playing=!playing;lastClock=performance.now();render()});
  $('flow-replay').addEventListener('click',()=>seek(0));
  $('flow-timeline').addEventListener('input',event=>seek(event.target.value));
  $('reset-view').addEventListener('click',()=>viewer.reset());
  document.addEventListener('visibilitychange',()=>{lastClock=performance.now()});
  viewer.renderer.setAnimationLoop(now=>{
    const delta=Math.max(0,Math.min(.1,(now-lastClock)/1000));lastClock=now;
    if(playing&&!document.hidden){time=Math.min(DURATION,time+delta);if(time>=DURATION)playing=false;render()}
    else viewer.render();
  });
  window.connectionsAPI={seek,inspect};
  window.addEventListener('pagehide',()=>{viewer.renderer.setAnimationLoop(null);instance.dispose();viewer.dispose()},{once:true});
}catch(error){$('stage-message').hidden=false;$('stage-message').textContent=`No se ha podido abrir el recorrido. ${error.message}`;for(const id of ['flow-play','flow-replay','flow-timeline'])$(id).disabled=true;console.error(error)}
