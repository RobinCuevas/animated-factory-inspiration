# Iconos de servicios

Los SVG identifican servicios representados en diagramas de arquitectura. No son la marca de esta plantilla ni afirman contratación, despliegue o certificación.

- `azure-*.svg` y `entra-external-id.svg`: colección oficial de [Azure Architecture Center](https://learn.microsoft.com/en-us/azure/architecture/icons/), paquete V24. `azure-openai.svg` es el icono del servicio Azure OpenAI, no el logotipo corporativo de OpenAI. `azure-ai-search.svg` corresponde a Azure AI Search.
- `entra-id.svg`: colección oficial de [Microsoft Entra](https://learn.microsoft.com/en-us/entra/architecture/architecture-icons), octubre de 2023.

Se conservan los SVG originales, sus colores y proporciones. Los nombres de los productos deben acompañar los iconos. Las colecciones permiten su uso en diagramas de arquitectura, formación y documentación bajo las condiciones de Microsoft, que reserva los demás derechos. Entra excluye su uso en comunicaciones de marketing. Consulta las condiciones enlazadas si cambias el uso del artefacto. Guías consultadas el 18 de septiembre de 2026.

Los logotipos de futuras empresas los aporta cada proyecto. No se incluyen marcas de clientes ni agencias. La geometría procedural, la tipografía y los iconos tienen procedencias distintas.
