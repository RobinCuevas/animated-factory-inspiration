---
name: fabrica-digital
description: Crea y adapta fábricas 3D animadas para explicar arquitecturas y procesos a público no técnico, con marca configurable, máquinas, flujos físicos y reproducción por pasos. Úsala para una nueva fábrica digital o para mejorar, integrar y exportar una existente.
---

# Fábrica digital

Transforma responsabilidades y datos en acciones físicas comprensibles. La plantilla ya resuelve cámara, reproducción, rótulos, nitidez, personajes y paneles. Reutiliza estos comportamientos y adapta el contenido a la empresa.

## Arrancar

1. Lee las instrucciones del proyecto y sus fuentes disponibles. Sintetiza componentes, datos, conexiones y límites de responsabilidad antes de modelar. Separa lo documentado, la hipótesis elegida y lo pendiente. Si una fuente no es accesible, continúa con las disponibles sin atribuirle contenido.
2. Define los recorridos que necesita la audiencia. Para el relato lee [references/ventas.md](references/ventas.md). No heredes todos los servicios ni todos los ejemplos de la plantilla.
3. Crea una copia nueva con `node scripts/create-demo.mjs <nuevo-directorio>`, ejecutado desde esta carpeta. No trabajes sobre el plugin instalado ni sobre un proyecto de otro cliente.
4. En la copia, lee `README.md` y `docs/reuse-guide.md`. Configura `src/project.js`, adapta arquitectura, guion y escena. Usa `docs/new-project-brief.md` para los datos que falten. Las elecciones reversibles de representación no necesitan detener el trabajo.
5. Ejecuta y revisa el resultado según [references/ejecucion.md](references/ejecucion.md). Entrega una vista comprobada, no solo un guion o capturas del ejemplo.

## Criterios que no conviene reinventar

Cada paso necesita un desencadenante, una acción visible y un resultado. Mantén la identidad del objeto durante su recorrido. Almacenar un archivo, guardar su referencia y entregar una copia son acciones distintas. La acumulación debe verse antes de añadir capacidad.

Conserva los controles de lectura de la plantilla: Anterior y Siguiente reproducen un paso completo y paran. El clic directo en una sección muestra su introducción completa. El salto desde la sección anterior puede entrar en el punto útil y usa una transición breve. No sincronices la duración de la cámara con la velocidad del relato.

Usa los iconos de servicios sobre las superficies de las máquinas y en sus fichas. Conserva proporciones y color de marca. El logo y los colores de la empresa son opcionales. No inventes un fabricante para un sistema identificado solo por sus siglas.

El robot y el evaluador de sombrero blanco son recursos de explicación, no funcionalidades obligatorias. Una sugerencia no equivale a autorización para actuar. Un escudo ilustrado no demuestra seguridad ni resultados de un pentest.

## Extender y entregar

Para una máquina o personaje nuevo, empieza por `catalog.html`, `connections.html` y `custom-asset.html`. Reutiliza `kit/` y `shared/`. Si necesitas una pieza nueva, conserva los pivotes, la animación reversible y la instancia independiente, y comprueba su acción en el contexto de la escena.

El texto principal se dirige al cliente. Las notas de preparación y las referencias internas permanecen fuera de la presentación. Una arquitectura preliminar puede llevar un estado visible y explicaciones concretas de sus decisiones pendientes, sin narrar el proceso interno de elaboración.

Usa datos sintéticos. Copia al artefacto público únicamente los recursos necesarios. La visualización no autoriza despliegues, gastos, envíos, publicaciones ni cambios en sistemas representados. Conserva los avisos de terceros. El detalle técnico de implementación visual está en `docs/reuse-guide.md` de la plantilla.
