# Abrir, comprobar y exportar

Trabaja en la copia del proyecto, no en el plugin instalado. Necesitas Node.js 22 o posterior y pnpm (la versión está declarada en `package.json`). FFmpeg solo es necesario para vídeo. El runtime disponible en Codex puede aportar estas herramientas, pero el paquete no depende de una ruta personal.

```sh
node scripts/factory.mjs dev
node scripts/factory.mjs check
node scripts/factory.mjs build
node scripts/factory.mjs preview
```

`dev` sirve una copia de las fuentes. Reinicia el comando después de modificar el proyecto. `preview` construye y sirve la web final. Abre la URL impresa. La página principal es el recorrido editable. `catalog.html`, `connections.html` y `custom-asset.html` muestran piezas, conexiones y una máquina adicional.

El wrapper conserva dependencias, compilación y resultados en una caché local fuera del proyecto. `FACTORY_CACHE_DIR` permite cambiarla y `FACTORY_PORT` el puerto. No edites esa copia temporal: la siguiente preparación la reemplaza. No ejecutes instalaciones de dependencias directamente dentro de un árbol sincronizado.

`check` comprueba el guion y la interfaz mediante un navegador. Lee su resultado y mira las capturas relevantes. Al cambiar recorridos adapta las comprobaciones a su comportamiento: los controles del ejemplo no validan la nueva arquitectura. Revisa al menos una vista panorámica y otra estrecha, los puntos de entrega entre máquinas y un salto de tiempo hacia atrás. Comprueba Chrome real si la presentación se hará allí.

Para exportar un recorrido:

```sh
node scripts/factory.mjs render consultation
node scripts/factory.mjs render consultation 4k
```

Sustituye `consultation` por un identificador incluido en tu proyecto. La salida habitual es MP4 sin audio, 1920 × 1080 a 24 fps o 3840 × 2160 a 60 fps. Verifica resolución, duración y decodificación del archivo generado. No entregues una prueba corta como exportación completa. Consulta `scripts/render.mjs` antes de cambiar opciones de captura.

`build` imprime el directorio estático entregable. Se sirve por HTTP, no abriendo `index.html` con `file://`. La compilación pública no necesita guiones privados, documentos fuente, rutas locales ni instrucciones de agentes. Revisa también `public/`, pues su contenido sí se copia a la web. Para insertar en otra web utiliza `?embed=1` y lee `docs/embedding.md`.
