# Del contexto a un recorrido

La audiencia debe poder señalar una máquina y explicar qué recibe, qué hace y dónde deja el resultado. El objetivo no es enseñar un curso de cloud ni llenar el suelo con el catálogo del proveedor.

Empieza por dos o tres acciones que la empresa reconozca. Una consulta, preparar trabajo, enviar una operación o recuperar un archivo suelen revelar más que una lista de servicios. Añade un recorrido de demora, fallo o demanda cuando ayude a discutir una decisión real.

Antes de construir, deja una síntesis privada pequeña: componente, responsabilidad, entrada, salida, persistencia y estado de la decisión. Si varias capacidades viven en un backend modular, una máquina puede representarlas. No dibujes todas las alternativas como instancias simultáneas.

Un paso útil tiene esta forma:

> La persona adjunta un plano. El portal comprueba su contexto y guarda el archivo en el almacén. Conserva en su base una ficha que permite volver a encontrarlo. El plano sigue guardado cuando se entrega una copia para leerlo.

La animación muestra el mismo archivo durante la entrada. Después distingue el original conservado, la referencia pequeña y la copia de lectura. No añade bandejas o folios móviles para rellenar tiempo.

La IA puede proponer, extraer o redactar. Explica qué información usa, qué produce y quién decide. Una fábrica que muestra acceso de agentes puede ser una propuesta para debate, con permisos y límites aún por acordar. No transforma esa posibilidad en una integración contratada.

Un evaluador externo puede probar la entrada y luego los permisos desde una cuenta autorizada. El escudo representa controles que se comprobarán. No cuentes que bloquea todo ni que el aislamiento está verificado si no hay resultados que lo sostengan.

En el texto público usa afirmaciones dirigidas a quien mira: "El borrador queda guardado" o "El diseño debe confirmar cómo se recibe el estado". Evita "figura en el briefing", "según nuestras notas" o rutas de documentos. Las fuentes y su alcance pueden permanecer en una ficha técnica si aportan una referencia útil y autorizada.

El mapa lógico explica responsabilidades e intercambios. La vista de red explica accesos. Una plataforma en el suelo no convierte un tenant, una suscripción y una VNet en la misma cosa. Sitúa los servicios globales y sus puntos de acceso con cuidado.
